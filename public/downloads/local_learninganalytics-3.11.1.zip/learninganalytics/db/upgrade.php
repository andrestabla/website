<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

defined('MOODLE_INTERNAL') || die();

/**
 * Pasos de actualizacion del plugin.
 *
 * @param int $oldversion
 * @return bool
 */
function xmldb_local_learninganalytics_upgrade($oldversion) {

    if ($oldversion < 2026082406) {
        // La marca de la ultima comprobacion de IA se escribe ANTES de salir a
        // la red, para que dos peticiones simultaneas no consulten a la vez.
        // El efecto colateral es que un intento fallido deja la marca puesta y
        // bloquea el reintento durante horas. Al actualizar se borra: asi una
        // plataforma que acaba de contratar la funcion la ve de inmediato en
        // vez de esperar a la revalidacion del dia siguiente.
        unset_config('aicheck', 'local_learninganalytics');

        upgrade_plugin_savepoint(true, 2026082406, 'local', 'learninganalytics');
    }

    return true;
}
