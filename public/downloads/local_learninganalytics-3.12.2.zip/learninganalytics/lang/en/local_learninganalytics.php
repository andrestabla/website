<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * English strings.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Learning Analytics';
$string['dashboard'] = 'Learning Analytics dashboard';
$string['settings'] = 'Learning Analytics settings';

// Capabilities.
$string['learninganalytics:view'] = 'View the Learning Analytics dashboard';
$string['learninganalytics:resendcredentials'] = 'Resend account credentials to users';

// Settings.
$string['field_estado'] = 'Status profile field';
$string['field_estado_desc'] = 'Custom user profile field used as the "Status" column. Leave empty to hide the column.';
$string['field_supervisor'] = 'Supervisor profile field';
$string['field_supervisor_desc'] = 'Custom user profile field used as the "Supervisor" column. Leave empty to hide the column.';
$string['sender'] = 'Credentials sender';
$string['sender_desc'] = 'Username of the account used as sender when resending credentials. Leave empty to use the site primary admin.';
$string['signaturemap'] = 'Signature assignment map';
$string['signaturemap_desc'] = 'One line per course, in the format <code>course_shortname : assignment</code>, where assignment is the assignment id or its exact name. Used for the "Signed" column. Leave empty to hide the column.';

// Dashboard UI.
$string['filters'] = 'Filters';
$string['filter_course'] = 'Course';
$string['filter_country'] = 'Country';
$string['filter_domain'] = 'Email domain';
$string['filter_estado'] = 'Status';
$string['filter_supervisor'] = 'Supervisor';
$string['filter_startdate'] = 'From';
$string['filter_enddate'] = 'To';
$string['filter_user'] = 'Search user';
$string['filter_all'] = 'All';
$string['applyfilters'] = 'Apply filters';
$string['resetfilters'] = 'Reset';

$string['kpi_users'] = 'Users';
$string['kpi_enrolments'] = 'Enrolments';
$string['kpi_certificates'] = 'Certificates issued';
$string['kpi_certrate'] = 'Certification rate';

$string['chart_growth'] = 'User growth';
$string['chart_domains'] = 'Users by email domain';
$string['chart_countries'] = 'Users by country';
$string['chart_certificates'] = 'Certificates over time';

$string['tab_users'] = 'Users';
$string['tab_progress'] = 'Progress';
$string['tab_certificates'] = 'Certificates';

$string['col_name'] = 'Name';
$string['col_email'] = 'Email';
$string['col_country'] = 'Country';
$string['col_estado'] = 'Status';
$string['col_supervisor'] = 'Supervisor';
$string['col_lastaccess'] = 'Last access';
$string['col_course'] = 'Course';
$string['col_progress'] = 'Progress';
$string['col_signed'] = 'Signed';
$string['col_certificate'] = 'Certificate';
$string['col_issued'] = 'Issued';

$string['yes'] = 'Yes';
$string['no'] = 'No';
$string['notapplicable'] = 'N/A';
$string['never'] = 'Never';
$string['nodata'] = 'No data matches the current filters.';
$string['nodate'] = 'No date';
$string['loading'] = 'Loading...';

// Export.
$string['export'] = 'Export';
$string['exportcsv'] = 'Download CSV';

// Resend credentials.
$string['resendcredentials'] = 'Resend account credentials';
$string['resendconfirm'] = 'Resend credentials to the {$a} selected user(s)?';
$string['resendconfirmdetail'] = 'A new password will be generated and emailed. Users will be required to change it at next login.';
$string['resendnousers'] = 'No users selected.';
$string['resendresults'] = 'Resend results';
$string['resendsent'] = 'Sent to {$a}';
$string['resendskippedauth'] = 'Skipped {$a}: the account uses an external authentication method (SSO/LDAP) and its password is not managed by Moodle.';
$string['resendfailed'] = 'Failed for {$a}: the message could not be sent. Check the site email configuration.';
$string['resendsummary'] = '{$a->sent} sent, {$a->skipped} skipped, {$a->failed} failed.';
$string['resendsubject'] = 'Your access credentials for {$a}';
$string['backtodashboard'] = 'Back to the dashboard';

// Warnings.
$string['customcertmissing'] = 'The Custom certificate plugin (mod_customcert) is not installed, so certificate data is unavailable.';
$string['fieldsnotconfigured'] = 'The Status and Supervisor profile fields are not configured. Set them in the plugin settings to enable those columns.';

// Privacy.
$string['privacy:metadata'] = 'The Learning Analytics plugin only displays data already stored elsewhere in Moodle. It does not store personal data itself, and does not send data to external services.';

// Access and placement (v2.1).
$string['hdr_access'] = 'Access';
$string['hdr_access_desc'] = 'Defines who can open the dashboards. Selecting a role grants it the corresponding Moodle capability, so the native Roles interface stays in sync and can still be used for finer-grained overrides.';
$string['viewroles'] = 'Roles that can view the dashboards';
$string['viewroles_desc'] = 'Site administrators always have access. A role selected here receives <code>local/learninganalytics:view</code>. Where the dashboard is available to that role depends on where the role is assigned: a manager at system level sees the platform dashboard, a teacher in a course sees that course only.';
$string['resendroles'] = 'Roles that can resend credentials';
$string['resendroles_desc'] = 'Grants <code>local/learninganalytics:resendcredentials</code>. This is a high-risk capability: it generates new passwords and emails them. Leave empty to restrict it to site administrators.';

$string['hdr_placement'] = 'Placement';
$string['hdr_placement_desc'] = 'Defines at which levels the dashboard appears. A disabled level is unreachable even by direct URL.';
$string['enablesite'] = 'Platform level';
$string['enablesite_desc'] = 'Show the site-wide dashboard under Site administration → Reports. Covers every course.';
$string['enablecategory'] = 'Category level';
$string['enablecategory_desc'] = 'Add the dashboard to category settings. Covers the category and its subcategories.';
$string['enablecourse'] = 'Course level';
$string['enablecourse_desc'] = 'Add the dashboard to the course menu. Covers that course only.';

$string['hdr_data'] = 'Data mapping';
$string['hdr_data_desc'] = 'Maps this platform\'s profile fields and assignments to the report columns. Nothing here is hardcoded: leaving a value empty hides the corresponding column.';
$string['hdr_credentials'] = 'Credential resending';
$string['hdr_credentials_desc'] = 'Settings for the bulk "Resend account credentials" action.';

$string['dashboardfor'] = 'Learning Analytics: {$a}';
$string['levelnotenabled'] = 'The Learning Analytics dashboard is not enabled at this level. A site administrator can enable it in the plugin settings.';
$string['scope_site'] = 'Whole platform';
$string['scope_category'] = 'Category';
$string['scope_course'] = 'Course';

// Charts v2.2.
$string['chart_activity'] = 'Activity by last access';
$string['chart_topcourses'] = 'Top courses by enrolment';
$string['chart_certsplit'] = 'Certified users';
$string['chart_map'] = 'Geographic distribution';
$string['act_7'] = 'Last 7 days';
$string['act_30'] = 'Last 30 days';
$string['act_90'] = 'Last 90 days';
$string['act_older'] = 'Over 90 days';
$string['act_never'] = 'Never accessed';
$string['cert_with'] = 'With certificate';
$string['cert_without'] = 'Without certificate';
$string['maphint'] = 'Bubble size is proportional to the number of users. Rendered locally: no map tiles are requested from external servers.';
$string['nocountrydata'] = 'No users have a country set in their profile.';
$string['nousers'] = 'no users';

// Course analytics v2.4.
$string['coursepanel'] = 'Course analytics';
$string['courseonlyreport'] = 'This report is only available at course level.';
$string['kpi_students'] = 'Students';
$string['kpi_avgprogress'] = 'Average progress';
$string['kpi_avggrade'] = 'Average grade';
$string['kpi_avgtime'] = 'Average time in course';
$string['kpi_completed'] = 'Completed the course';
$string['chart_sections'] = 'Progress by section';
$string['chart_activities'] = 'Progress by activity';
$string['chart_activitygrades'] = 'Average grade by activity';
$string['tab_students'] = 'Students';
$string['tab_activities'] = 'Activities';
$string['col_progress'] = 'Progress';
$string['col_grade'] = 'Grade';
$string['col_timespent'] = 'Time in course';
$string['col_activity'] = 'Activity';
$string['col_section'] = 'Section';
$string['col_completedby'] = 'Completed by';
$string['col_avggrade'] = 'Average grade';
$string['sectionnumber'] = 'Section {$a}';
$string['nosection'] = 'No section';
$string['durationhm'] = '{$a->h} h {$a->m} min';
$string['durationm'] = '{$a} min';
$string['filter_lastaccess'] = 'Last access';
$string['filter_progressrange'] = 'Progress (%)';
$string['filter_graderange'] = 'Grade (%)';
$string['filter_student'] = 'Student';
$string['la_older'] = 'Over 90 days';
$string['nocompletion'] = 'This course has no activity completion tracking enabled, so progress cannot be calculated. Enable it in the course settings and set completion conditions on the activities.';
$string['nogrades'] = 'This course has no graded activities yet.';
$string['timeestimated'] = 'Time in course is an estimate derived from activity logs: consecutive events are added up and a gap over 30 minutes closes the session. It is not an exact measurement.';
$string['logcapped'] = 'The log volume exceeded the processing limit, so times shown cover only part of the history.';
$string['unnamedactivity'] = '(unnamed activity)';

// Category cascade v2.6.
$string['filter_category'] = 'Category';
$string['filter_subcategory'] = 'Subcategory';
$string['filter_categorylevel'] = 'Category (level {$a})';
$string['filter_role'] = 'Role';
$string['sendmessage'] = 'Message';
$string['col_actions'] = 'Actions';

// Bulk messaging v2.9.
$string['learninganalytics:sendbulkmessage'] = 'Send a message to all users matching a filter';
$string['bulkmessage'] = 'Send message to filtered users';
$string['bulkmessagebutton'] = 'Message filtered users';
$string['bulkmessageroles'] = 'Roles that can send bulk messages';
$string['bulkmessageroles_desc'] = 'Grants <code>local/learninganalytics:sendbulkmessage</code>. This is the highest-risk capability in the plugin: it reaches every user returned by a filter at once. Leave empty to restrict it to site administrators.';
$string['bulkmessagelimit'] = 'Maximum recipients per send';
$string['bulkmessagelimit_desc'] = 'A send targeting more recipients than this is refused rather than truncated. Default 200.';
$string['bulkmessagetext'] = 'Message';
$string['bulkmessagetext_help'] = 'Plain text. It is delivered as a personal Moodle message from your account to each recipient, and each person only sees their own copy.';
$string['bulkmessagesend'] = 'Send message';
$string['bulkmessageconfirm'] = 'This message will be sent to {$a} people';
$string['bulkmessagerecipients'] = 'Recipients:';
$string['bulkmessageresults'] = 'Send results';
$string['bulkmessagesummary'] = '{$a->sent} sent, {$a->blocked} not permitted, {$a->failed} failed.';
$string['bulkmessageblocked'] = 'their privacy settings do not allow your message';
$string['bulkmessagefailed'] = 'delivery failed';
$string['bulkmessagenorecipients'] = 'The current filter returns no one to message.';
$string['bulkmessagetoomany'] = 'The filter returns {$a->count} recipients, over the limit of {$a->limit}. Narrow the filter, or raise the limit in the plugin settings.';
$string['messagingdisabled'] = 'Messaging is disabled on this site.';
$string['event_bulkmessagesent'] = 'Bulk message sent from Learning Analytics';

// Email modal v3.0.
$string['learninganalytics:sendmessage'] = 'Email a user from the dashboard';
$string['emailtitle'] = 'Send email';
$string['emailsubject'] = 'Subject';
$string['emailbody'] = 'Message';
$string['emailsend'] = 'Send email';
$string['emailrecipient'] = 'Will be sent to:';
$string['emailsentok'] = 'Email sent to {$a}.';
$string['emailsentfail'] = 'The email could not be sent. Check the site mail configuration.';
$string['emailnoaddress'] = 'This user has no email address on record.';
$string['emailempty'] = 'Both a subject and a message are required.';
$string['usernotinscope'] = 'That user is not part of the scope you are viewing.';
$string['event_emailsent'] = 'Email sent from Learning Analytics';
$string['messageroles'] = 'Roles that can email users';
$string['messageroles_desc'] = 'Grants <code>local/learninganalytics:sendmessage</code>, which allows sending an email to one user at a time from the dashboard.';
$string['emailsubject_course'] = 'Your progress in {$a}';
$string['emailbody_course'] = 'Hello {$a->name},

I am writing about your progress in "{$a->course}".

  Progress:        {$a->progress}%
  Grade:           {$a->grade}
  Last access:     {$a->lastaccess}
  Time in course:  {$a->timespent}

';
$string['emailsubject_general'] = 'A message about your learning';
$string['emailbody_general'] = 'Hello {$a->name},

  Last access: {$a->lastaccess}

';

// Email appearance v3.1.
$string['hdr_email'] = 'Email appearance';
$string['hdr_email_desc'] = 'Header, colour and footer of the emails sent from the dashboard.';
$string['emaillogo'] = 'Email logo';
$string['emaillogo_desc'] = 'Shown in the email header. PNG, JPG, GIF and SVG are accepted. Most email clients do not render SVG, so an uploaded SVG is converted to PNG automatically when a converter is available on the server; the conversion is cached and refreshed whenever the logo changes. If no converter is installed the SVG is sent as is, which some clients will not display. If left empty, the site logo is used when its format allows, and otherwise the site name is shown as text.';
$string['emaillogo_svgnote'] = 'An SVG logo is in use but the server has no SVG converter installed, so the logo will not appear in most email clients. Install <code>librsvg2-bin</code> on the server, or upload a PNG version instead.';
$string['emailaccent'] = 'Accent colour';
$string['emailaccent_desc'] = 'Hex colour of the header band and links, for example <code>#2a72b0</code>.';
$string['emailfooter'] = 'Footer text';
$string['emailfooter_desc'] = 'Optional text shown above the site name in the footer, for contact or legal notices.';

$string['emailresult_ok'] = 'Email sent';
$string['emailresult_fail'] = 'Could not send';

// Exports v3.4.
$string['exp_full'] = 'Download';
$string['exp_chartsblock'] = 'Charts only';
$string['exp_menulabel'] = 'Download {$a}';
$string['exp_kpis'] = 'Key figures';
$string['exp_coursekpis'] = 'Course key figures';
$string['exp_indicator'] = 'Indicator';
$string['exp_value'] = 'Value';
$string['exp_category'] = 'Category';
$string['exp_type'] = 'Type';
$string['exp_unknownformat'] = 'Unknown export format.';

$string['exp_workspace'] = 'Whole workspace';
$string['exp_tablesblock'] = 'Tables only';
$string['exp_aspdf'] = 'PDF (with charts)';
$string['exp_asxlsx'] = 'Excel (.xlsx)';
$string['exp_ascsv'] = 'CSV';

$string['bulkchannel'] = 'Send via';
$string['bulkchannel_help'] = 'Email arrives in the recipient\'s inbox with the site header and footer, and needs a subject. A Moodle message stays inside the platform and respects each user\'s messaging privacy settings.';
$string['bulkchannel_email'] = 'Email';
$string['bulkchannel_message'] = 'Moodle message';
$string['bulkmessagenoaddress'] = 'no email address on record';

// Licensing v3.8.
$string['hdr_licence'] = 'Licence';
$string['hdr_licence_desc'] = 'Without a licence the plugin shows the free metrics: user and certificate totals, user growth, top courses by enrolment, and CSV download. A licence unlocks filters, tables, the map, course analytics, messaging and the XLSX, PDF and JPG downloads. Licences are issued at <a href="https://www.algoritmot.com/learning_analytics" target="_blank">algoritmot.com/learning_analytics</a>.';
$string['lic_key'] = 'Activation code';
$string['lic_key_desc'] = 'Paste the code issued for this platform. Your site identifier is <code>{$a}</code> — quote it when requesting a licence.';
$string['lic_active'] = '<strong>Licence active</strong> — {$a->customer}. Valid until {$a->expires}.';
$string['lic_noexpiry'] = 'no expiry date';
$string['lic_reason_nocode'] = '<strong>Free version.</strong> No activation code entered.';
$string['lic_reason_invalid'] = '<strong>The code is not valid.</strong> Check that it was copied in full.';
$string['lic_reason_expired'] = '<strong>The licence has expired.</strong> Renew it to restore the full features.';
$string['lic_reason_wrongsite'] = '<strong>This code belongs to another platform.</strong> Request one for this site identifier.';
$string['lic_reason_revoked'] = '<strong>The licence was revoked.</strong> Contact Algoritmo T.';
$string['lic_required'] = 'This feature requires an active licence.';
$string['lic_upsell'] = 'You are using the free version: overall figures, user growth and top courses. Filters, tables, the map, course analytics, messaging and advanced downloads need a licence.';
$string['lic_activate'] = 'Activate';
$string['task_revalidate'] = 'Revalidate Learning Analytics licence';

// Metric definitions: what it measures, where it comes from, which rule applies.
$string['whatisthis'] = 'How this is calculated';
$string['generatedat'] = 'Data calculated at {$a}';
$string['def_growth'] = 'New users per month, based on when each account was created in Moodle (timecreated field). It counts sign-ups, not activity: a user created in March shows in March even if they never logged in.';
$string['def_domains'] = 'Users grouped by their email domain, taking whatever follows the at sign. Useful to tell which institution each group comes from.';
$string['def_countries'] = 'Country declared in each user Moodle profile. It is not inferred from the IP address: if the profile is empty, that user does not appear on the map.';
$string['def_activity'] = 'Users grouped by their last access to the platform, measured from today. "Never accessed" are accounts created that never logged in.';
$string['def_topcourses'] = 'Courses ranked by number of distinct enrolled users. A user with two enrolments in the same course counts once.';
$string['def_certificates'] = 'Certificates issued per month through the mod_customcert activity. If a course issues certificates by other means, they do not show here.';
$string['def_certsplit'] = 'How many users in scope have earned at least one certificate and how many none.';
$string['def_certrate'] = 'Percentage of users with at least one certificate over all users in scope. It is not the percentage of passed courses.';
$string['def_sections'] = 'Average completion percentage of the activities in each section, across the students of the course. Only activities with completion tracking enabled are counted.';
$string['def_activities'] = 'Percentage of students who completed each activity. An activity without completion tracking configured shows as zero.';
$string['def_activitygrades'] = 'Average grade of each gradable activity, out of 100. Only students who have a grade are included: those who have not submitted do not lower the average.';

// Conversational analytics. Queries are resolved by Algoritmo T, not by this
// platform: hence the quota and the note about what is sent.
$string['ai_heading'] = 'Ask about these figures';
$string['ai_intro'] = 'Type a question and it will be answered using the data on screen. Only the aggregated figures of the visible blocks are sent: no people, no email addresses.';
$string['ai_placeholder'] = 'For example: where is the biggest problem and what would you do first?';
$string['ai_ask'] = 'Ask';
$string['ai_asking'] = 'Asking…';
$string['ai_remaining'] = '{$a} queries left in your allowance.';
$string['ai_nodata'] = 'There is no chart with data on screen to ask about.';
$string['ai_notincluded'] = 'Conversational analytics is not enabled for this platform.';
$string['ai_unreachable'] = 'The service could not be reached. Please try again in a moment.';
$string['ai_failed'] = 'The query could not be resolved.';
$string['ai_disclaimer'] = 'Automatically generated from the figures shown. Check it before making a decision.';

// Per-chart explanation. Each one spends a query from the allowance, so the
// warning has to come before the spend.
$string['ai_explain'] = 'Explain with AI';
$string['ai_explainq'] = 'Explain in two or three sentences what this block shows and what is worth looking at.';
$string['ai_explaincost'] = 'Each explanation spends one query from your allowance. You have {$a} left. Continue?';
$string['ai_explainnote'] = 'One query spent from the allowance. {$a} left.';
$string['ai_empty'] = 'This block has no data to explain.';

// Report mode: same cost as a question, structured output.
$string['ai_mode_answer'] = 'Short answer';
$string['ai_mode_report'] = 'Detailed report';
$string['ai_reportplaceholder'] = 'What the report should cover. For example: platform status for Monday board meeting, focusing on drop-out.';
$string['ai_pdftitle'] = 'AI analysis';
