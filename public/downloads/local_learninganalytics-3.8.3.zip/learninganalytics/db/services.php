<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Web service function definitions.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_learninganalytics_get_report' => [
        'classname'     => 'local_learninganalytics\external\get_report',
        'description'   => 'Devuelve los datos analiticos del dashboard.',
        'type'          => 'read',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'local/learninganalytics:view',
    ],
    'local_learninganalytics_get_filters' => [
        'classname'     => 'local_learninganalytics\external\get_filters',
        'description'   => 'Devuelve las opciones de los filtros globales.',
        'type'          => 'read',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'local/learninganalytics:view',
    ],
    'local_learninganalytics_get_course_report' => [
        'classname'     => 'local_learninganalytics\external\get_course_report',
        'description'   => 'Analitica de un curso: progreso, calificaciones y permanencia.',
        'type'          => 'read',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'local/learninganalytics:view',
    ],
    'local_learninganalytics_send_email' => [
        'classname'     => 'local_learninganalytics\external\send_email',
        'description'   => 'Envia un correo a un usuario desde el tablero.',
        'type'          => 'write',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'local/learninganalytics:sendmessage',
    ],
    'local_learninganalytics_search_users' => [
        'classname'     => 'local_learninganalytics\external\search_users',
        'description'   => 'Autocompletado de usuarios para el filtro.',
        'type'          => 'read',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'local/learninganalytics:view',
    ],
];
