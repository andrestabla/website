<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Hook callback registration (PSR-14).
 *
 * Reemplaza el callback heredado local_*_before_footer(), deprecado en 4.4.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$callbacks = [
    [
        'hook'     => \core_user\hook\extend_bulk_user_actions::class,
        'callback' => [\local_learninganalytics\hook_callbacks::class, 'extend_bulk_user_actions'],
        'priority' => 0,
    ],
];
