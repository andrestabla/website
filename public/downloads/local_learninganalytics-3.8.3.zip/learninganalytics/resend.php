<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Destino de la accion masiva "Reenviar credenciales".
 *
 * Flujo nativo de Moodle: los IDs seleccionados llegan en $SESSION->bulk_users,
 * se confirma con un formulario real (sesskey validado) y se informa del
 * resultado por usuario. Nada de confirm() ni alert() de JavaScript.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/moodlelib.php');

use local_learninganalytics\local\config;

require_login();

$context = context_system::instance();
require_capability('local/learninganalytics:resendcredentials', $context);

$confirm = optional_param('confirm', 0, PARAM_BOOL);

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/learninganalytics/resend.php'));
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('resendcredentials', 'local_learninganalytics'));
$PAGE->set_heading(get_string('resendcredentials', 'local_learninganalytics'));

$returnurl = new moodle_url('/admin/user.php');
$userids = $SESSION->bulk_users ?? [];

echo $OUTPUT->header();

if (empty($userids)) {
    echo $OUTPUT->notification(
        get_string('resendnousers', 'local_learninganalytics'),
        \core\output\notification::NOTIFY_WARNING
    );
    echo $OUTPUT->continue_button($returnurl);
    echo $OUTPUT->footer();
    exit;
}

if (!$confirm) {
    // Pantalla de confirmacion.
    echo $OUTPUT->heading(get_string('resendcredentials', 'local_learninganalytics'), 3);
    echo html_writer::tag('p', get_string('resendconfirm', 'local_learninganalytics', count($userids)));
    echo html_writer::tag('p', get_string('resendconfirmdetail', 'local_learninganalytics'));

    $continueurl = new moodle_url('/local/learninganalytics/resend.php',
        ['confirm' => 1, 'sesskey' => sesskey()]);
    echo $OUTPUT->confirm(
        get_string('resendconfirm', 'local_learninganalytics', count($userids)),
        $continueurl,
        $returnurl
    );
    echo $OUTPUT->footer();
    exit;
}

require_sesskey();

$sender = config::credentials_sender();
$site = get_site();
$sent = $skipped = $failed = 0;
$messages = [];

foreach ($userids as $userid) {
    $user = $DB->get_record('user', ['id' => (int)$userid, 'deleted' => 0]);
    if (!$user) {
        continue;
    }

    // NUNCA convertir el metodo de autenticacion. La version anterior forzaba
    // auth = 'manual', desconectando de su directorio a cuentas SSO/LDAP de
    // forma permanente y silenciosa.
    if ($user->auth !== 'manual') {
        $skipped++;
        $messages[] = [
            'text' => get_string('resendskippedauth', 'local_learninganalytics', fullname($user)),
            'type' => \core\output\notification::NOTIFY_WARNING,
        ];
        continue;
    }

    // Flujo nativo: genera la contrasena, la envia y marca cambio obligatorio.
    // La contrasena no pasa por nuestro codigo ni se registra en ningun sitio.
    if (setnew_password_and_mail($user)) {
        set_user_preference('auth_forcepasswordchange', 1, $user);

        // Auditoria por la API de eventos: sin cuerpo de mensaje, sin contrasena.
        \local_learninganalytics\event\credentials_resent::create([
            'context'       => $context,
            'objectid'      => $user->id,
            'relateduserid' => $user->id,
        ])->trigger();

        $sent++;
        $messages[] = [
            'text' => get_string('resendsent', 'local_learninganalytics', fullname($user)),
            'type' => \core\output\notification::NOTIFY_SUCCESS,
        ];
    } else {
        $failed++;
        $messages[] = [
            'text' => get_string('resendfailed', 'local_learninganalytics', fullname($user)),
            'type' => \core\output\notification::NOTIFY_ERROR,
        ];
    }
}

// Consumir la seleccion para que no se reutilice por accidente.
unset($SESSION->bulk_users);

echo $OUTPUT->heading(get_string('resendresults', 'local_learninganalytics'), 3);

echo $OUTPUT->notification(
    get_string('resendsummary', 'local_learninganalytics', (object)[
        'sent' => $sent, 'skipped' => $skipped, 'failed' => $failed,
    ]),
    $sent > 0 ? \core\output\notification::NOTIFY_SUCCESS : \core\output\notification::NOTIFY_WARNING
);

foreach ($messages as $m) {
    echo $OUTPUT->notification($m['text'], $m['type']);
}

echo $OUTPUT->continue_button($returnurl);
echo $OUTPUT->footer();
