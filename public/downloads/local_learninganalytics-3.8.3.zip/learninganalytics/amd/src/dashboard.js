// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Learning Analytics dashboard.
 *
 * Sin CDN: Chart.js viene del nucleo de Moodle como core/chartjs.
 * Sin innerHTML con datos de usuario: todo se construye con textContent, de
 * modo que un apellido como <img src=x onerror=...> se muestra como texto.
 * Sin llamadas a servicios externos: la geolocalizacion por IP fue eliminada.
 *
 * @module     local_learninganalytics/dashboard
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import {call as fetchMany} from 'core/ajax';
import Chart from 'core/chartjs';
import {get_string as getString} from 'core/str';
import Notification from 'core/notification';
import Templates from 'core/templates';
import ModalSaveCancel from 'core/modal_save_cancel';
import ModalCancel from 'core/modal_cancel';
import ModalEvents from 'core/modal_events';
import * as WorldMap from 'local_learninganalytics/worldmap';

/** @type {Object<string, Chart>} Instancias de graficas vivas. */
const charts = {};

/** @type {HTMLElement} Raiz del dashboard. */
let root = null;

/** @type {number} Handle del debounce del autocompletado. */
let searchTimer = 0;

/** @type {Array} Ultimo conjunto de datos recibido, para exportar. */
let lastData = null;

/** @type {number} Contexto del ambito: plataforma, categoria o curso. */
let contextId = 0;

/** @type {Array} Arbol de categorias del ambito. */
let categoryTree = [];

/** @type {number} Raiz del arbol: 0 en plataforma, o la categoria del ambito. */
let rootCategory = 0;

/** @type {number} Categoria seleccionada en el nivel mas profundo. */
let selectedCategory = 0;

/** @type {boolean} Si el usuario puede escribir mensajes. */
let canMessage = false;

/** @type {string} Raiz del sitio, para construir enlaces. */
let wwwRoot = '';

/** @type {string} URL de la pagina de envio masivo. */
let bulkUrl = '';

/** @type {string} URL del punto de descarga. */
let exportUrl = '';

/** @type {Object} Datos del ultimo informe de curso, para prerrellenar. */
let courseData = null;

/** @type {Object<number, Object>} Filas por usuario, para prerrellenar. */
const rowIndex = {};

/**
 * Paleta accesible, estable entre temas claro y oscuro.
 *
 * @type {Array<string>}
 */
const PALETTE = [
    '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
    '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
];


/**
 * Lee los filtros actuales del formulario.
 *
 * @return {Object}
 */
const readFilters = () => {
    const filters = {
        courseid: 0, country: '', domain: '', estado: '', supervisor: '',
        startdate: 0, enddate: 0, userid: 0, search: '', roleid: 0,
        contextid: contextId, categoryid: selectedCategory
    };

    root.querySelectorAll('[data-filter]').forEach((el) => {
        const key = el.dataset.filter;
        const value = el.value;

        if (key === 'courseid' || key === 'roleid') {
            filters[key] = parseInt(value, 10) || 0;
        } else if (key === 'startdate' || key === 'enddate') {
            // Fecha local -> marca de tiempo en segundos.
            if (value) {
                const d = new Date(value + (key === 'enddate' ? 'T23:59:59' : 'T00:00:00'));
                filters[key] = Math.floor(d.getTime() / 1000);
            }
        } else {
            filters[key] = value;
        }
    });

    // El autocompletado guarda el id elegido en un data attribute.
    const search = root.querySelector('[data-filter="search"]');
    if (search && search.dataset.userid) {
        filters.userid = parseInt(search.dataset.userid, 10) || 0;
    }

    return filters;
};

/**
 * Muestra u oculta un filtro completo con su etiqueta.
 *
 * @param {string} name
 * @param {boolean} show
 */
const toggleFilter = (name, show) => {
    const el = root.querySelector(`[data-filter="${name}"]`);
    if (!el) {
        return;
    }
    const column = el.closest('[class*="col-"]');
    if (column) {
        column.hidden = !show;
    }
};

/**
 * Rellena un desplegable sin usar innerHTML.
 *
 * @param {string} selector
 * @param {Array} items
 * @param {string} allLabel
 */
const fillSelect = (selector, items, allLabel) => {
    const select = root.querySelector(selector);
    if (!select) {
        return;
    }

    select.textContent = '';

    const optAll = document.createElement('option');
    optAll.value = '';
    optAll.textContent = allLabel;
    select.appendChild(optAll);

    items.forEach((item) => {
        const opt = document.createElement('option');
        if (typeof item === 'object') {
            opt.value = String(item.id);
            opt.textContent = item.name;    // textContent: nunca interpreta HTML.
        } else {
            opt.value = item;
            opt.textContent = item;
        }
        select.appendChild(opt);
    });
};

/**
 * Muestra u oculta la tarjeta que contiene una grafica.
 *
 * El tablero refleja lo que existe en el ambito: una grafica sin datos se
 * retira en lugar de dejar unos ejes vacios.
 *
 * @param {string} name
 * @param {boolean} hasData
 */
const toggleChartCard = (name, hasData) => {
    const canvas = root.querySelector(`[data-chart="${name}"]`);
    if (!canvas) {
        return;
    }
    const column = canvas.closest('[class*="col-"]');
    if (column) {
        column.hidden = !hasData;
    }
};

/**
 * Muestra u oculta una tarjeta de indicador.
 *
 * @param {string} name
 * @param {boolean} show
 */
const toggleKpi = (name, show) => {
    const el = root.querySelector(`[data-kpi="${name}"]`);
    if (!el) {
        return;
    }
    const column = el.closest('[class*="col-"]');
    if (column) {
        column.hidden = !show;
    }
};

/**
 * Indica si una serie tiene algun valor util.
 *
 * @param {Object} series
 * @return {boolean}
 */
const hasSeriesData = (series) => {
    return Boolean(series && series.values && series.values.length
        && series.values.some((v) => v > 0));
};

/**
 * Dibuja o actualiza una grafica.
 *
 * @param {string} name
 * @param {string} type
 * @param {Object} series
 * @param {string} label
 */
const renderChart = (name, type, series, label, options = {}) => {
    const canvas = root.querySelector(`[data-chart="${name}"]`);
    if (!canvas || !series) {
        return;
    }

    if (charts[name]) {
        charts[name].destroy();
    }

    const horizontal = options.horizontal === true;
    const isRound = type === 'doughnut' || type === 'pie' || type === 'polarArea';

    charts[name] = new Chart(canvas.getContext('2d'), {
        type: type,
        data: {
            labels: series.labels,
            datasets: [{
                label: label,
                data: series.values,
                backgroundColor: type === 'line'
                    ? 'rgba(31, 119, 180, 0.18)'
                    : series.labels.map((_, i) => PALETTE[i % PALETTE.length]),
                borderColor: type === 'line' ? PALETTE[0] : 'rgba(255, 255, 255, 0.65)',
                borderWidth: type === 'line' ? 2 : 1,
                fill: type === 'line',
                tension: 0.35,
                pointRadius: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: horizontal ? 'y' : 'x',
            plugins: {
                legend: {
                    display: isRound,
                    position: isRound ? 'bottom' : 'top',
                    labels: {boxWidth: 12, font: {size: 11}}
                }
            },
            scales: isRound ? {} : {
                x: horizontal
                    ? {beginAtZero: true, ticks: {precision: 0}}
                    : {ticks: {autoSkip: true, maxRotation: 45, font: {size: 10}}},
                y: horizontal
                    ? {ticks: {font: {size: 10}}}
                    : {beginAtZero: true, ticks: {precision: 0}}
            }
        }
    });
};

/**
 * Dibuja el mapa coropletico de usuarios por pais.
 *
 * @param {Object} series labels, values, codes
 * @param {string} emptyLabel
 */
const renderMap = (series, emptyLabel) => {
    const canvas = root.querySelector('[data-chart="map"]');
    if (!canvas || !series) {
        return;
    }

    const tooltip = root.querySelector('[data-region="map-tooltip"]');
    WorldMap.render(canvas, series, tooltip, emptyLabel);
    renderLegend(series);
};

/**
 * Pinta la leyenda de la escala de color.
 *
 * @param {Object} series
 */
const renderLegend = (series) => {
    const box = root.querySelector('[data-region="map-legend"]');
    if (!box) {
        return;
    }

    box.textContent = '';
    const max = Math.max(1, ...series.values);

    WorldMap.legendSteps(max).forEach((step) => {
        const item = document.createElement('span');
        item.className = 'local-la-legend-item';

        const swatch = document.createElement('span');
        swatch.className = 'local-la-legend-swatch';
        swatch.style.backgroundColor = step.color;

        const text = document.createElement('span');
        text.textContent = step.from === step.to
            ? String(step.to)
            : step.from + '-' + step.to;

        item.appendChild(swatch);
        item.appendChild(text);
        box.appendChild(item);
    });
};

/**
 * Crea una celda de tabla con texto plano.
 *
 * @param {string} text
 * @return {HTMLTableCellElement}
 */
const cell = (text) => {
    const td = document.createElement('td');
    td.textContent = text === null || text === undefined ? '' : String(text);
    return td;
};

/**
 * Compone el cuerpo prerrellenado del correo.
 *
 * Se parte del progreso real del estudiante para que quien escribe no tenga
 * que ir a buscarlo: el mensaje ya nace con el contexto delante.
 *
 * @param {Object} row Fila del estudiante o del usuario.
 * @return {Promise<Object>} subject y body.
 */
const buildEmailDraft = async(row) => {
    const isCourse = Object.prototype.hasOwnProperty.call(row, 'progress');
    const coursename = (courseData && courseData.coursename) ? courseData.coursename : '';

    if (isCourse) {
        const [subject, body] = await Promise.all([
            getString('emailsubject_course', 'local_learninganalytics', coursename),
            getString('emailbody_course', 'local_learninganalytics', {
                name: row.fullname,
                course: coursename,
                progress: row.progress,
                grade: (row.grade === null || row.grade === undefined)
                    ? '-' : row.grade + '%',
                lastaccess: row.lastaccessformatted,
                timespent: row.timespentformatted
            })
        ]);
        return {subject: subject, body: body};
    }

    const [subject, body] = await Promise.all([
        getString('emailsubject_general', 'local_learninganalytics'),
        getString('emailbody_general', 'local_learninganalytics', {
            name: row.fullname,
            lastaccess: row.lastaccess
        })
    ]);

    return {subject: subject, body: body};
};

/**
 * Muestra el resultado del envio en un modal.
 *
 * @param {boolean} success
 * @param {string} message
 * @param {string} recipient
 * @return {Promise} Se resuelve cuando el modal se cierra.
 */
const showEmailResult = async(success, message, recipient) => {
    const modal = await ModalCancel.create({
        title: await getString(
            success ? 'emailresult_ok' : 'emailresult_fail',
            'local_learninganalytics'
        ),
        body: Templates.render('local_learninganalytics/email_result', {
            success: success,
            message: message,
            recipient: recipient || ''
        }),
        buttons: {cancel: await getString('ok', 'core')}
    });

    await modal.show();

    return new Promise((resolve) => {
        modal.getRoot().on(ModalEvents.hidden, resolve);
    });
};

/**
 * Abre el modal de redaccion y envia el correo al confirmar.
 *
 * @param {number} userid
 * @return {Promise}
 */
const openEmailModal = async(userid) => {
    const row = rowIndex[userid];
    if (!row) {
        return;
    }

    try {
        const draft = await buildEmailDraft(row);

        const modal = await ModalSaveCancel.create({
            title: await getString('emailtitle', 'local_learninganalytics'),
            body: Templates.render('local_learninganalytics/email_modal', {
                subject: draft.subject,
                body: draft.body,
                email: row.email,
                fullname: row.fullname
            }),
            buttons: {save: await getString('emailsend', 'local_learninganalytics')},
            large: true
        });

        modal.getRoot().on(ModalEvents.save, (e) => {
            // Se impide el cierre automatico hasta saber el resultado del envio.
            e.preventDefault();

            const rootEl = modal.getRoot()[0];
            const subject = rootEl.querySelector('[data-region="email-subject"]').value.trim();
            const body = rootEl.querySelector('[data-region="email-body"]').value.trim();

            if (!subject || !body) {
                return;
            }

            fetchMany([{
                methodname: 'local_learninganalytics_send_email',
                args: {contextid: contextId, userid: userid, subject: subject, body: body}
            }])[0].then((result) => {
                if (result.status) {
                    // Enviado: se cierra la redaccion y se confirma.
                    modal.hide();
                    modal.destroy();
                    return showEmailResult(true, result.message, row.fullname);
                }

                // Fallo: el modal de redaccion sigue abierto detras, de modo
                // que el texto escrito no se pierde y se puede reintentar.
                return showEmailResult(false, result.message, row.fullname);
            }).catch((error) => {
                const detail = (error && error.message)
                    ? error.message
                    : String(error);
                return showEmailResult(false, detail, row.fullname);
            });
        });

        modal.getRoot().on(ModalEvents.hidden, () => modal.destroy());

        await modal.show();
    } catch (error) {
        Notification.exception(error);
    }
};

/**
 * Crea la celda con la accion de enviar mensaje.
 *
 * Enlace directo a la mensajeria de Moodle, en una pestana nueva para no
 * perder los filtros aplicados.
 *
 * Se descarto abrir el cajon de mensajes con core_message/message_drawer_helper:
 * su API es asincrona, de modo que un try/catch no puede capturar su fallo y
 * el preventDefault se ejecutaba igualmente, dejando el boton sin efecto util
 * cuando el cajon fallaba. Un enlace normal no tiene ese problema.
 *
 * @param {number} userid
 * @param {string} fullname
 * @param {string} label
 * @return {HTMLTableCellElement}
 */
const messageCell = (userid, fullname, label) => {
    const td = document.createElement('td');
    const id = parseInt(userid, 10);

    if (!id) {
        return td;   // Sin id valido no se ofrece la accion.
    }

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn btn-sm btn-outline-primary local-la-message';
    button.dataset.emailuser = String(id);
    button.textContent = label;
    // El nombre va en el titulo accesible, no interpolado en HTML.
    button.title = label + ': ' + fullname;

    td.appendChild(button);

    return td;
};

/**
 * Pinta la tabla de usuarios.
 *
 * @param {Array} users
 * @param {Object} flags
 */
const renderUsers = (users, flags) => {
    const body = root.querySelector('[data-region="users-body"]');
    if (!body) {
        return;
    }

    body.textContent = '';

    users.forEach((u) => {
        rowIndex[u.id] = u;
        const tr = document.createElement('tr');
        tr.appendChild(cell(u.fullname));
        tr.appendChild(cell(u.email));
        tr.appendChild(cell(u.country));
        if (flags.hasestado) {
            tr.appendChild(cell(u.estado));
        }
        if (flags.hassupervisor) {
            tr.appendChild(cell(u.supervisor));
        }
        tr.appendChild(cell(u.lastaccess));
        if (canMessage) {
            tr.appendChild(messageCell(u.id, u.fullname, flags.messagelabel));
        }
        body.appendChild(tr);
    });
};

/**
 * Pinta la tabla de progreso.
 *
 * @param {Array} rows
 * @param {Object} strings
 */
const renderProgress = (rows, strings) => {
    const body = root.querySelector('[data-region="progress-body"]');
    if (!body) {
        return;
    }

    body.textContent = '';

    rows.forEach((r) => {
        const tr = document.createElement('tr');
        tr.appendChild(cell(r.fullname));
        tr.appendChild(cell(r.coursename));
        tr.appendChild(cell(strings[r.signed] || r.signed));
        body.appendChild(tr);
    });
};

/**
 * Carga los datos y repinta el dashboard.
 *
 * @return {Promise}
 */
const loadData = async() => {
    const filters = readFilters();

    try {
        // core/ajax.call() devuelve un array de promesas (una por peticion):
        // hay que esperar la promesa individual, no el array.
        const data = await fetchMany([{
            methodname: 'local_learninganalytics_get_report',
            args: filters
        }])[0];

        lastData = data;

        // KPIs.
        root.querySelector('[data-kpi="users"]').textContent = data.kpis.users;
        root.querySelector('[data-kpi="enrolments"]').textContent = data.kpis.enrolments;
        root.querySelector('[data-kpi="certificates"]').textContent = data.kpis.certificates;
        root.querySelector('[data-kpi="certrate"]').textContent = data.kpis.certrate + '%';

        // Graficas: cada serie con el tipo que mejor la representa.
        const [
            growthLabel, domainsLabel, countriesLabel, certsLabel,
            activityLabel, topLabel, splitLabel
        ] = await Promise.all([
            getString('chart_growth', 'local_learninganalytics'),
            getString('chart_domains', 'local_learninganalytics'),
            getString('chart_countries', 'local_learninganalytics'),
            getString('chart_certificates', 'local_learninganalytics'),
            getString('chart_activity', 'local_learninganalytics'),
            getString('chart_topcourses', 'local_learninganalytics'),
            getString('chart_certsplit', 'local_learninganalytics')
        ]);

        const zeroLabel = await getString('nousers', 'local_learninganalytics');

        // Cada grafica se muestra solo si el ambito tiene datos para ella.
        const mapHasData = hasSeriesData(data.countries);
        toggleChartCard('map', mapHasData);
        if (mapHasData) {
            renderMap(data.countries, zeroLabel);
        }

        toggleChartCard('growth', hasSeriesData(data.growth));
        if (hasSeriesData(data.growth)) {
            renderChart('growth', 'line', data.growth, growthLabel);
        }

        toggleChartCard('domains', hasSeriesData(data.domains));
        if (hasSeriesData(data.domains)) {
            renderChart('domains', 'doughnut', data.domains, domainsLabel);
        }

        toggleChartCard('countries', hasSeriesData(data.countries));
        if (hasSeriesData(data.countries)) {
            renderChart('countries', 'bar', data.countries, countriesLabel);
        }

        toggleChartCard('activity', hasSeriesData(data.activity));
        if (hasSeriesData(data.activity)) {
            renderChart('activity', 'bar', data.activity, activityLabel);
        }

        toggleChartCard('topcourses', hasSeriesData(data.topcourses));
        if (hasSeriesData(data.topcourses)) {
            renderChart('topcourses', 'bar', data.topcourses, topLabel, {horizontal: true});
        }

        // Certificados: solo si el ambito tiene actividades de certificado.
        toggleKpi('certificates', data.hascerts);
        toggleKpi('certrate', data.hascerts);
        toggleChartCard('certificates', data.hascerts && hasSeriesData(data.certificates));
        toggleChartCard('certsplit', data.hascerts && hasSeriesData(data.certsplit));

        if (data.hascerts) {
            if (hasSeriesData(data.certificates)) {
                renderChart('certificates', 'line', data.certificates, certsLabel);
            }
            if (hasSeriesData(data.certsplit)) {
                renderChart('certsplit', 'doughnut', data.certsplit, splitLabel);
            }
        }

        // Tablas.
        const [yes, no, na] = await Promise.all([
            getString('yes', 'local_learninganalytics'),
            getString('no', 'local_learninganalytics'),
            getString('notapplicable', 'local_learninganalytics')
        ]);

        const messageLabel = await getString('sendmessage', 'local_learninganalytics');
        renderUsers(data.users, Object.assign({messagelabel: messageLabel}, data));
        renderProgress(data.progress, {yes: yes, no: no, na: na});

        const empty = root.querySelector('[data-region="empty"]');
        if (empty) {
            empty.hidden = data.users.length > 0;
        }

        await attachExportMenus();
    } catch (error) {
        Notification.exception(error);
    }
};


/**
 * Cadena de ancestros de la categoria seleccionada, de la raiz hacia abajo.
 *
 * @return {Array<number>}
 */
const categoryChain = () => {
    const chain = [];
    let current = selectedCategory;

    while (current && current !== rootCategory) {
        chain.unshift(current);
        const cat = categoryTree.find((c) => c.id === current);
        current = cat ? cat.parent : 0;
    }

    return chain;
};

/**
 * Dibuja la cascada de categorias.
 *
 * Replica la estructura de course/management.php: un selector por nivel, y
 * al elegir una categoria aparece el selector de sus hijas. Los niveles mas
 * profundos desaparecen si se vuelve a "Todas".
 *
 * @return {Promise}
 */
const buildCascade = async() => {
    const box = root.querySelector('[data-region="category-cascade"]');
    if (!box || !categoryTree.length) {
        return;
    }

    box.textContent = '';
    const chain = categoryChain();
    const allLabel = await getString('filter_all', 'local_learninganalytics');

    let parent = rootCategory;
    let level = 0;

    for (;;) {
        const options = categoryTree.filter((c) => c.parent === parent);
        if (!options.length) {
            break;
        }

        const chosen = chain[level] || 0;
        const label = level === 0
            ? await getString('filter_category', 'local_learninganalytics')
            : await getString('filter_categorylevel', 'local_learninganalytics', level + 1);

        const col = document.createElement('div');
        col.className = 'col-md-3 mb-2';

        const lab = document.createElement('label');
        lab.setAttribute('for', 'la-cat-' + level);
        lab.textContent = label;

        const select = document.createElement('select');
        select.id = 'la-cat-' + level;
        select.className = 'custom-select w-100';
        select.dataset.catlevel = String(level);

        const optAll = document.createElement('option');
        optAll.value = '0';
        optAll.textContent = allLabel;
        select.appendChild(optAll);

        options.forEach((c) => {
            const opt = document.createElement('option');
            opt.value = String(c.id);
            opt.textContent = c.name;
            if (c.id === chosen) {
                opt.selected = true;
            }
            select.appendChild(opt);
        });

        col.appendChild(lab);
        col.appendChild(select);
        box.appendChild(col);

        if (!chosen) {
            break;   // Sin seleccion en este nivel no hay nivel siguiente.
        }

        parent = chosen;
        level++;
    }
};

/**
 * Responde al cambio de un selector de la cascada.
 *
 * @param {HTMLSelectElement} select
 * @return {Promise}
 */
const onCategoryChange = async(select) => {
    const level = parseInt(select.dataset.catlevel, 10);
    const value = parseInt(select.value, 10) || 0;
    const chain = categoryChain();

    // Al cambiar un nivel se descartan los niveles mas profundos.
    if (value) {
        selectedCategory = value;
    } else {
        selectedCategory = level > 0 ? (chain[level - 1] || rootCategory) : rootCategory;
    }

    if (selectedCategory === rootCategory) {
        selectedCategory = 0;
    }

    await buildCascade();
    await loadFilters();
    await loadData();
};

/**
 * Lee los filtros del panel de curso.
 *
 * @return {Object}
 */
const readCourseFilters = () => {
    const filters = {
        contextid: contextId, userid: 0, lastaccess: '', roleid: 0,
        progressmin: 0, progressmax: 100, grademin: 0, grademax: 100
    };

    root.querySelectorAll('[data-cfilter]').forEach((el) => {
        const key = el.dataset.cfilter;
        if (key === 'lastaccess') {
            filters[key] = el.value;
        } else if (key === 'userid' || key === 'roleid') {
            filters[key] = parseInt(el.value, 10) || 0;
        } else {
            const n = parseInt(el.value, 10);
            filters[key] = isNaN(n) ? filters[key] : n;
        }
    });

    return filters;
};

/**
 * Pinta la tabla de estudiantes del curso.
 *
 * @param {Array} students
 */
const renderCourseStudents = (students, messageLabel) => {
    const body = root.querySelector('[data-region="cstudents-body"]');
    if (!body) {
        return;
    }

    body.textContent = '';

    students.forEach((s) => {
        rowIndex[s.userid] = s;
        const tr = document.createElement('tr');
        tr.appendChild(cell(s.fullname));

        // Barra de progreso: se lee mejor que un numero suelto.
        const td = document.createElement('td');
        const bar = document.createElement('div');
        bar.className = 'local-la-bar';
        const fill = document.createElement('span');
        fill.style.width = Math.max(0, Math.min(100, s.progress)) + '%';
        bar.appendChild(fill);
        const num = document.createElement('span');
        num.className = 'local-la-bar-label';
        num.textContent = s.progress + '%';
        td.appendChild(bar);
        td.appendChild(num);
        tr.appendChild(td);

        tr.appendChild(cell(s.grade === null || s.grade === undefined ? '-' : s.grade + '%'));
        tr.appendChild(cell(s.lastaccessformatted));
        tr.appendChild(cell(s.timespentformatted));
        if (canMessage) {
            tr.appendChild(messageCell(s.userid, s.fullname, messageLabel));
        }
        body.appendChild(tr);
    });
};

/**
 * Pinta la tabla de actividades del curso.
 *
 * @param {Array} activities
 */
const renderCourseActivities = (activities) => {
    const body = root.querySelector('[data-region="cactivities-body"]');
    if (!body) {
        return;
    }

    body.textContent = '';

    activities.forEach((a) => {
        const tr = document.createElement('tr');
        tr.appendChild(cell(a.name));
        tr.appendChild(cell(a.sectionname));
        tr.appendChild(cell(a.completed));
        tr.appendChild(cell(a.progress + '%'));
        tr.appendChild(cell(a.average === null || a.average === undefined ? '-' : a.average + '%'));
        body.appendChild(tr);
    });
};

/**
 * Rellena el desplegable de estudiantes la primera vez.
 *
 * @param {Array} students
 */
const fillStudentFilter = (students) => {
    const select = root.querySelector('[data-cfilter="userid"]');
    if (!select || select.dataset.filled) {
        return;
    }
    select.dataset.filled = '1';

    fillSelect('[data-cfilter="userid"]', students.map((s) => ({id: s.userid, name: s.fullname})),
        select.dataset.allLabel || '');
};

/**
 * Carga y pinta el panel de curso.
 *
 * @return {Promise}
 */
const loadCourseData = async() => {
    const panel = root.querySelector('[data-region="course-panel"]');
    if (!panel) {
        return;
    }

    try {
        const data = await fetchMany([{
            methodname: 'local_learninganalytics_get_course_report',
            args: readCourseFilters()
        }])[0];

        const k = data.kpis;
        root.querySelector('[data-ckpi="students"]').textContent = k.students;
        root.querySelector('[data-ckpi="avgprogress"]').textContent = k.avgprogress + '%';
        root.querySelector('[data-ckpi="avggrade"]').textContent =
            k.gradedcount > 0 ? k.avggrade + '%' : '-';
        root.querySelector('[data-ckpi="avgtime"]').textContent = k.avgtimeformatted;

        const [secLabel, actLabel, gradeLabel] = await Promise.all([
            getString('chart_sections', 'local_learninganalytics'),
            getString('chart_activities', 'local_learninganalytics'),
            getString('chart_activitygrades', 'local_learninganalytics')
        ]);

        renderChart('csections', 'bar', data.sections, secLabel);

        renderChart('cactivities', 'bar', {
            labels: data.activities.map((a) => a.name),
            values: data.activities.map((a) => a.progress)
        }, actLabel, {horizontal: true});

        // Solo las actividades que realmente tienen nota.
        const graded = data.activities.filter((a) => a.average !== null && a.average !== undefined);
        renderChart('cgrades', 'bar', {
            labels: graded.map((a) => a.name),
            values: graded.map((a) => a.average)
        }, gradeLabel);

        const messageLabel = await getString('sendmessage', 'local_learninganalytics');
        courseData = data;
        renderCourseStudents(data.students, messageLabel);
        renderCourseActivities(data.activities);
        fillStudentFilter(data.students);

        // Avisos: decir por que falta un dato es mejor que dejar el hueco.
        const noCompletion = root.querySelector('[data-region="no-completion"]');
        if (noCompletion) {
            noCompletion.hidden = data.hascompletion;
        }
        const noGrades = root.querySelector('[data-region="no-grades"]');
        if (noGrades) {
            noGrades.hidden = graded.length > 0;
        }
        const capped = root.querySelector('[data-region="log-capped"]');
        if (capped) {
            capped.hidden = !data.logcapped;
        }

        await attachExportMenus();
    } catch (error) {
        Notification.exception(error);
    }
};

/**
 * Carga las opciones de los filtros.
 *
 * @return {Promise}
 */
const loadFilters = async() => {
    try {
        const data = await fetchMany([{
            methodname: 'local_learninganalytics_get_filters',
            args: {contextid: contextId, categoryid: selectedCategory}
        }])[0];

        const allLabel = await getString('filter_all', 'local_learninganalytics');

        // El arbol solo se guarda la primera vez: no cambia al filtrar.
        if (!categoryTree.length && data.categories && data.categories.length) {
            categoryTree = data.categories;
            rootCategory = data.rootcategory;
            await buildCascade();
        }

        fillSelect('[data-filter="courseid"]', data.courses, allLabel);
        fillSelect('[data-filter="country"]', data.countries, allLabel);
        fillSelect('[data-filter="domain"]', data.domains, allLabel);
        fillSelect('[data-filter="estado"]', data.estados, allLabel);
        fillSelect('[data-filter="supervisor"]', data.supervisores, allLabel);
        fillSelect('[data-filter="roleid"]', (data.roles || []).map(
            (r) => ({id: r.id, name: r.name + ' (' + r.count + ')'})), allLabel);
        fillSelect('[data-cfilter="roleid"]', (data.roles || []).map(
            (r) => ({id: r.id, name: r.name + ' (' + r.count + ')'})), allLabel);

        // Un filtro con una sola opcion posible no filtra nada: se retira.
        toggleFilter('courseid', data.courses.length > 1);
        toggleFilter('country', data.countries.length > 1);
        toggleFilter('domain', data.domains.length > 1);
        toggleFilter('estado', data.estados.length > 0);
        toggleFilter('supervisor', data.supervisores.length > 0);
        toggleFilter('roleid', (data.roles || []).length > 1);
    } catch (error) {
        Notification.exception(error);
    }
};

/**
 * Autocompletado de usuarios.
 *
 * @param {string} query
 */
const searchUsers = async(query) => {
    const box = root.querySelector('[data-region="suggestions"]');
    if (!box) {
        return;
    }

    if (query.length < 2) {
        box.hidden = true;
        box.textContent = '';
        return;
    }

    try {
        const results = await fetchMany([{
            methodname: 'local_learninganalytics_search_users',
            args: {query: query, contextid: contextId}
        }])[0];

        box.textContent = '';

        results.forEach((u) => {
            // createElement + textContent en lugar de innerHTML: un nombre con
            // etiquetas HTML se muestra literal, no se ejecuta.
            const item = document.createElement('button');
            item.type = 'button';
            item.className = 'local-la-suggestion';
            item.dataset.userid = String(u.id);

            const name = document.createElement('span');
            name.className = 'local-la-suggestion-name';
            name.textContent = u.label;

            const email = document.createElement('span');
            email.className = 'local-la-suggestion-email';
            email.textContent = u.email;

            item.appendChild(name);
            item.appendChild(email);
            box.appendChild(item);
        });

        box.hidden = results.length === 0;
    } catch (error) {
        Notification.exception(error);
    }
};

/**
 * Exporta la tabla visible a CSV, sin librerias externas.
 */
const exportCsv = () => {
    if (!lastData) {
        return;
    }

    const escape = (v) => '"' + String(v === null || v === undefined ? '' : v).replace(/"/g, '""') + '"';
    const rows = [['Name', 'Email', 'Country', 'Status', 'Supervisor', 'Last access']];

    lastData.users.forEach((u) => {
        rows.push([u.fullname, u.email, u.country, u.estado, u.supervisor, u.lastaccess]);
    });

    const csv = rows.map((r) => r.map(escape).join(',')).join('\r\n');
    const blob = new Blob(['﻿' + csv], {type: 'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = 'learning-analytics.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
};

/**
 * Lleva los filtros actuales a la pagina de envio masivo.
 *
 * Se envian los FILTROS, no la lista de destinatarios: el servidor la
 * recalcula aplicando capacidad y ambito, de modo que manipular el formulario
 * no permite alcanzar a nadie que no saliera ya en el tablero.
 *
 * @param {string} source report | course
 */
const goToBulkMessage = (source) => {
    if (!bulkUrl) {
        return;
    }

    const filters = source === 'course' ? readCourseFilters() : readFilters();

    const form = document.createElement('form');
    form.method = 'POST';
    form.action = bulkUrl;

    const add = (name, value) => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = name;
        input.value = String(value);
        form.appendChild(input);
    };

    Object.keys(filters).forEach((key) => add(key, filters[key]));
    add('source', source);
    add('sesskey', root.dataset.sesskey || '');

    document.body.appendChild(form);
    form.submit();
};

/**
 * Correspondencia entre objetivo de exportacion y lienzo de su grafica.
 *
 * @type {Object<string,string>}
 */
const TARGET_CANVAS = {
    growth: 'growth', domains: 'domains', countries: 'countries',
    activity: 'activity', topcourses: 'topcourses',
    certificates: 'certificates', certsplit: 'certsplit',
    csections: 'csections', cactivities: 'cactivities'
};

/**
 * Descarga un blob con el nombre indicado.
 *
 * @param {Blob} blob
 * @param {string} filename
 */
const downloadBlob = (blob, filename) => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
};

/**
 * Guarda una grafica como JPG a partir de su lienzo.
 *
 * Chart.js dibuja sobre un canvas, asi que la imagen se obtiene del propio
 * navegador sin ninguna libreria adicional. Se pinta antes un fondo blanco
 * porque JPG no admite transparencia y quedaria negro.
 *
 * @param {string} target
 */
const exportChartAsJpg = (target) => {
    const name = TARGET_CANVAS[target];
    const source = name ? root.querySelector(`[data-chart="${name}"]`) : null;

    if (!source) {
        return;
    }

    const canvas = document.createElement('canvas');
    canvas.width = source.width;
    canvas.height = source.height;

    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(source, 0, 0);

    canvas.toBlob((blob) => {
        if (blob) {
            downloadBlob(blob, 'learning-analytics-' + target + '.jpg');
        }
    }, 'image/jpeg', 0.92);
};

/**
 * Reune las imagenes de las graficas que correspondan al objetivo.
 *
 * @param {string} target
 * @return {Array<string>} PNG en data URI.
 */
const collectChartImages = (target) => {
    let names = [];

    if (target === 'all' || target === 'blockcharts') {
        names = Object.values(TARGET_CANVAS);
    } else if (target === 'blockcourse') {
        names = ['csections', 'cactivities'];
    } else if (TARGET_CANVAS[target]) {
        names = [TARGET_CANVAS[target]];
    }

    const images = [];

    names.forEach((name) => {
        const canvas = root.querySelector(`[data-chart="${name}"]`);
        // Solo las visibles: una grafica oculta por falta de datos no aporta.
        if (!canvas || !canvas.offsetParent) {
            return;
        }
        try {
            // El titulo sale del encabezado de la tarjeta, para que en el PDF
            // cada grafica se pueda identificar sin adivinar.
            const card = canvas.closest('.card');
            const heading = card ? card.querySelector('h3') : null;

            images.push({
                data: canvas.toDataURL('image/png'),
                title: heading ? heading.textContent.trim() : ''
            });
        } catch (e) {
            // Un lienzo no exportable no debe impedir el resto de la descarga.
        }
    });

    return images;
};

/**
 * Envia los filtros al punto de descarga y deja que el navegador reciba
 * el archivo.
 *
 * Se recalcula en el servidor a partir de los filtros, nunca de datos que
 * mande el navegador, de modo que la descarga respeta capacidad y ambito.
 *
 * @param {string} format csv | xlsx | pdf
 * @param {string} target
 */
const requestExport = (format, target) => {
    if (!exportUrl) {
        return;
    }

    const isCourseTarget = target.charAt(0) === 'c' && target !== 'countries';
    const filters = isCourseTarget || target === 'blockcourse'
        ? Object.assign({}, readFilters(), readCourseFilters())
        : readFilters();

    const form = document.createElement('form');
    form.method = 'POST';
    form.action = exportUrl;
    form.target = '_blank';

    const add = (name, value) => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = name;
        input.value = String(value);
        form.appendChild(input);
    };

    Object.keys(filters).forEach((key) => add(key, filters[key]));
    add('format', format);
    add('target', target);

    // El sesskey sale del atributo de la plantilla; M.cfg lo respalda por si
    // la pagina se sirviera desde una copia cacheada sin el atributo.
    const sesskey = root.dataset.sesskey
        || (window.M && window.M.cfg && window.M.cfg.sesskey)
        || '';
    add('sesskey', sesskey);

    if (format === 'pdf') {
        collectChartImages(target).forEach((chart, i) => {
            add('images[' + i + ']', chart.data);
            add('imagetitles[' + i + ']', chart.title);
        });
    }

    document.body.appendChild(form);
    form.submit();

    // El formulario NO se retira en el acto: con target="_blank" el navegador
    // serializa el cuerpo de forma asincrona, y quitarlo antes de tiempo
    // truncaba el POST. Al perderse los campos se perdia el sesskey, que es
    // el error que veia el usuario. Se retira mas tarde, ya enviado.
    window.setTimeout(() => {
        if (form.parentNode) {
            form.parentNode.removeChild(form);
        }
    }, 4000);
};

/**
 * Inserta el menu de descarga en cada tarjeta que tenga objetivo declarado.
 *
 * @return {Promise}
 */
const attachExportMenus = async() => {
    const holders = root.querySelectorAll('[data-exporttarget]');

    for (const holder of holders) {
        if (holder.dataset.exportready) {
            continue;
        }
        holder.dataset.exportready = '1';

        const target = holder.dataset.exporttarget;
        const label = await getString('exp_menulabel', 'local_learninganalytics',
            holder.dataset.exportname || target);

        const {html} = await Templates.renderForPromise(
            'local_learninganalytics/export_menu',
            {target: target, label: label, hasimage: Boolean(TARGET_CANVAS[target])}
        );

        Templates.appendNodeContents(holder, html, '');
    }
};

/**
 * Abre y cierra los desplegables del plugin.
 *
 * No se usa el data-toggle de Bootstrap a proposito: Moodle 4.5 trae
 * Bootstrap 4 (data-toggle) y las ramas posteriores migran a Bootstrap 5
 * (data-bs-toggle). Gestionarlo aqui hace que los menus funcionen igual en
 * cualquier tema y version, sin depender de que libreria haya cargada.
 *
 * @param {HTMLElement} button
 */
const toggleDropdown = (button) => {
    const menu = button.parentNode
        ? button.parentNode.querySelector('.dropdown-menu')
        : null;

    if (!menu) {
        return;
    }

    const open = menu.classList.contains('show');

    // Solo un menu abierto a la vez.
    closeAllDropdowns();

    if (!open) {
        menu.classList.add('show');
        button.setAttribute('aria-expanded', 'true');
    }
};

/**
 * Cierra todos los desplegables del plugin.
 */
const closeAllDropdowns = () => {
    if (!root) {
        return;
    }

    root.querySelectorAll('.dropdown-menu.show').forEach((menu) => {
        menu.classList.remove('show');
    });

    root.querySelectorAll('[data-la-dropdown]').forEach((button) => {
        button.setAttribute('aria-expanded', 'false');
    });
};

/**
 * Registra los manejadores de eventos.
 */
const registerListeners = () => {
    // Cerrar los menus al pulsar fuera de ellos.
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.local-la-export, .btn-group')) {
            closeAllDropdowns();
        }
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeAllDropdowns();
        }
    });

    root.addEventListener('click', (e) => {
        const dropdown = e.target.closest('[data-la-dropdown]');
        if (dropdown) {
            e.preventDefault();
            e.stopPropagation();
            toggleDropdown(dropdown);
            return;
        }

        const action = e.target.closest('[data-action]');
        if (action) {
            e.preventDefault();
            if (action.dataset.action === 'apply') {
                loadData();
            } else if (action.dataset.action === 'reset') {
                root.querySelectorAll('[data-filter]').forEach((el) => {
                    el.value = '';
                    delete el.dataset.userid;
                });
                selectedCategory = 0;
                buildCascade()
                    .then(loadFilters)
                    .then(loadData)
                    .catch(Notification.exception);
            } else if (action.dataset.action === 'export') {
                exportCsv();
            } else if (action.dataset.action === 'bulkmessage') {
                goToBulkMessage(action.dataset.source);
            } else if (action.dataset.action === 'capply') {
                loadCourseData();
            } else if (action.dataset.action === 'creset') {
                root.querySelectorAll('[data-cfilter]').forEach((el) => {
                    if (el.dataset.cfilter === 'progressmax' || el.dataset.cfilter === 'grademax') {
                        el.value = '100';
                    } else if (el.tagName === 'SELECT') {
                        el.value = '';
                    } else {
                        el.value = '0';
                    }
                });
                loadCourseData();
            }
            return;
        }

        const tab = e.target.closest('[data-tab]');
        if (tab) {
            e.preventDefault();
            root.querySelectorAll('[data-tab]').forEach((t) => t.classList.remove('active'));
            tab.classList.add('active');
            root.querySelector('[data-region="tab-users"]').hidden = tab.dataset.tab !== 'users';
            root.querySelector('[data-region="tab-progress"]').hidden = tab.dataset.tab !== 'progress';
            return;
        }

        const ctab = e.target.closest('[data-ctab]');
        if (ctab) {
            e.preventDefault();
            root.querySelectorAll('[data-ctab]').forEach((t) => t.classList.remove('active'));
            ctab.classList.add('active');
            root.querySelector('[data-region="ctab-students"]').hidden = ctab.dataset.ctab !== 'students';
            root.querySelector('[data-region="ctab-activities"]').hidden = ctab.dataset.ctab !== 'activities';
            return;
        }

        const exportBtn = e.target.closest('[data-export]');
        if (exportBtn) {
            e.preventDefault();
            closeAllDropdowns();
            const format = exportBtn.dataset.export;
            const target = exportBtn.dataset.target;
            if (format === 'jpg') {
                exportChartAsJpg(target);
            } else {
                requestExport(format, target);
            }
            return;
        }

        const emailBtn = e.target.closest('[data-emailuser]');
        if (emailBtn) {
            e.preventDefault();
            openEmailModal(parseInt(emailBtn.dataset.emailuser, 10));
            return;
        }

        const suggestion = e.target.closest('.local-la-suggestion');
        if (suggestion) {
            e.preventDefault();
            const input = root.querySelector('[data-filter="search"]');
            input.value = suggestion.querySelector('.local-la-suggestion-name').textContent;
            input.dataset.userid = suggestion.dataset.userid;
            root.querySelector('[data-region="suggestions"]').hidden = true;
            loadData();
        }
    });

    root.addEventListener('change', (e) => {
        const select = e.target.closest('[data-catlevel]');
        if (select) {
            onCategoryChange(select).catch(Notification.exception);
        }
    });

    const search = root.querySelector('[data-filter="search"]');
    if (search) {
        search.addEventListener('input', () => {
            delete search.dataset.userid;
            window.clearTimeout(searchTimer);
            searchTimer = window.setTimeout(() => searchUsers(search.value.trim()), 300);
        });
    }
};

/**
 * Punto de entrada.
 *
 * @param {Object} params
 * @param {number} params.contextid Contexto del ambito (0 = plataforma).
 */
export const init = (params) => {
    root = document.querySelector('[data-region="la-dashboard"]');
    if (!root) {
        return;
    }

    // El contexto llega desde index.php via js_call_amd; si faltara, se toma
    // del atributo de datos de la plantilla.
    contextId = (params && params.contextid)
        ? parseInt(params.contextid, 10)
        : parseInt(root.dataset.contextid || '0', 10);

    canMessage = root.dataset.canmessage === '1';
    wwwRoot = (params && params.wwwroot) ? params.wwwroot : '';
    bulkUrl = root.dataset.bulkurl || '';
    exportUrl = root.dataset.exporturl || '';

    registerListeners();
    loadFilters().then(loadData).catch(Notification.exception);

    // El panel de curso solo existe cuando el ambito es un curso.
    if (root.querySelector('[data-region="course-panel"]')) {
        loadCourseData();
    }
};
