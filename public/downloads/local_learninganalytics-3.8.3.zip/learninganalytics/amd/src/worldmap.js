// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Mapa coropletico de usuarios por pais.
 *
 * Dibuja geometria real de fronteras sobre un canvas propio, con proyeccion
 * equirectangular, escala de color secuencial y deteccion de pais bajo el
 * cursor. No usa Leaflet ni mosaicos: todo el dibujo es local, asi que
 * funciona con CSP estricta y sin salida a internet.
 *
 * @module     local_learninganalytics/worldmap
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import WORLD from 'local_learninganalytics/worlddata';

/** Latitud maxima representada; por encima solo hay hielo y distorsion. */
const LAT_MAX = 83;

/** Latitud minima; recorta la Antartida, que nunca aporta datos. */
const LAT_MIN = -56;

/**
 * Escala secuencial de azules, de menor a mayor densidad.
 *
 * @type {Array<string>}
 */
const SCALE = ['#d6e6f4', '#adcde9', '#7fb0da', '#4f92c8', '#2a72b0', '#155293'];

/** Relleno de los paises sin datos. */
const EMPTY_FILL = '#eef1f4';

/** Color de las fronteras. */
const STROKE = '#ffffff';

/** Fondo del oceano. */
const OCEAN = '#f7fbfd';

/**
 * Estado interno de cada mapa creado, indexado por canvas.
 *
 * @type {WeakMap}
 */
const instances = new WeakMap();

/**
 * Calcula la transformacion que encaja el mundo en el canvas.
 *
 * @param {number} width
 * @param {number} height
 * @return {Object}
 */
const makeProjection = (width, height) => {
    const lonSpan = 360;
    const latSpan = LAT_MAX - LAT_MIN;
    // Escala uniforme en ambos ejes: sin esto los paises salen deformados.
    const scale = Math.min(width / lonSpan, height / latSpan);
    const offsetX = (width - lonSpan * scale) / 2;
    const offsetY = (height - latSpan * scale) / 2;

    return {
        x: (lon) => offsetX + (lon + 180) * scale,
        y: (lat) => offsetY + (LAT_MAX - lat) * scale
    };
};

/**
 * Devuelve el color correspondiente a un valor.
 *
 * @param {number} value
 * @param {number} max
 * @return {string}
 */
const colorFor = (value, max) => {
    if (!value) {
        return EMPTY_FILL;
    }
    // Escala raiz: con un pais dominante, la lineal dejaria al resto invisible.
    const ratio = Math.sqrt(value) / Math.sqrt(max);
    const index = Math.min(SCALE.length - 1, Math.floor(ratio * SCALE.length));
    return SCALE[index];
};

/**
 * Comprueba si un punto cae dentro de un anillo (algoritmo par-impar).
 *
 * @param {Array<number>} ring Coordenadas aplanadas [x,y,x,y,...].
 * @param {number} px
 * @param {number} py
 * @return {boolean}
 */
const pointInRing = (ring, px, py) => {
    let inside = false;
    const n = ring.length / 2;

    for (let i = 0, j = n - 1; i < n; j = i++) {
        const xi = ring[i * 2];
        const yi = ring[i * 2 + 1];
        const xj = ring[j * 2];
        const yj = ring[j * 2 + 1];

        if (((yi > py) !== (yj > py))
                && (px < (xj - xi) * (py - yi) / (yj - yi) + xi)) {
            inside = !inside;
        }
    }

    return inside;
};

/**
 * Dibuja el mapa completo.
 *
 * @param {HTMLCanvasElement} canvas
 * @param {Object} state
 */
const draw = (canvas, state) => {
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;

    if (!width || !height) {
        return;
    }

    // Sin esto el mapa se ve borroso en pantallas de alta densidad.
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const proj = makeProjection(width, height);
    state.projection = proj;

    ctx.fillStyle = OCEAN;
    ctx.fillRect(0, 0, width, height);

    ctx.lineWidth = 0.6;
    ctx.strokeStyle = STROKE;
    ctx.lineJoin = 'round';

    WORLD.forEach(([iso, rings]) => {
        const value = state.values[iso] || 0;
        const isHover = state.hover === iso;

        ctx.fillStyle = isHover ? '#0f3d6e' : colorFor(value, state.max);

        rings.forEach((ring) => {
            ctx.beginPath();
            for (let i = 0; i < ring.length; i += 2) {
                const px = proj.x(ring[i]);
                const py = proj.y(ring[i + 1]);
                if (i === 0) {
                    ctx.moveTo(px, py);
                } else {
                    ctx.lineTo(px, py);
                }
            }
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
        });
    });
};

/**
 * Encuentra el pais bajo unas coordenadas de pantalla.
 *
 * @param {Object} state
 * @param {number} px
 * @param {number} py
 * @return {string|null}
 */
const countryAt = (state, px, py) => {
    const proj = state.projection;
    if (!proj) {
        return null;
    }

    // Invertir la proyeccion es mas barato que proyectar 10.000 vertices.
    const lon = ((px - proj.x(-180)) / (proj.x(180) - proj.x(-180))) * 360 - 180;
    const lat = LAT_MAX - ((py - proj.y(LAT_MAX)) / (proj.y(LAT_MIN) - proj.y(LAT_MAX))) * (LAT_MAX - LAT_MIN);

    let found = null;

    WORLD.forEach(([iso, rings]) => {
        if (found) {
            return;
        }
        for (let i = 0; i < rings.length; i++) {
            if (pointInRing(rings[i], lon, lat)) {
                found = iso;
                return;
            }
        }
    });

    return found;
};

/**
 * Crea o actualiza el mapa de un canvas.
 *
 * @param {HTMLCanvasElement} canvas
 * @param {Object} series labels, values, codes
 * @param {HTMLElement} tooltip Elemento donde mostrar el detalle.
 * @param {string} emptyLabel Texto para paises sin datos.
 */
export const render = (canvas, series, tooltip, emptyLabel) => {
    const values = {};
    const names = {};

    (series.codes || []).forEach((code, i) => {
        values[code] = series.values[i];
        names[code] = series.labels[i];
    });

    const state = {
        values: values,
        names: names,
        max: Math.max(1, ...series.values),
        hover: null,
        projection: null
    };

    instances.set(canvas, state);
    draw(canvas, state);

    if (canvas.dataset.laBound) {
        return;
    }
    canvas.dataset.laBound = '1';

    canvas.addEventListener('mousemove', (e) => {
        const current = instances.get(canvas);
        if (!current) {
            return;
        }

        const rect = canvas.getBoundingClientRect();
        const iso = countryAt(current, e.clientX - rect.left, e.clientY - rect.top);

        if (iso !== current.hover) {
            current.hover = iso;
            draw(canvas, current);
        }

        if (iso && tooltip) {
            const count = current.values[iso] || 0;
            // textContent, nunca innerHTML: el nombre viene del servidor pero
            // la regla del plugin es no interpretar HTML en datos.
            tooltip.textContent = (current.names[iso] || iso) + ': '
                + (count || emptyLabel);
            tooltip.style.left = (e.clientX - rect.left + 12) + 'px';
            tooltip.style.top = (e.clientY - rect.top + 12) + 'px';
            tooltip.hidden = false;
        } else if (tooltip) {
            tooltip.hidden = true;
        }
    });

    canvas.addEventListener('mouseleave', () => {
        const current = instances.get(canvas);
        if (current && current.hover) {
            current.hover = null;
            draw(canvas, current);
        }
        if (tooltip) {
            tooltip.hidden = true;
        }
    });

    // Redibujar al cambiar el tamano del contenedor.
    if (window.ResizeObserver) {
        const observer = new window.ResizeObserver(() => {
            const current = instances.get(canvas);
            if (current) {
                draw(canvas, current);
            }
        });
        observer.observe(canvas);
    }
};

/**
 * Devuelve los tramos de la leyenda para un maximo dado.
 *
 * @param {number} max
 * @return {Array<Object>}
 */
export const legendSteps = (max) => {
    return SCALE.map((color, i) => {
        const lower = Math.round(Math.pow(i / SCALE.length, 2) * max);
        const upper = Math.round(Math.pow((i + 1) / SCALE.length, 2) * max);
        return {color: color, from: lower, to: upper};
    });
};
