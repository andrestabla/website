<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\task;

use local_learninganalytics\local\licence;

/**
 * Revalida la licencia contra el ecosistema de Algoritmo T.
 *
 * Solo sirve para detectar revocaciones. Si el servicio no responde, la
 * licencia sigue como esta: una caida de red o un cliente sin salida a
 * internet no debe dejarle sin el producto que pago.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class revalidate_licence extends \core\task\scheduled_task {

    /**
     * @return string
     */
    public function get_name(): string {
        return get_string('task_revalidate', 'local_learninganalytics');
    }

    /**
     * Ejecuta la revalidacion.
     */
    public function execute(): void {
        global $CFG;

        $status = licence::get_status();

        // Sin codigo, o con uno que ni siquiera esta bien firmado, no hay nada
        // que revalidar: eso ya se resuelve en local.
        if ($status->licenceid === '') {
            return;
        }

        require_once($CFG->libdir . '/filelib.php');

        $payload = json_encode([
            'licence' => $status->licenceid,
            'site'    => licence::site_hash(),
            'version' => get_config('local_learninganalytics', 'version'),
        ]);

        $curl = new \curl(['ignoresecurity' => false]);
        $response = $curl->post(licence::VALIDATE_URL, $payload, [
            'CURLOPT_HTTPHEADER'     => ['Content-Type: application/json'],
            'CURLOPT_TIMEOUT'        => 15,
            'CURLOPT_CONNECTTIMEOUT' => 8,
            'CURLOPT_FOLLOWLOCATION' => 0,
        ]);

        $info = $curl->get_info();
        $httpcode = (int)($info['http_code'] ?? 0);

        if ($curl->get_errno() || $httpcode !== 200) {
            // Servicio inaccesible: se deja el estado intacto y se registra.
            mtrace('Learning Analytics: no se pudo revalidar la licencia (HTTP '
                . $httpcode . '). Se mantiene el estado actual.');
            set_config('licencelastcheck', time(), 'local_learninganalytics');
            return;
        }

        $data = json_decode($response, true);

        if (!is_array($data) || !isset($data['status'])) {
            mtrace('Learning Analytics: respuesta de revalidacion no reconocida.');
            return;
        }

        // Solo una revocacion explicita desactiva la licencia.
        if ($data['status'] === 'revoked') {
            set_config('licencerevoked', 1, 'local_learninganalytics');
            mtrace('Learning Analytics: la licencia ' . $status->licenceid . ' fue revocada.');
        } else {
            unset_config('licencerevoked', 'local_learninganalytics');
            mtrace('Learning Analytics: licencia vigente.');
        }

        set_config('licencelastcheck', time(), 'local_learninganalytics');
    }
}
