<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\form;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/formslib.php');

/**
 * Formulario de envio masivo.
 *
 * Los filtros viajan como campos ocultos y el servidor recalcula con ellos la
 * lista de destinatarios: nunca se confia en una lista de ids enviada por el
 * navegador, que podria manipularse para alcanzar a otras personas.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class bulkmessage_form extends \moodleform {

    /**
     * Define los campos.
     */
    public function definition(): void {
        $mform = $this->_form;
        $hidden = $this->_customdata['hidden'] ?? [];

        foreach ($hidden as $name => $value) {
            $mform->addElement('hidden', $name, $value);
            $mform->setType($name, is_int($value) ? PARAM_INT : PARAM_RAW);
        }

        $mform->addElement('hidden', 'confirm', 1);
        $mform->setType('confirm', PARAM_BOOL);

        // Canal: cada envio decide si sale por correo o por mensajeria interna.
        $mform->addElement('select', 'channel',
            get_string('bulkchannel', 'local_learninganalytics'), [
                'email'   => get_string('bulkchannel_email', 'local_learninganalytics'),
                'message' => get_string('bulkchannel_message', 'local_learninganalytics'),
            ]);
        $mform->setDefault('channel', 'email');
        $mform->addHelpButton('channel', 'bulkchannel', 'local_learninganalytics');

        // El asunto solo existe en el correo: un mensaje interno de Moodle no
        // tiene asunto, asi que el campo se oculta al elegir ese canal.
        $mform->addElement('text', 'subject',
            get_string('emailsubject', 'local_learninganalytics'), ['size' => 60]);
        $mform->setType('subject', PARAM_TEXT);
        $mform->hideIf('subject', 'channel', 'neq', 'email');

        $mform->addElement('textarea', 'messagetext',
            get_string('bulkmessagetext', 'local_learninganalytics'),
            ['rows' => 8, 'cols' => 60, 'style' => 'width:100%;']);
        $mform->setType('messagetext', PARAM_TEXT);
        $mform->addRule('messagetext', get_string('required'), 'required', null, 'client');
        $mform->addHelpButton('messagetext', 'bulkmessagetext', 'local_learninganalytics');

        $this->add_action_buttons(true, get_string('bulkmessagesend', 'local_learninganalytics'));
    }

    /**
     * Valida el contenido.
     *
     * @param array $data
     * @param array $files
     * @return array
     */
    public function validation($data, $files): array {
        $errors = parent::validation($data, $files);

        if (trim($data['messagetext'] ?? '') === '') {
            $errors['messagetext'] = get_string('required');
        }

        // Un correo sin asunto llega como spam a muchos filtros.
        if (($data['channel'] ?? '') === 'email' && trim($data['subject'] ?? '') === '') {
            $errors['subject'] = get_string('required');
        }

        return $errors;
    }
}
