<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\admin;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/adminlib.php');

/**
 * Ajuste que traduce una seleccion de roles a capacidades reales de Moodle.
 *
 * Da un front parametrizable ("quien puede ver los tableros") sin inventar un
 * sistema de permisos paralelo: al guardar, asigna o retira la capacidad en la
 * definicion de cada rol. Asi require_capability() sigue siendo la unica
 * fuente de verdad y quien prefiera la interfaz nativa de Roles puede usarla.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class setting_roles extends \admin_setting_configmulticheckbox {

    /** @var string Capacidad que se concede o retira. */
    protected $capability;

    /**
     * @param string $name Nombre del ajuste.
     * @param string $visiblename
     * @param string $description
     * @param string $capability Capacidad a gestionar.
     * @param array $defaultroles Shortnames de rol activos por defecto.
     */
    public function __construct($name, $visiblename, $description, $capability, array $defaultroles = []) {
        $this->capability = $capability;

        $defaults = [];
        foreach ($defaultroles as $shortname) {
            $defaults[$shortname] = 1;
        }

        parent::__construct($name, $visiblename, $description, $defaults, null);
    }

    /**
     * Carga los roles del sitio como opciones.
     *
     * @return bool
     */
    public function load_choices() {
        global $DB;

        if (is_array($this->choices)) {
            return true;
        }

        $this->choices = [];

        try {
            $roles = role_get_names(\context_system::instance(), ROLENAME_ORIGINAL);
        } catch (\Throwable $e) {
            return false;   // Durante la instalacion puede no haber roles todavia.
        }

        foreach ($roles as $role) {
            // Los roles que no pueden asignarse en ningun contexto util se omiten.
            if (in_array($role->shortname, ['guest', 'frontpage'], true)) {
                continue;
            }
            $this->choices[$role->shortname] = $role->localname;
        }

        return true;
    }

    /**
     * Guarda la seleccion y sincroniza las capacidades.
     *
     * @param array $data
     * @return string Cadena vacia si todo fue bien.
     */
    public function write_setting($data) {
        $result = parent::write_setting($data);

        if ($result === '') {
            $this->sync_capabilities();
        }

        return $result;
    }

    /**
     * Aplica la seleccion guardada a las definiciones de rol.
     */
    protected function sync_capabilities(): void {
        global $DB;

        if (!$this->load_choices()) {
            return;
        }

        $selected = $this->get_setting();
        $selected = is_array($selected) ? $selected : [];
        $syscontext = \context_system::instance();

        foreach ($this->choices as $shortname => $unused) {
            $roleid = $DB->get_field('role', 'id', ['shortname' => $shortname]);
            if (!$roleid) {
                continue;
            }

            $wanted = !empty($selected[$shortname]);

            if ($wanted) {
                // La capacidad se define a nivel de sistema en el rol: quien
                // tenga el rol en un curso la obtiene en ese curso, y quien lo
                // tenga en el sistema la obtiene en toda la plataforma.
                assign_capability($this->capability, CAP_ALLOW, $roleid, $syscontext->id, true);
            } else {
                unassign_capability($this->capability, $roleid, $syscontext->id, false);
            }
        }

        // Sin esto los cambios no se ven hasta que caduque la cache de accesos.
        $syscontext->mark_dirty();
        \core\session\manager::gc();
    }
}
