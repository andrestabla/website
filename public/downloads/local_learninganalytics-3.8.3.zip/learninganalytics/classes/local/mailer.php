<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

/**
 * Composicion del correo con cabecera, cuerpo y pie.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mailer {

    /** Area de archivos del logo para correo. */
    const LOGO_FILEAREA = 'emaillogo';

    /** Area donde se guarda la version PNG generada a partir de un SVG. */
    const LOGO_PNG_FILEAREA = 'emaillogopng';

    /** Altura en pixeles del PNG generado (doble para pantallas densas). */
    const LOGO_PNG_HEIGHT = 88;

    /** Rutas donde buscar el rasterizador de SVG. */
    const RSVG_PATHS = ['/usr/bin/rsvg-convert', '/usr/local/bin/rsvg-convert'];

    /**
     * URL absoluta del logo apto para correo, o null si no hay ninguno.
     *
     * Cadena de preferencia:
     *   1. El logo propio del plugin. Si es SVG, se usa su version PNG, porque
     *      Gmail y Outlook no pintan SVG; la conversion se cachea.
     *   2. El logo del sitio (core_admin), si su formato sirve para correo.
     *   3. Ninguno: la cabecera muestra el nombre del sitio como texto.
     *
     * @return string|null
     */
    public static function get_logo_url(): ?string {
        global $OUTPUT;

        $file = self::get_logo_file();

        if ($file) {
            if (self::is_email_safe_image($file->get_filename())) {
                return self::file_url($file);
            }

            // Es SVG: se sirve su conversion a PNG si se puede obtener.
            $png = self::get_or_make_png($file);
            if ($png) {
                return self::file_url($png);
            }

            // Sin conversor disponible se envia el SVG igualmente: los clientes
            // que lo soportan lo mostraran, y el resto vera el texto alternativo.
            return self::file_url($file);
        }

        $sitelogo = $OUTPUT->get_logo_url(null, 150);
        if ($sitelogo) {
            $url = $sitelogo->out(false);
            if (self::is_email_safe_image($url)) {
                return $url;
            }
        }

        return null;
    }

    /**
     * Archivo de logo subido en los ajustes del plugin, o null.
     *
     * @return \stored_file|null
     */
    protected static function get_logo_file(): ?\stored_file {
        $fs = get_file_storage();
        $files = $fs->get_area_files(\context_system::instance()->id,
            'local_learninganalytics', self::LOGO_FILEAREA, 0, 'itemid', false);

        return $files ? reset($files) : null;
    }

    /**
     * URL publica de un archivo almacenado.
     *
     * @param \stored_file $file
     * @return string
     */
    protected static function file_url(\stored_file $file): string {
        return \moodle_url::make_pluginfile_url(
            $file->get_contextid(), $file->get_component(), $file->get_filearea(),
            $file->get_itemid(), $file->get_filepath(), $file->get_filename())->out(false);
    }

    /**
     * Ruta del rasterizador de SVG, o null si no hay ninguno instalado.
     *
     * @return string|null
     */
    public static function get_converter(): ?string {
        foreach (self::RSVG_PATHS as $path) {
            if (is_executable($path)) {
                return $path;
            }
        }

        return null;
    }

    /**
     * Devuelve el PNG generado a partir de un SVG, creandolo si hace falta.
     *
     * El nombre del PNG lleva el contenthash del SVG original, de modo que al
     * cambiar el logo se genera uno nuevo y no se sirve el anterior.
     *
     * @param \stored_file $svg
     * @return \stored_file|null
     */
    protected static function get_or_make_png(\stored_file $svg): ?\stored_file {
        $fs = get_file_storage();
        $context = \context_system::instance();
        $filename = $svg->get_contenthash() . '.png';

        $existing = $fs->get_file($context->id, 'local_learninganalytics',
            self::LOGO_PNG_FILEAREA, 0, '/', $filename);

        if ($existing) {
            return $existing;
        }

        $converter = self::get_converter();
        if (!$converter) {
            return null;
        }

        $tempdir = make_request_directory();
        $svgpath = $tempdir . '/logo.svg';
        $pngpath = $tempdir . '/logo.png';

        file_put_contents($svgpath, $svg->get_content());

        // Solo se ejecuta un binario conocido y con argumentos entrecomillados.
        $command = escapeshellcmd($converter)
            . ' -h ' . (int)self::LOGO_PNG_HEIGHT
            . ' -f png -o ' . escapeshellarg($pngpath)
            . ' ' . escapeshellarg($svgpath) . ' 2>/dev/null';

        exec($command, $output, $status);

        if ($status !== 0 || !file_exists($pngpath) || filesize($pngpath) === 0) {
            return null;
        }

        // Se limpian conversiones anteriores: solo interesa la del logo actual.
        $fs->delete_area_files($context->id, 'local_learninganalytics',
            self::LOGO_PNG_FILEAREA);

        return $fs->create_file_from_pathname([
            'contextid' => $context->id,
            'component' => 'local_learninganalytics',
            'filearea'  => self::LOGO_PNG_FILEAREA,
            'itemid'    => 0,
            'filepath'  => '/',
            'filename'  => $filename,
        ], $pngpath);
    }

    /**
     * Indica si un nombre de archivo es una imagen que los clientes de correo
     * pintan de forma fiable.
     *
     * @param string $filename
     * @return bool
     */
    protected static function is_email_safe_image(string $filename): bool {
        $extension = \core_text::strtolower(pathinfo(parse_url($filename, PHP_URL_PATH) ?: $filename,
            PATHINFO_EXTENSION));

        return in_array($extension, ['png', 'jpg', 'jpeg', 'gif'], true);
    }

    /**
     * Compone el cuerpo HTML completo del correo.
     *
     * @param string $plaintext Texto que escribio la persona.
     * @return string
     */
    public static function render_html(string $plaintext): string {
        global $OUTPUT, $CFG;

        $site = get_site();
        $accent = trim((string)get_config('local_learninganalytics', 'emailaccent'));
        if ($accent === '' || !preg_match('/^#[0-9a-fA-F]{6}$/', $accent)) {
            $accent = '#2a72b0';
        }

        $logourl = self::get_logo_url();

        // s() escapa el texto y solo despues se insertan los saltos de linea:
        // lo que escriba una persona nunca se interpreta como marcado.
        $bodyhtml = nl2br(s($plaintext));

        return $OUTPUT->render_from_template('local_learninganalytics/email_body', [
            'accent'       => $accent,
            'haslogo'      => (bool)$logourl,
            'logourl'      => $logourl ?? '',
            'sitename'     => format_string($site->fullname),
            'siteurl'      => $CFG->wwwroot,
            'bodyhtml'     => $bodyhtml,
            'footertext'   => trim((string)get_config('local_learninganalytics', 'emailfooter')),
            'supportemail' => $CFG->supportemail ?? '',
            'year'         => userdate(time(), '%Y'),
        ]);
    }
}
