<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

/**
 * Resuelve el ambito del dashboard: plataforma, categoria o curso.
 *
 * El mismo dashboard sirve a los tres niveles. El contexto determina que
 * cursos entran en el informe y contra que contexto se comprueba la capacidad,
 * de modo que un profesor solo ve los datos de su curso.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class scope {

    /** Nivel plataforma. */
    const LEVEL_SITE = 'site';

    /** Nivel categoria. */
    const LEVEL_CATEGORY = 'category';

    /** Nivel curso. */
    const LEVEL_COURSE = 'course';

    /** @var \context */
    protected $context;

    /** @var string */
    protected $level;

    /** @var int Id de la categoria o curso; 0 en plataforma. */
    protected $instanceid;

    /**
     * @param \context $context
     */
    protected function __construct(\context $context) {
        $this->context = $context;

        if ($context instanceof \context_course && $context->instanceid != SITEID) {
            $this->level = self::LEVEL_COURSE;
            $this->instanceid = (int)$context->instanceid;
        } else if ($context instanceof \context_coursecat) {
            $this->level = self::LEVEL_CATEGORY;
            $this->instanceid = (int)$context->instanceid;
        } else {
            $this->level = self::LEVEL_SITE;
            $this->instanceid = 0;
        }
    }

    /**
     * Construye el ambito a partir de un contextid; 0 o invalido = plataforma.
     *
     * @param int $contextid
     * @return self
     */
    public static function from_contextid(int $contextid): self {
        if ($contextid <= 0) {
            return new self(\context_system::instance());
        }

        try {
            $context = \context::instance_by_id($contextid, MUST_EXIST);
        } catch (\Exception $e) {
            $context = \context_system::instance();
        }

        // Solo se admiten estos tres niveles; cualquier otro sube a sistema.
        if (!($context instanceof \context_system)
                && !($context instanceof \context_coursecat)
                && !($context instanceof \context_course)) {
            $context = \context_system::instance();
        }

        return new self($context);
    }

    /**
     * @return \context
     */
    public function get_context(): \context {
        return $this->context;
    }

    /**
     * @return string site | category | course
     */
    public function get_level(): string {
        return $this->level;
    }

    /**
     * @return int
     */
    public function get_instanceid(): int {
        return $this->instanceid;
    }

    /**
     * Indica si este nivel esta habilitado en los ajustes del plugin.
     *
     * @return bool
     */
    public function is_enabled(): bool {
        $map = [
            self::LEVEL_SITE     => 'enablesite',
            self::LEVEL_CATEGORY => 'enablecategory',
            self::LEVEL_COURSE   => 'enablecourse',
        ];

        // Los tableros de categoria y curso son parte de la licencia: sin
        // ella solo existe el de plataforma.
        if ($this->level !== self::LEVEL_SITE
                && !licence::has_feature(licence::FEATURE_SCOPES)) {
            return false;
        }

        $setting = get_config('local_learninganalytics', $map[$this->level]);

        // Sin valor guardado todavia, el nivel plataforma se considera activo.
        if ($setting === false) {
            return $this->level === self::LEVEL_SITE;
        }

        return (bool)$setting;
    }

    /**
     * Cursos que entran en el informe.
     *
     * @return array|null Lista de courseids, o null si no hay restriccion.
     */
    public function get_course_ids(): ?array {
        global $DB;

        if ($this->level === self::LEVEL_SITE) {
            return null;   // Sin restriccion.
        }

        if ($this->level === self::LEVEL_COURSE) {
            return [$this->instanceid];
        }

        // Categoria: incluye subcategorias, via el campo path.
        return self::courses_in_category($this->instanceid);
    }

    /**
     * Cursos que cuelgan de una categoria, incluidas sus subcategorias.
     *
     * Se usa tanto para el ambito de categoria como para el filtro en cascada,
     * de modo que ambos comparten exactamente la misma definicion de subarbol.
     *
     * @param int $categoryid
     * @return array Lista de courseids.
     */
    public static function courses_in_category(int $categoryid): array {
        global $DB;

        $category = $DB->get_record('course_categories', ['id' => $categoryid], 'id, path');
        if (!$category) {
            return [];
        }

        $like = $DB->sql_like('cc.path', ':path');
        $sql = "SELECT c.id
                  FROM {course} c
                  JOIN {course_categories} cc ON cc.id = c.category
                 WHERE (cc.id = :catid OR {$like}) AND c.id <> :siteid";

        $ids = $DB->get_fieldset_sql($sql, [
            'catid'  => $categoryid,
            'path'   => $DB->sql_like_escape($category->path) . '/%',
            'siteid' => SITEID,
        ]);

        return array_map('intval', $ids);
    }

    /**
     * Categorias visibles dentro del ambito, para el filtro en cascada.
     *
     * En plataforma son todas; en una categoria, ella y sus descendientes.
     *
     * @return array
     */
    public function get_categories(): array {
        global $DB;

        if ($this->level === self::LEVEL_COURSE) {
            return [];   // Un curso no tiene arbol que recorrer.
        }

        if ($this->level === self::LEVEL_CATEGORY) {
            $category = $DB->get_record('course_categories', ['id' => $this->instanceid], 'id, path');
            if (!$category) {
                return [];
            }
            $like = $DB->sql_like('path', ':path');
            $records = $DB->get_records_select('course_categories',
                "id = :catid OR {$like}",
                ['catid' => $this->instanceid, 'path' => $DB->sql_like_escape($category->path) . '/%'],
                'path', 'id, name, parent, depth, coursecount, visible');
        } else {
            $records = $DB->get_records('course_categories', null, 'path',
                'id, name, parent, depth, coursecount, visible');
        }

        $out = [];
        foreach ($records as $c) {
            if (!$c->visible && !has_capability('moodle/category:viewhiddencategories',
                    \context_coursecat::instance($c->id))) {
                continue;
            }
            $out[] = [
                'id'     => (int)$c->id,
                'name'   => format_string($c->name),
                'parent' => (int)$c->parent,
                'depth'  => (int)$c->depth,
            ];
        }

        return $out;
    }

    /**
     * Categoria raiz del arbol para este ambito.
     *
     * @return int 0 en plataforma; el id de la categoria en ambito categoria.
     */
    public function get_root_category(): int {
        return $this->level === self::LEVEL_CATEGORY ? $this->instanceid : 0;
    }

    /**
     * Contextos donde una asignacion de rol afecta a este ambito.
     *
     * Incluye el contexto propio, sus ancestros (un rol asignado en la
     * categoria se hereda en sus cursos) y los contextos de los cursos que
     * abarca. Null significa "cualquier contexto", que es lo correcto en
     * plataforma: alli un docente lo es por serlo en algun curso.
     *
     * @return array|null
     */
    public function get_role_context_ids(): ?array {
        if ($this->level === self::LEVEL_SITE) {
            return null;
        }

        $ids = $this->context->get_parent_context_ids(true);

        foreach ($this->get_course_ids() ?? [] as $courseid) {
            $ids[] = \context_course::instance($courseid)->id;
        }

        return array_values(array_unique(array_map('intval', $ids)));
    }

    /**
     * Roles realmente asignados dentro del ambito.
     *
     * Solo se ofrecen los que existen: un curso sin gestores no muestra el
     * rol "Gestor" en el filtro.
     *
     * @return array
     */
    public function get_roles(): array {
        global $DB;

        $ctxids = $this->get_role_context_ids();
        $params = [];
        $where = '';

        if ($ctxids !== null) {
            if (empty($ctxids)) {
                return [];
            }
            [$insql, $params] = $DB->get_in_or_equal($ctxids, SQL_PARAMS_NAMED, 'rc');
            $where = " WHERE ra.contextid {$insql}";
        }

        $sql = "SELECT r.id, r.shortname, r.name, r.archetype, COUNT(DISTINCT ra.userid) AS total
                  FROM {role_assignments} ra
                  JOIN {role} r ON r.id = ra.roleid
                       {$where}
              GROUP BY r.id, r.shortname, r.name, r.archetype
              ORDER BY r.sortorder";

        $records = $DB->get_records_sql($sql, $params);
        if (empty($records)) {
            return [];
        }

        // role_get_names da el nombre localizado y el personalizado del sitio.
        $names = role_get_names($this->context, ROLENAME_ORIGINAL);

        $out = [];
        foreach ($records as $r) {
            $out[] = [
                'id'    => (int)$r->id,
                'name'  => $names[$r->id]->localname ?? $r->shortname,
                'count' => (int)$r->total,
            ];
        }

        return $out;
    }

    /**
     * Comprueba que un usuario pertenece a este ambito.
     *
     * Sin esto, quien tuviera permiso en un curso podria escribir por id a
     * cualquier persona de la plataforma manipulando la peticion.
     *
     * @param int $userid
     * @return bool
     */
    public function can_target_user(int $userid): bool {
        global $DB;

        if (!$DB->record_exists('user', ['id' => $userid, 'deleted' => 0])) {
            return false;
        }

        $courseids = $this->get_course_ids();

        if ($courseids === null) {
            return true;   // Plataforma: cualquier usuario del sitio.
        }

        if (empty($courseids)) {
            return false;
        }

        [$insql, $params] = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED, 'tc');

        $sql = "SELECT 1
                  FROM {user_enrolments} ue
                  JOIN {enrol} e ON e.id = ue.enrolid
                 WHERE ue.userid = :userid AND e.courseid {$insql}";

        return $DB->record_exists_sql($sql, $params + ['userid' => $userid]);
    }

    /**
     * Titulo legible del ambito, para la cabecera de la pagina.
     *
     * @return string
     */
    public function get_heading(): string {
        global $DB;

        if ($this->level === self::LEVEL_COURSE) {
            $name = $DB->get_field('course', 'fullname', ['id' => $this->instanceid]);
            return get_string('dashboardfor', 'local_learninganalytics', format_string($name));
        }

        if ($this->level === self::LEVEL_CATEGORY) {
            $name = $DB->get_field('course_categories', 'name', ['id' => $this->instanceid]);
            return get_string('dashboardfor', 'local_learninganalytics', format_string($name));
        }

        return get_string('dashboard', 'local_learninganalytics');
    }

    /**
     * URL del dashboard para este ambito.
     *
     * @return \moodle_url
     */
    public function get_url(): \moodle_url {
        $params = [];
        if ($this->level !== self::LEVEL_SITE) {
            $params['contextid'] = $this->context->id;
        }

        return new \moodle_url('/local/learninganalytics/index.php', $params);
    }
}
