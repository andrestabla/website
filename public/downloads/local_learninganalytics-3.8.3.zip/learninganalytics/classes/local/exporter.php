<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Reune los datos que se pueden exportar.
 *
 * Traduce un "objetivo" (un objeto suelto, un bloque o el informe entero) a una
 * lista de conjuntos de datos con titulo, cabeceras y filas. A partir de ahi,
 * cada formato solo tiene que recorrer esa estructura, de modo que CSV, XLSX y
 * PDF no pueden divergir en lo que muestran.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class exporter {

    /** @var scope */
    protected $scope;

    /** @var array */
    protected $filters;

    /** @var array|null Informe general, calculado bajo demanda. */
    protected $report = null;

    /** @var array|null Informe de curso, calculado bajo demanda. */
    protected $coursereport = null;

    /**
     * @param scope $scope
     * @param array $filters
     */
    public function __construct(scope $scope, array $filters) {
        $this->scope = $scope;
        $this->filters = $filters;
    }

    /**
     * Objetivos disponibles en este ambito.
     *
     * @return array clave => titulo
     */
    public function get_available_targets(): array {
        $targets = [
            'kpis'         => get_string('exp_kpis', 'local_learninganalytics'),
            'users'        => get_string('tab_users', 'local_learninganalytics'),
            'progress'     => get_string('tab_progress', 'local_learninganalytics'),
            'growth'       => get_string('chart_growth', 'local_learninganalytics'),
            'domains'      => get_string('chart_domains', 'local_learninganalytics'),
            'countries'    => get_string('chart_countries', 'local_learninganalytics'),
            'activity'     => get_string('chart_activity', 'local_learninganalytics'),
            'topcourses'   => get_string('chart_topcourses', 'local_learninganalytics'),
        ];

        if ($this->scope->get_level() === scope::LEVEL_COURSE) {
            $targets['ckpis']       = get_string('exp_coursekpis', 'local_learninganalytics');
            $targets['csections']   = get_string('chart_sections', 'local_learninganalytics');
            $targets['cactivities'] = get_string('tab_activities', 'local_learninganalytics');
            $targets['cstudents']   = get_string('tab_students', 'local_learninganalytics');
        }

        return $targets;
    }

    /**
     * Devuelve los conjuntos de datos de un objetivo.
     *
     * @param string $target Clave de objeto, "block:*" o "all".
     * @return array Lista de ['title' => ..., 'headers' => [...], 'rows' => [[...]]]
     */
    public function get_datasets(string $target): array {
        $iscourse = $this->scope->get_level() === scope::LEVEL_COURSE;

        // El navegador no puede enviar ":" en un PARAM_ALPHANUMEXT, asi que
        // los bloques viajan sin el. Se aceptan ambas formas para que la
        // clase no dependa de como la llame quien la use.
        $aliases = [
            'blockcharts' => 'block:charts',
            'blocktables' => 'block:tables',
            'blockcourse' => 'block:course',
        ];
        $target = $aliases[$target] ?? $target;

        switch ($target) {
            case 'all':
                $keys = ['kpis', 'users', 'progress', 'growth', 'domains',
                         'countries', 'activity', 'topcourses'];
                if ($iscourse) {
                    $keys = array_merge(['ckpis', 'csections', 'cactivities', 'cstudents'], $keys);
                }
                break;

            case 'block:charts':
                $keys = ['growth', 'domains', 'countries', 'activity', 'topcourses'];
                if ($iscourse) {
                    array_unshift($keys, 'csections');
                }
                break;

            case 'block:tables':
                $keys = $iscourse ? ['cstudents', 'cactivities', 'users', 'progress']
                                  : ['users', 'progress'];
                break;

            case 'block:course':
                $keys = $iscourse ? ['ckpis', 'csections', 'cactivities', 'cstudents'] : [];
                break;

            default:
                $keys = [$target];
        }

        $out = [];
        foreach ($keys as $key) {
            $dataset = $this->build_dataset($key);
            if ($dataset !== null) {
                $out[] = $dataset;
            }
        }

        return $out;
    }

    /**
     * Informe general, calculado una sola vez.
     *
     * @return array
     */
    protected function report(): array {
        if ($this->report === null) {
            $this->report = (new report_query($this->filters, $this->scope))->run();
        }

        return $this->report;
    }

    /**
     * Informe de curso, calculado una sola vez.
     *
     * @return array|null
     */
    protected function coursereport(): ?array {
        if ($this->scope->get_level() !== scope::LEVEL_COURSE) {
            return null;
        }

        if ($this->coursereport === null) {
            $this->coursereport = (new course_report(
                $this->scope->get_instanceid(), $this->filters))->run();
        }

        return $this->coursereport;
    }

    /**
     * Construye un conjunto de datos concreto.
     *
     * @param string $key
     * @return array|null
     */
    protected function build_dataset(string $key): ?array {
        switch ($key) {
            case 'kpis':
                return $this->dataset_kpis();
            case 'users':
                return $this->dataset_users();
            case 'progress':
                return $this->dataset_progress();
            case 'growth':
            case 'domains':
            case 'countries':
            case 'activity':
            case 'topcourses':
            case 'certificates':
            case 'certsplit':
                return $this->dataset_series($key);
            case 'ckpis':
                return $this->dataset_course_kpis();
            case 'csections':
                return $this->dataset_sections();
            case 'cactivities':
                return $this->dataset_activities();
            case 'cstudents':
                return $this->dataset_students();
        }

        return null;
    }

    /**
     * @return array
     */
    protected function dataset_kpis(): array {
        $r = $this->report();
        $k = $r['kpis'];

        $rows = [
            [get_string('kpi_users', 'local_learninganalytics'), $k['users']],
            [get_string('kpi_enrolments', 'local_learninganalytics'), $k['enrolments']],
        ];

        // Los certificados solo se exportan si el ambito los tiene.
        if (!empty($r['hascerts'])) {
            $rows[] = [get_string('kpi_certificates', 'local_learninganalytics'), $k['certificates']];
            $rows[] = [get_string('kpi_certrate', 'local_learninganalytics'), $k['certrate'] . '%'];
        }

        return [
            'title'   => get_string('exp_kpis', 'local_learninganalytics'),
            'headers' => [get_string('exp_indicator', 'local_learninganalytics'),
                          get_string('exp_value', 'local_learninganalytics')],
            'rows'    => $rows,
        ];
    }

    /**
     * @return array
     */
    protected function dataset_users(): array {
        $r = $this->report();

        $headers = [
            get_string('col_name', 'local_learninganalytics'),
            get_string('col_email', 'local_learninganalytics'),
            get_string('col_country', 'local_learninganalytics'),
        ];
        if (!empty($r['hasestado'])) {
            $headers[] = get_string('col_estado', 'local_learninganalytics');
        }
        if (!empty($r['hassupervisor'])) {
            $headers[] = get_string('col_supervisor', 'local_learninganalytics');
        }
        $headers[] = get_string('col_lastaccess', 'local_learninganalytics');

        $rows = [];
        foreach ($r['users'] as $u) {
            $row = [$u['fullname'], $u['email'], $u['country']];
            if (!empty($r['hasestado'])) {
                $row[] = $u['estado'];
            }
            if (!empty($r['hassupervisor'])) {
                $row[] = $u['supervisor'];
            }
            $row[] = $u['lastaccess'];
            $rows[] = $row;
        }

        return [
            'title'   => get_string('tab_users', 'local_learninganalytics'),
            'headers' => $headers,
            'rows'    => $rows,
        ];
    }

    /**
     * @return array
     */
    protected function dataset_progress(): array {
        $r = $this->report();
        $rows = [];

        foreach ($r['progress'] as $p) {
            $signed = $p['signed'] === 'na'
                ? get_string('notapplicable', 'local_learninganalytics')
                : ($p['signed'] === 'yes'
                    ? get_string('yes', 'local_learninganalytics')
                    : get_string('no', 'local_learninganalytics'));

            $rows[] = [$p['fullname'], $p['email'], $p['coursename'], $signed];
        }

        return [
            'title'   => get_string('tab_progress', 'local_learninganalytics'),
            'headers' => [
                get_string('col_name', 'local_learninganalytics'),
                get_string('col_email', 'local_learninganalytics'),
                get_string('col_course', 'local_learninganalytics'),
                get_string('col_signed', 'local_learninganalytics'),
            ],
            'rows'    => $rows,
        ];
    }

    /**
     * Serie de una grafica como tabla de dos columnas.
     *
     * @param string $key
     * @return array|null
     */
    protected function dataset_series(string $key): ?array {
        $r = $this->report();

        if (empty($r[$key]['labels'])) {
            return null;   // Sin datos no se exporta una hoja vacia.
        }

        $titles = [
            'growth'       => 'chart_growth',
            'domains'      => 'chart_domains',
            'countries'    => 'chart_countries',
            'activity'     => 'chart_activity',
            'topcourses'   => 'chart_topcourses',
            'certificates' => 'chart_certificates',
            'certsplit'    => 'chart_certsplit',
        ];

        $rows = [];
        foreach ($r[$key]['labels'] as $i => $label) {
            $rows[] = [$label, $r[$key]['values'][$i]];
        }

        return [
            'title'   => get_string($titles[$key], 'local_learninganalytics'),
            'headers' => [get_string('exp_category', 'local_learninganalytics'),
                          get_string('exp_value', 'local_learninganalytics')],
            'rows'    => $rows,
        ];
    }

    /**
     * @return array|null
     */
    protected function dataset_course_kpis(): ?array {
        $c = $this->coursereport();
        if (!$c) {
            return null;
        }

        $k = $c['kpis'];

        return [
            'title'   => get_string('exp_coursekpis', 'local_learninganalytics'),
            'headers' => [get_string('exp_indicator', 'local_learninganalytics'),
                          get_string('exp_value', 'local_learninganalytics')],
            'rows'    => [
                [get_string('kpi_students', 'local_learninganalytics'), $k['students']],
                [get_string('kpi_avgprogress', 'local_learninganalytics'), $k['avgprogress'] . '%'],
                [get_string('kpi_avggrade', 'local_learninganalytics'),
                    $k['gradedcount'] > 0 ? $k['avggrade'] . '%' : '-'],
                [get_string('kpi_avgtime', 'local_learninganalytics'), $k['avgtimeformatted']],
                [get_string('kpi_completed', 'local_learninganalytics'), $k['completed']],
            ],
        ];
    }

    /**
     * @return array|null
     */
    protected function dataset_sections(): ?array {
        $c = $this->coursereport();
        if (!$c || empty($c['sections']['labels'])) {
            return null;
        }

        $rows = [];
        foreach ($c['sections']['labels'] as $i => $label) {
            $rows[] = [$label, $c['sections']['values'][$i] . '%'];
        }

        return [
            'title'   => get_string('chart_sections', 'local_learninganalytics'),
            'headers' => [get_string('col_section', 'local_learninganalytics'),
                          get_string('col_progress', 'local_learninganalytics')],
            'rows'    => $rows,
        ];
    }

    /**
     * @return array|null
     */
    protected function dataset_activities(): ?array {
        $c = $this->coursereport();
        if (!$c) {
            return null;
        }

        $rows = [];
        foreach ($c['activities'] as $a) {
            $rows[] = [
                $a['name'],
                $a['sectionname'],
                $a['modname'],
                $a['completed'],
                $a['progress'] . '%',
                ($a['average'] === null) ? '-' : $a['average'] . '%',
            ];
        }

        return [
            'title'   => get_string('tab_activities', 'local_learninganalytics'),
            'headers' => [
                get_string('col_activity', 'local_learninganalytics'),
                get_string('col_section', 'local_learninganalytics'),
                get_string('exp_type', 'local_learninganalytics'),
                get_string('col_completedby', 'local_learninganalytics'),
                get_string('col_progress', 'local_learninganalytics'),
                get_string('col_avggrade', 'local_learninganalytics'),
            ],
            'rows'    => $rows,
        ];
    }

    /**
     * @return array|null
     */
    protected function dataset_students(): ?array {
        $c = $this->coursereport();
        if (!$c) {
            return null;
        }

        $rows = [];
        foreach ($c['students'] as $s) {
            $rows[] = [
                $s['fullname'],
                $s['email'],
                $s['progress'] . '%',
                ($s['grade'] === null) ? '-' : $s['grade'] . '%',
                $s['lastaccessformatted'],
                $s['timespentformatted'],
            ];
        }

        return [
            'title'   => get_string('tab_students', 'local_learninganalytics'),
            'headers' => [
                get_string('col_name', 'local_learninganalytics'),
                get_string('col_email', 'local_learninganalytics'),
                get_string('col_progress', 'local_learninganalytics'),
                get_string('col_grade', 'local_learninganalytics'),
                get_string('col_lastaccess', 'local_learninganalytics'),
                get_string('col_timespent', 'local_learninganalytics'),
            ],
            'rows'    => $rows,
        ];
    }

    /**
     * Titulo legible del informe, para la cabecera del archivo.
     *
     * @return string
     */
    public function get_report_title(): string {
        return $this->scope->get_heading();
    }
}
