<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

/**
 * Resuelve los ajustes del plugin a los identificadores que necesita el SQL.
 *
 * Los ajustes se guardan por shortname (estable frente a reimportaciones) y
 * aqui se traducen a fieldid una sola vez por peticion.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class config {

    /** @var array<string,int|null> Cache de shortname => fieldid. */
    private static $fieldcache = [];

    /** @var array|null Cache del mapa de firmas ya resuelto. */
    private static $signaturecache = null;

    /**
     * Devuelve el fieldid del campo de perfil configurado, o null.
     *
     * @param string $setting Nombre del ajuste (field_estado | field_supervisor).
     * @return int|null
     */
    public static function get_profile_fieldid(string $setting): ?int {
        global $DB;

        $shortname = trim((string)get_config('local_learninganalytics', $setting));
        if ($shortname === '') {
            return null;
        }
        if (array_key_exists($shortname, self::$fieldcache)) {
            return self::$fieldcache[$shortname];
        }

        $id = $DB->get_field('user_info_field', 'id', ['shortname' => $shortname]);
        self::$fieldcache[$shortname] = $id ? (int)$id : null;

        return self::$fieldcache[$shortname];
    }

    /**
     * fieldid del campo "Estado", o null si no esta configurado o no existe.
     *
     * @return int|null
     */
    public static function estado_fieldid(): ?int {
        return self::get_profile_fieldid('field_estado');
    }

    /**
     * fieldid del campo "Supervisor", o null si no esta configurado o no existe.
     *
     * @return int|null
     */
    public static function supervisor_fieldid(): ?int {
        return self::get_profile_fieldid('field_supervisor');
    }

    /**
     * Usuario remitente para el reenvio de credenciales.
     *
     * Reemplaza el "user ID 55" cableado: se configura por username y, si no
     * esta configurado o no existe, cae al administrador principal del sitio.
     *
     * @return \stdClass
     */
    public static function credentials_sender(): \stdClass {
        global $DB;

        $username = trim((string)get_config('local_learninganalytics', 'sender_username'));
        if ($username !== '') {
            $user = $DB->get_record('user', ['username' => $username, 'deleted' => 0]);
            if ($user) {
                return $user;
            }
        }

        return get_admin();
    }

    /**
     * Mapa de cursos con tarea de firma: courseid => assignid.
     *
     * Reemplaza los pares curso 2/tarea 11 y curso 4/tarea 12 cableados.
     * Acepta el id numerico de la tarea o su nombre exacto, que es mas
     * estable entre plataformas.
     *
     * @return array<int,int> courseid => assignid
     */
    public static function signature_map(): array {
        global $DB;

        if (self::$signaturecache !== null) {
            return self::$signaturecache;
        }

        $raw = (string)get_config('local_learninganalytics', 'signature_map');
        $map = [];

        foreach (preg_split('/\R/', $raw) as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, ':') === false) {
                continue;
            }

            [$courseref, $assignref] = array_map('trim', explode(':', $line, 2));
            if ($courseref === '' || $assignref === '') {
                continue;
            }

            $courseid = $DB->get_field('course', 'id', ['shortname' => $courseref]);
            if (!$courseid) {
                continue;   // El curso no existe en esta plataforma: se ignora la linea.
            }

            if (ctype_digit($assignref)) {
                // Id numerico: se valida que pertenezca a ese curso.
                $assignid = $DB->get_field('assign', 'id',
                    ['id' => (int)$assignref, 'course' => $courseid]);
            } else {
                // Nombre exacto dentro del curso.
                $assignid = $DB->get_field('assign', 'id',
                    ['name' => $assignref, 'course' => $courseid], IGNORE_MULTIPLE);
            }

            if ($assignid) {
                $map[(int)$courseid] = (int)$assignid;
            }
        }

        self::$signaturecache = $map;

        return $map;
    }

    /**
     * Limpia las caches internas. Solo para pruebas.
     */
    public static function reset_caches(): void {
        self::$fieldcache = [];
        self::$signaturecache = null;
    }
}
