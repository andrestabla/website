<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Verificacion de la licencia y control de funcionalidades.
 *
 * Modelo mixto:
 *  1. El codigo de activacion viene firmado con Ed25519 por Algoritmo T. El
 *     plugin lleva la clave publica y lo verifica en local, de modo que activa
 *     al instante y sigue funcionando sin conexion.
 *  2. Una tarea programada revalida periodicamente contra el ecosistema para
 *     permitir revocar licencias. Si el servicio no responde NO se desactiva
 *     nada: un corte de red del cliente no puede dejarlo sin producto.
 *
 * Nota honesta sobre el alcance de esta proteccion: los plugins de Moodle se
 * distribuyen bajo GPL, luego el codigo es visible y modificable. Esta barrera
 * es un control comercial y contractual, no un DRM: disuade el uso casual sin
 * licencia, no lo hace imposible.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class licence {

    /** Clave publica Ed25519 de Algoritmo T, en base64. */
    const PUBLIC_KEY = 'HVHVwEfMNi02FervyV4qsi+ifxfzRuspQ73v2B5kwOE=';

    /** Prefijo que identifica el formato de codigo. */
    const CODE_PREFIX = 'LA1.';

    /** Endpoint de revalidacion. */
    const VALIDATE_URL = 'https://www.algoritmot.com/api/licence/validate';

    // ---------------------------------------------------------------------
    // Funcionalidades.
    // ---------------------------------------------------------------------

    /** Tablas de usuarios y de progreso. */
    const FEATURE_TABLES = 'tables';

    /** Graficas mas alla de las dos gratuitas, incluido el mapa. */
    const FEATURE_CHARTS = 'charts';

    /** Filtros: categorias, rol, pais, dominio, fechas y busqueda. */
    const FEATURE_FILTERS = 'filters';

    /** Tableros de categoria y de curso. */
    const FEATURE_SCOPES = 'scopes';

    /** Panel de analitica del curso. */
    const FEATURE_COURSE = 'course';

    /** Correo individual y envio masivo. */
    const FEATURE_MESSAGING = 'messaging';

    /** Descargas en XLSX, PDF y JPG. CSV es gratuito. */
    const FEATURE_EXPORT = 'export';

    /** @var array|null Cache del estado dentro de la peticion. */
    protected static $status = null;

    /**
     * Estado actual de la licencia.
     *
     * @return \stdClass valid, reason, customer, expires, features, licenceid
     */
    public static function get_status(): \stdClass {
        if (self::$status !== null) {
            return self::$status;
        }

        $status = (object)[
            'valid'     => false,
            'reason'    => 'nocode',
            'customer'  => '',
            'expires'   => 0,
            'features'  => [],
            'licenceid' => '',
        ];

        $code = trim((string)get_config('local_learninganalytics', 'licencekey'));

        if ($code === '') {
            return self::$status = $status;
        }

        $payload = self::verify_code($code);

        if ($payload === null) {
            $status->reason = 'invalid';
            return self::$status = $status;
        }

        $status->customer  = (string)($payload['c'] ?? '');
        $status->expires   = (int)($payload['e'] ?? 0);
        $status->features  = (array)($payload['f'] ?? []);
        $status->licenceid = (string)($payload['i'] ?? '');

        // Caducidad.
        if ($status->expires > 0 && $status->expires < time()) {
            $status->reason = 'expired';
            return self::$status = $status;
        }

        // Vinculacion al sitio: "*" vale para cualquiera.
        $site = (string)($payload['s'] ?? '*');
        if ($site !== '*' && $site !== self::site_hash()) {
            $status->reason = 'wrongsite';
            return self::$status = $status;
        }

        // Revocacion detectada por la tarea de revalidacion.
        if (get_config('local_learninganalytics', 'licencerevoked')) {
            $status->reason = 'revoked';
            return self::$status = $status;
        }

        $status->valid = true;
        $status->reason = 'ok';

        return self::$status = $status;
    }

    /**
     * Comprueba si una funcionalidad esta disponible.
     *
     * @param string $feature
     * @return bool
     */
    public static function has_feature(string $feature): bool {
        $status = self::get_status();

        if (!$status->valid) {
            return false;
        }

        // "*" habilita todo el catalogo.
        return in_array('*', $status->features, true)
            || in_array($feature, $status->features, true);
    }

    /**
     * Verifica la firma de un codigo y devuelve su contenido.
     *
     * @param string $code
     * @return array|null null si la firma no es valida.
     */
    public static function verify_code(string $code): ?array {
        $code = trim($code);

        if (strpos($code, self::CODE_PREFIX) !== 0) {
            return null;
        }

        $parts = explode('.', substr($code, strlen(self::CODE_PREFIX)));
        if (count($parts) !== 2) {
            return null;
        }

        try {
            $payload = sodium_base642bin($parts[0], SODIUM_BASE64_VARIANT_URLSAFE_NO_PADDING);
            $signature = sodium_base642bin($parts[1], SODIUM_BASE64_VARIANT_URLSAFE_NO_PADDING);
            $publickey = sodium_base642bin(self::PUBLIC_KEY, SODIUM_BASE64_VARIANT_ORIGINAL);
        } catch (\Throwable $e) {
            return null;
        }

        if (strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES
                || strlen($publickey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
            return null;
        }

        if (!sodium_crypto_sign_verify_detached($signature, $payload, $publickey)) {
            return null;
        }

        $data = json_decode($payload, true);

        return is_array($data) ? $data : null;
    }

    /**
     * Identificador del sitio, para vincular una licencia sin exponer datos.
     *
     * Se deriva de $CFG->siteidentifier, la cadena unica que Moodle genera al
     * instalar y guarda en la base de datos.
     *
     * NO se usa wwwroot a proposito: hay instalaciones que lo calculan de forma
     * dinamica a partir de la cabecera Host, con lo que el mismo sitio produce
     * un identificador distinto segun se acceda por web o por CLI, con www o
     * sin el, o por http o https. Eso rompia la vinculacion de la licencia: el
     * administrador veia un identificador y la tarea programada enviaba otro.
     *
     * @return string
     */
    public static function site_hash(): string {
        global $CFG;

        $seed = $CFG->siteidentifier ?? '';

        // Sin siteidentifier (instalacion incompleta) se cae a wwwroot, que es
        // peor pero permite seguir funcionando.
        if ($seed === '') {
            $seed = rtrim($CFG->wwwroot, '/');
        }

        return substr(hash('sha256', $seed), 0, 32);
    }

    /**
     * Texto explicativo del estado, para los ajustes.
     *
     * @return string
     */
    public static function get_status_message(): string {
        $status = self::get_status();

        if ($status->valid) {
            $expires = $status->expires > 0
                ? userdate($status->expires, get_string('strftimedate'))
                : get_string('lic_noexpiry', 'local_learninganalytics');

            return get_string('lic_active', 'local_learninganalytics',
                (object)['customer' => s($status->customer), 'expires' => $expires]);
        }

        return get_string('lic_reason_' . $status->reason, 'local_learninganalytics');
    }
}
