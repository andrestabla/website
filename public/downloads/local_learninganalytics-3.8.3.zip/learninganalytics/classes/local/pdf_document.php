<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/pdflib.php');

/**
 * Documento PDF con pie propio.
 *
 * TCPDF no ofrece un metodo para fijar el texto del pie: la unica via es
 * sobrescribir Footer(), que la libreria invoca al cerrar cada pagina.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class pdf_document extends \pdf {

    /** @var string Texto de la izquierda del pie. */
    protected $footerlabel = '';

    /**
     * Fija el texto del pie.
     *
     * @param string $text
     */
    public function set_footer_label(string $text): void {
        $this->footerlabel = $text;
    }

    /**
     * Pie de cada pagina: sitio a la izquierda, numeracion a la derecha.
     */
    // phpcs:ignore moodle.NamingConventions.ValidFunctionName.LowercaseMethod
    public function Footer() {
        $this->SetY(-13);

        $this->SetDrawColor(220, 226, 232);
        $this->Line($this->original_lMargin, $this->GetY(),
            $this->getPageWidth() - $this->original_rMargin, $this->GetY());

        $this->SetY(-11);
        $this->SetFont('freesans', '', 7);
        $this->SetTextColor(140, 148, 158);

        $width = $this->getPageWidth() - $this->original_lMargin - $this->original_rMargin;

        $this->Cell($width / 2, 6, $this->footerlabel, 0, 0, 'L');
        $this->Cell($width / 2, 6,
            $this->getAliasNumPage() . ' / ' . $this->getAliasNbPages(), 0, 0, 'R');
    }
}
