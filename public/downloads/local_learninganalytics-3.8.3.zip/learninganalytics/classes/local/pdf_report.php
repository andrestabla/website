<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/pdflib.php');

/**
 * Maquetacion del informe en PDF.
 *
 * Reglas de composicion:
 *  - Las graficas van en rejilla de dos columnas, con su titulo y respetando
 *    su proporcion. Nunca se estiran al ancho de la pagina: una grafica
 *    deformada informa peor que una pequena.
 *  - El contenido fluye; no se abre pagina nueva por cada elemento.
 *  - Las cabeceras de tabla se repiten al partir en varias paginas.
 *  - Pie con numero de pagina y nombre del sitio.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class pdf_report {

    /** Margen lateral en milimetros. */
    const MARGIN = 14;

    /** Ancho util de la pagina A4 con esos margenes. */
    const CONTENT_WIDTH = 182;

    /** Separacion entre las dos columnas de graficas. */
    const GUTTER = 6;

    /** Altura maxima de una grafica, para que no domine la pagina. */
    const CHART_MAX_HEIGHT = 62;

    /** Limite inferior a partir del cual conviene saltar de pagina. */
    const PAGE_BOTTOM = 262;

    /**
     * Fuente Unicode incluida en TCPDF.
     *
     * helvetica es una fuente base limitada a Latin-1: convierte en "?" las
     * tildes de algunos contextos y cualquier caracter fuera de ese juego.
     * freesans cubre Unicode y viene con Moodle, sin anadir dependencias.
     */
    const FONT = 'freesans';

    /** @var pdf_document */
    protected $doc;

    /** @var exporter */
    protected $exporter;

    /** @var string */
    protected $title;

    /**
     * @param exporter $exporter
     */
    public function __construct(exporter $exporter) {
        $this->exporter = $exporter;
        $this->title = $exporter->get_report_title();
    }

    /**
     * Genera el documento y lo devuelve como cadena binaria.
     *
     * @param array $datasets
     * @param array $charts Lista de ['title' => string, 'path' => string]
     * @return string
     */
    public function render(array $datasets, array $charts): string {
        global $CFG;

        $site = get_site();

        $this->doc = new pdf_document();
        $this->doc->SetCreator('Moodle');
        $this->doc->SetTitle($this->title);
        $this->doc->SetMargins(self::MARGIN, self::MARGIN, self::MARGIN);
        $this->doc->SetAutoPageBreak(true, 18);
        $this->doc->setPrintHeader(false);

        // Pie propio: sitio y numeracion, en todas las paginas.
        $this->doc->setPrintFooter(true);
        $this->doc->setFooterMargin(12);
        $this->doc->set_footer_label(format_string($site->fullname));

        $this->doc->AddPage();

        $this->draw_cover($site);

        // Las cifras clave abren el informe: son el resumen que se busca
        // primero. Las graficas y el resto de tablas van despues.
        $summary = [];
        $rest = [];
        foreach ($datasets as $dataset) {
            if (count($dataset['headers']) === 2
                    && $dataset['headers'][0] === get_string('exp_indicator', 'local_learninganalytics')) {
                $summary[] = $dataset;
            } else {
                $rest[] = $dataset;
            }
        }

        $this->draw_tables($summary);
        $this->draw_charts($charts);
        $this->draw_tables($rest);

        return $this->doc->Output($this->title . '.pdf', 'S');
    }

    /**
     * Cabecera del documento: logo, titulo y fecha.
     *
     * @param \stdClass $site
     */
    protected function draw_cover(\stdClass $site): void {
        $logo = $this->logo_path();

        if ($logo) {
            $this->doc->Image($logo, self::MARGIN, 12, 0, 11, '', '', '', false, 300);
            $this->doc->SetY(28);
        } else {
            $this->doc->SetY(16);
        }

        $this->doc->SetFont(self::FONT, 'B', 16);
        $this->doc->SetTextColor(30, 38, 48);
        $this->doc->Cell(0, 9, self::clean_text($this->title), 0, 1, 'L');

        $this->doc->SetFont(self::FONT, '', 9);
        $this->doc->SetTextColor(110, 118, 130);
        $this->doc->Cell(0, 5, format_string($site->fullname) . '  ·  ' . userdate(time()), 0, 1, 'L');

        // Linea de separacion.
        $y = $this->doc->GetY() + 2;
        $this->doc->SetDrawColor(210, 216, 224);
        $this->doc->Line(self::MARGIN, $y, self::MARGIN + self::CONTENT_WIDTH, $y);
        $this->doc->SetY($y + 5);
        $this->doc->SetTextColor(0, 0, 0);
    }

    /**
     * Rejilla de graficas a dos columnas.
     *
     * @param array $charts
     */
    protected function draw_charts(array $charts): void {
        if (empty($charts)) {
            return;
        }

        $this->section_heading(get_string('exp_chartsblock', 'local_learninganalytics'));

        $colwidth = (self::CONTENT_WIDTH - self::GUTTER) / 2;
        $column = 0;
        $rowtop = $this->doc->GetY();
        $rowheight = 0;

        foreach ($charts as $chart) {
            $size = @getimagesize($chart['path']);
            if (!$size || $size[0] <= 0) {
                continue;
            }

            // Proporcion respetada, con tope de altura.
            $width = $colwidth;
            $height = ($size[1] / $size[0]) * $width;
            if ($height > self::CHART_MAX_HEIGHT) {
                $height = self::CHART_MAX_HEIGHT;
                $width = ($size[0] / $size[1]) * $height;
            }

            $blockheight = $height + 9;   // Imagen mas su titulo.

            // Salto de pagina antes de empezar una fila que no cabe.
            if ($column === 0 && $rowtop + $blockheight > self::PAGE_BOTTOM) {
                $this->doc->AddPage();
                $rowtop = $this->doc->GetY();
                $rowheight = 0;
            }

            $x = self::MARGIN + $column * ($colwidth + self::GUTTER);

            $this->doc->SetXY($x, $rowtop);
            $this->doc->SetFont(self::FONT, 'B', 8.5);
            $this->doc->SetTextColor(60, 68, 78);
            $this->doc->Cell($colwidth, 5, self::clean_text($chart['title']), 0, 0, 'L');

            // La imagen se centra en su columna si quedo mas estrecha.
            $imgx = $x + max(0, ($colwidth - $width) / 2);
            $this->doc->Image($chart['path'], $imgx, $rowtop + 6, $width, $height, '', '', '', false, 300);

            $rowheight = max($rowheight, $blockheight);
            $column++;

            if ($column === 2) {
                $column = 0;
                $rowtop += $rowheight + 6;
                $rowheight = 0;
            }
        }

        // Cerrar una fila impar.
        if ($column === 1) {
            $rowtop += $rowheight + 6;
        }

        $this->doc->SetY($rowtop + 2);
        $this->doc->SetTextColor(0, 0, 0);
    }

    /**
     * Tablas de datos.
     *
     * @param array $datasets
     */
    protected function draw_tables(array $datasets): void {
        foreach ($datasets as $dataset) {
            if (empty($dataset['rows'])) {
                continue;
            }

            // Deja al menos sitio para la cabecera y un par de filas.
            if ($this->doc->GetY() > self::PAGE_BOTTOM - 30) {
                $this->doc->AddPage();
            }

            $this->section_heading($dataset['title']);

            // Con muchas columnas se reduce el cuerpo para que quepan.
            $columns = count($dataset['headers']);
            $fontsize = $columns >= 6 ? 6.5 : ($columns >= 4 ? 7.5 : 8.5);
            $this->doc->SetFont(self::FONT, '', $fontsize);

            $this->doc->writeHTML($this->table_html($dataset), true, false, false, false, '');
            $this->doc->Ln(3);
        }
    }

    /**
     * Limpia el texto para el PDF.
     *
     * Ninguna fuente incluida en TCPDF tiene glifos de emoji, asi que un
     * emoji acabaria como "?" o como un recuadro vacio. Es preferible
     * retirarlo: "Modulo 1" se lee mejor que "Modulo 1??".
     *
     * @param string $text
     * @return string
     */
    public static function clean_text(string $text): string {
        $cleaned = preg_replace(
            '/[\x{1F000}-\x{1FAFF}\x{2190}-\x{2BFF}\x{FE00}-\x{FE0F}'
            . '\x{20D0}-\x{20FF}\x{1F1E6}-\x{1F1FF}]/u',
            '', $text);

        if ($cleaned === null) {
            return $text;   // Si la expresion falla, mejor el original.
        }

        // Los emojis suelen ir separados por espacios que quedarian sueltos.
        $cleaned = preg_replace('/\s+/u', ' ', $cleaned);

        return trim($cleaned);
    }

    /**
     * Titulo de seccion.
     *
     * @param string $text
     */
    protected function section_heading(string $text): void {
        $this->doc->SetFont(self::FONT, 'B', 11);
        $this->doc->SetTextColor(30, 38, 48);
        $this->doc->Cell(0, 7, self::clean_text($text), 0, 1, 'L');
        $this->doc->SetTextColor(0, 0, 0);
    }

    /**
     * Tabla en HTML para writeHTML.
     *
     * thead permite que TCPDF repita la cabecera al partir la tabla entre
     * paginas, que es justo lo que se pierde con una tabla larga.
     *
     * @param array $dataset
     * @return string
     */
    protected function table_html(array $dataset): string {
        $html = '<table border="0.3" cellpadding="3" cellspacing="0" width="100%">'
              . '<thead><tr style="background-color:#e9edf2;color:#1e2630;">';

        foreach ($dataset['headers'] as $header) {
            $html .= '<th align="left"><b>' . s(self::clean_text($header)) . '</b></th>';
        }
        $html .= '</tr></thead><tbody>';

        foreach ($dataset['rows'] as $i => $row) {
            // Bandas alternas: una tabla larga se lee mucho mejor.
            $background = ($i % 2) ? ' style="background-color:#f7f9fb;"' : '';
            $html .= '<tr' . $background . '>';
            foreach ($row as $value) {
                $html .= '<td>' . s(self::clean_text((string)$value)) . '</td>';
            }
            $html .= '</tr>';
        }

        return $html . '</tbody></table>';
    }

    /**
     * Ruta local del logo, o null. TCPDF necesita ruta, no URL, y no pinta SVG.
     *
     * @return string|null
     */
    protected function logo_path(): ?string {
        $fs = get_file_storage();
        $context = \context_system::instance();

        foreach ([mailer::LOGO_PNG_FILEAREA, mailer::LOGO_FILEAREA] as $area) {
            $files = $fs->get_area_files($context->id, 'local_learninganalytics',
                $area, 0, 'itemid', false);
            if (!$files) {
                continue;
            }

            $file = reset($files);
            $extension = \core_text::strtolower(pathinfo($file->get_filename(), PATHINFO_EXTENSION));
            if (!in_array($extension, ['png', 'jpg', 'jpeg'], true)) {
                continue;
            }

            $path = make_request_directory() . '/logo.' . $extension;
            $file->copy_content_to($path);

            return $path;
        }

        return null;
    }
}
