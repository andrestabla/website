<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\event;

/**
 * Se dispara cuando se reenvian credenciales a un usuario.
 *
 * Sustituye a local_systemmessages_log(): la auditoria va al registro estandar
 * de Moodle en lugar de a una tabla creada a mano, y ademas NO se guarda el
 * cuerpo del mensaje, que era como la contrasena acababa en claro en la BD.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class credentials_resent extends \core\event\base {

    /**
     * Inicializa los datos del evento.
     */
    protected function init(): void {
        $this->data['crud'] = 'u';
        $this->data['edulevel'] = self::LEVEL_OTHER;
        $this->data['objecttable'] = 'user';
    }

    /**
     * @return string
     */
    public static function get_name(): string {
        return get_string('resendcredentials', 'local_learninganalytics');
    }

    /**
     * @return string
     */
    public function get_description(): string {
        return "The user with id '{$this->userid}' resent account credentials " .
               "to the user with id '{$this->relateduserid}'.";
    }

    /**
     * @return \moodle_url
     */
    public function get_url(): \moodle_url {
        return new \moodle_url('/local/learninganalytics/index.php');
    }
}
