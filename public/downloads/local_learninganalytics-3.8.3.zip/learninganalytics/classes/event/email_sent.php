<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\event;

/**
 * Se dispara al enviar un correo a un usuario desde el tablero.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class email_sent extends \core\event\base {

    /**
     * Inicializa los datos del evento.
     */
    protected function init(): void {
        $this->data['crud'] = 'c';
        $this->data['edulevel'] = self::LEVEL_OTHER;
        $this->data['objecttable'] = 'user';
    }

    /**
     * @return string
     */
    public static function get_name(): string {
        return get_string('event_emailsent', 'local_learninganalytics');
    }

    /**
     * @return string
     */
    public function get_description(): string {
        return "The user with id '{$this->userid}' emailed the user with id " .
               "'{$this->relateduserid}' from the Learning Analytics dashboard.";
    }

    /**
     * @return \moodle_url
     */
    public function get_url(): \moodle_url {
        return new \moodle_url('/local/learninganalytics/index.php');
    }
}
