<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\privacy;

/**
 * Privacy provider.
 *
 * El plugin no almacena datos personales propios: solo presenta datos que ya
 * existen en Moodle, y no transmite nada a servicios externos (la llamada a
 * freeipapi.com de la version anterior fue eliminada). La auditoria del
 * reenvio de credenciales se hace con la API de eventos, cuyo tratamiento de
 * privacidad corre a cargo de los almacenes de registro del nucleo.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class provider implements \core_privacy\local\metadata\null_provider {

    /**
     * @return string
     */
    public static function get_reason(): string {
        return 'privacy:metadata';
    }
}
