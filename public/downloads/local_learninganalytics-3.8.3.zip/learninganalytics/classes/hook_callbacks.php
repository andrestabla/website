<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics;

use core_user\hook\extend_bulk_user_actions;

/**
 * Hook callbacks.
 *
 * Sustituye las ~190 lineas de raspado del DOM con setInterval que inyectaban
 * la accion en la pagina de participantes. Este hook alimenta las acciones
 * masivas de Administracion del sitio > Usuarios > Acciones masivas de usuario,
 * que es donde un administrador espera encontrar una accion de este tipo.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class hook_callbacks {

    /**
     * Anade la accion de reenvio de credenciales a las acciones masivas.
     *
     * @param extend_bulk_user_actions $hook
     */
    public static function extend_bulk_user_actions(extend_bulk_user_actions $hook): void {
        $context = \context_system::instance();

        if (!has_capability('local/learninganalytics:resendcredentials', $context)) {
            return;
        }

        $hook->add_action(
            'local_learninganalytics_resend',
            new \action_link(
                new \moodle_url('/local/learninganalytics/resend.php'),
                get_string('resendcredentials', 'local_learninganalytics')
            )
        );
    }
}
