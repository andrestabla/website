<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;
use local_learninganalytics\local\scope;

/**
 * Envia un correo a un usuario concreto desde el tablero.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class send_email extends external_api {

    /**
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'contextid' => new external_value(PARAM_INT, 'Contexto del ambito'),
            'userid'    => new external_value(PARAM_INT, 'Destinatario'),
            'subject'   => new external_value(PARAM_TEXT, 'Asunto'),
            'body'      => new external_value(PARAM_TEXT, 'Cuerpo en texto plano'),
        ]);
    }

    /**
     * @param int $contextid
     * @param int $userid
     * @param string $subject
     * @param string $body
     * @return array
     */
    public static function execute(int $contextid, int $userid,
            string $subject, string $body): array {
        global $DB, $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'contextid' => $contextid,
            'userid'    => $userid,
            'subject'   => $subject,
            'body'      => $body,
        ]);

        $scope = scope::from_contextid($params['contextid']);
        $context = $scope->get_context();

        self::validate_context($context);
        require_capability('local/learninganalytics:sendmessage', $context);

        if (!\local_learninganalytics\local\licence::has_feature(
                \local_learninganalytics\local\licence::FEATURE_MESSAGING)) {
            throw new \moodle_exception('lic_required', 'local_learninganalytics');
        }

        if (!$scope->is_enabled()) {
            throw new \moodle_exception('levelnotenabled', 'local_learninganalytics');
        }

        // El destinatario debe pertenecer al ambito: no basta con conocer su id.
        if (!$scope->can_target_user($params['userid'])) {
            throw new \moodle_exception('usernotinscope', 'local_learninganalytics');
        }

        $subject = trim($params['subject']);
        $body = trim($params['body']);

        if ($subject === '' || $body === '') {
            throw new \moodle_exception('emailempty', 'local_learninganalytics');
        }

        $recipient = $DB->get_record('user', ['id' => $params['userid'], 'deleted' => 0],
            '*', MUST_EXIST);

        if (empty($recipient->email)) {
            return ['status' => false, 'message' => get_string('emailnoaddress',
                'local_learninganalytics')];
        }

        // Cabecera con logo, cuerpo y pie, con estilos en linea.
        $html = \local_learninganalytics\local\mailer::render_html($body);

        $sent = email_to_user($recipient, $USER, $subject, $body, $html);

        if ($sent) {
            \local_learninganalytics\event\email_sent::create([
                'context'       => $context,
                'objectid'      => $recipient->id,
                'relateduserid' => $recipient->id,
            ])->trigger();
        }

        return [
            'status'  => (bool)$sent,
            'message' => $sent
                ? get_string('emailsentok', 'local_learninganalytics', $recipient->email)
                : get_string('emailsentfail', 'local_learninganalytics'),
        ];
    }

    /**
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'status'  => new external_value(PARAM_BOOL, 'Si el correo se envio'),
            'message' => new external_value(PARAM_TEXT, 'Detalle para mostrar'),
        ]);
    }
}
