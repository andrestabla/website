<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;

/**
 * Autocompletado de usuarios para el filtro.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class search_users extends external_api {

    /**
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'query'     => new external_value(PARAM_TEXT, 'Texto de busqueda'),
            'contextid' => new external_value(PARAM_INT, 'Contexto del ambito; 0 = plataforma', VALUE_DEFAULT, 0),
        ]);
    }

    /**
     * @param string $query
     * @return array
     */
    public static function execute(string $query, int $contextid = 0): array {
        global $DB;

        $params = self::validate_parameters(self::execute_parameters(),
            ['query' => $query, 'contextid' => $contextid]);

        $scope = \local_learninganalytics\local\scope::from_contextid($params['contextid']);
        $context = $scope->get_context();

        self::validate_context($context);
        require_capability('local/learninganalytics:view', $context);

        $query = trim($params['query']);
        if (\core_text::strlen($query) < 2) {
            return [];
        }

        $fullnamesql = $DB->sql_concat('u.firstname', "' '", 'u.lastname');
        $escaped = '%' . $DB->sql_like_escape($query) . '%';
        $sqlparams = ['q1' => $escaped, 'q2' => $escaped];

        // El autocompletado no debe filtrar usuarios de fuera del ambito.
        $scopewhere = '';
        $scopeids = $scope->get_course_ids();
        if ($scopeids !== null) {
            if (empty($scopeids)) {
                $scopewhere = ' AND 1 = 0';
            } else {
                [$insql, $inparams] = $DB->get_in_or_equal($scopeids, SQL_PARAMS_NAMED, 'scp');
                $scopewhere = " AND EXISTS (
                                   SELECT 1
                                     FROM {user_enrolments} ue_s
                                     JOIN {enrol} e_s ON e_s.id = ue_s.enrolid
                                    WHERE ue_s.userid = u.id AND e_s.courseid {$insql})";
                $sqlparams += $inparams;
            }
        }

        $sql = "SELECT u.id, u.firstname, u.lastname, u.email
                  FROM {user} u
                 WHERE u.deleted = 0 AND u.confirmed = 1
                       AND (" . $DB->sql_like($fullnamesql, ':q1', false) . "
                            OR " . $DB->sql_like('u.email', ':q2', false) . ")
                       {$scopewhere}
              ORDER BY u.lastname, u.firstname";

        $records = $DB->get_records_sql($sql, $sqlparams, 0, 15);

        $out = [];
        foreach ($records as $u) {
            $out[] = [
                'id'    => (int)$u->id,
                'label' => fullname($u),
                'email' => $u->email,
            ];
        }

        return $out;
    }

    /**
     * @return external_multiple_structure
     */
    public static function execute_returns(): external_multiple_structure {
        return new external_multiple_structure(new external_single_structure([
            'id'    => new external_value(PARAM_INT, 'ID de usuario'),
            'label' => new external_value(PARAM_TEXT, 'Nombre completo'),
            'email' => new external_value(PARAM_TEXT, 'Correo'),
        ]));
    }
}
