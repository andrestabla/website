<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_learninganalytics\local\course_report;
use local_learninganalytics\local\scope;

/**
 * Analitica de un curso: progreso, calificaciones y permanencia.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class get_course_report extends external_api {

    /**
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'contextid'   => new external_value(PARAM_INT, 'Contexto del curso'),
            'userid'      => new external_value(PARAM_INT, 'Estudiante concreto', VALUE_DEFAULT, 0),
            'lastaccess'  => new external_value(PARAM_ALPHANUM, '7 | 30 | 90 | older | never', VALUE_DEFAULT, ''),
            'progressmin' => new external_value(PARAM_INT, 'Progreso minimo', VALUE_DEFAULT, 0),
            'progressmax' => new external_value(PARAM_INT, 'Progreso maximo', VALUE_DEFAULT, 100),
            'grademin'    => new external_value(PARAM_INT, 'Calificacion minima', VALUE_DEFAULT, 0),
            'grademax'    => new external_value(PARAM_INT, 'Calificacion maxima', VALUE_DEFAULT, 100),
            'roleid'      => new external_value(PARAM_INT, 'Rol dentro del curso', VALUE_DEFAULT, 0),
        ]);
    }

    /**
     * @param int $contextid
     * @param int $userid
     * @param string $lastaccess
     * @param int $progressmin
     * @param int $progressmax
     * @param int $grademin
     * @param int $grademax
     * @return array
     */
    public static function execute(int $contextid, int $userid = 0, string $lastaccess = '',
            int $progressmin = 0, int $progressmax = 100,
            int $grademin = 0, int $grademax = 100, int $roleid = 0): array {

        $params = self::validate_parameters(self::execute_parameters(), [
            'contextid'   => $contextid,
            'userid'      => $userid,
            'lastaccess'  => $lastaccess,
            'progressmin' => $progressmin,
            'progressmax' => $progressmax,
            'grademin'    => $grademin,
            'grademax'    => $grademax,
            'roleid'      => $roleid,
        ]);

        $scope = scope::from_contextid($params['contextid']);
        $context = $scope->get_context();

        self::validate_context($context);
        require_capability('local/learninganalytics:view', $context);

        if (!\local_learninganalytics\local\licence::has_feature(
                \local_learninganalytics\local\licence::FEATURE_COURSE)) {
            throw new \moodle_exception('lic_required', 'local_learninganalytics');
        }

        // Este informe solo existe a nivel de curso.
        if ($scope->get_level() !== scope::LEVEL_COURSE) {
            throw new \moodle_exception('courseonlyreport', 'local_learninganalytics');
        }

        if (!$scope->is_enabled()) {
            throw new \moodle_exception('levelnotenabled', 'local_learninganalytics');
        }

        $report = new course_report($scope->get_instanceid(), $params);

        return $report->run();
    }

    /**
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        $series = new external_single_structure([
            'labels' => new external_multiple_structure(new external_value(PARAM_TEXT, 'Etiqueta')),
            'values' => new external_multiple_structure(new external_value(PARAM_FLOAT, 'Valor')),
        ]);

        return new external_single_structure([
            'kpis' => new external_single_structure([
                'students'     => new external_value(PARAM_INT, 'Estudiantes'),
                'avgprogress'  => new external_value(PARAM_FLOAT, 'Progreso medio (%)'),
                'avggrade'     => new external_value(PARAM_FLOAT, 'Calificacion media (%)'),
                'gradedcount'  => new external_value(PARAM_INT, 'Estudiantes con nota'),
                'avgtime'      => new external_value(PARAM_INT, 'Tiempo medio (segundos)'),
                'avgtimeformatted' => new external_value(PARAM_TEXT, 'Tiempo medio legible'),
                'totalmodules' => new external_value(PARAM_INT, 'Actividades con seguimiento'),
                'completed'    => new external_value(PARAM_INT, 'Estudiantes al 100%'),
            ]),
            'sections'   => $series,
            'activities' => new external_multiple_structure(new external_single_structure([
                'cmid'        => new external_value(PARAM_INT, 'ID del modulo'),
                'name'        => new external_value(PARAM_TEXT, 'Actividad'),
                'sectionname' => new external_value(PARAM_TEXT, 'Seccion'),
                'modname'     => new external_value(PARAM_PLUGIN, 'Tipo de modulo'),
                'completed'   => new external_value(PARAM_INT, 'Estudiantes que la completaron'),
                'progress'    => new external_value(PARAM_FLOAT, 'Porcentaje de finalizacion'),
                'average'     => new external_value(PARAM_FLOAT, 'Calificacion media (%)', VALUE_OPTIONAL, null, NULL_ALLOWED),
            ])),
            'students' => new external_multiple_structure(new external_single_structure([
                'userid'     => new external_value(PARAM_INT, 'ID'),
                'fullname'   => new external_value(PARAM_TEXT, 'Nombre'),
                'email'      => new external_value(PARAM_TEXT, 'Correo'),
                'progress'   => new external_value(PARAM_FLOAT, 'Progreso (%)'),
                'grade'      => new external_value(PARAM_FLOAT, 'Calificacion (%)', VALUE_OPTIONAL, null, NULL_ALLOWED),
                'lastaccess' => new external_value(PARAM_INT, 'Ultimo acceso (marca de tiempo)'),
                'lastaccessformatted' => new external_value(PARAM_TEXT, 'Ultimo acceso legible'),
                'timespent'  => new external_value(PARAM_INT, 'Permanencia (segundos)'),
                'timespentformatted' => new external_value(PARAM_TEXT, 'Permanencia legible'),
            ])),
            'coursename'    => new external_value(PARAM_TEXT, 'Nombre del curso'),
            'hascompletion' => new external_value(PARAM_BOOL, 'El curso tiene seguimiento de finalizacion'),
            'hasgrades'     => new external_value(PARAM_BOOL, 'El curso tiene calificaciones'),
            'haslogs'       => new external_value(PARAM_BOOL, 'Hay registros para estimar permanencia'),
            'logcapped'     => new external_value(PARAM_BOOL, 'Se alcanzo el tope de registros'),
            'totalmodules'  => new external_value(PARAM_INT, 'Actividades con seguimiento'),
        ]);
    }
}
