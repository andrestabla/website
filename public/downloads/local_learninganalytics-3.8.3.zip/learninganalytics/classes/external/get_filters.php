<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_learninganalytics\local\config;
use local_learninganalytics\local\scope;

/**
 * Devuelve las opciones de los filtros globales.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class get_filters extends external_api {

    /**
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'contextid'  => new external_value(PARAM_INT, 'Contexto del ambito; 0 = plataforma', VALUE_DEFAULT, 0),
            'categoryid' => new external_value(PARAM_INT, 'Categoria seleccionada en la cascada', VALUE_DEFAULT, 0),
        ]);
    }

    /**
     * @return array
     */
    public static function execute(int $contextid = 0, int $categoryid = 0): array {
        global $DB;

        $params = self::validate_parameters(self::execute_parameters(),
            ['contextid' => $contextid, 'categoryid' => $categoryid]);

        $scope = scope::from_contextid($params['contextid']);
        $context = $scope->get_context();

        self::validate_context($context);
        require_capability('local/learninganalytics:view', $context);

        // Sin licencia no se ofrecen filtros: no tendria sentido poblarlos
        // cuando el informe los ignora.
        if (!\local_learninganalytics\local\licence::has_feature(
                \local_learninganalytics\local\licence::FEATURE_FILTERS)) {
            return [
                'categories' => [], 'roles' => [], 'rootcategory' => 0,
                'courses' => [], 'countries' => [], 'domains' => [],
                'estados' => [], 'supervisores' => [],
            ];
        }

        // Cursos: los del ambito, estrechados por la categoria elegida en la
        // cascada, de modo que el desplegable siempre refleje el nivel actual.
        $courses = [];
        $scopeids = $scope->get_course_ids();

        if (!empty($params['categoryid'])) {
            $incategory = \local_learninganalytics\local\scope::courses_in_category(
                (int)$params['categoryid']);
            $scopeids = $scopeids === null
                ? $incategory
                : array_values(array_intersect($scopeids, $incategory));
        }

        if ($scopeids === null) {
            $records = $DB->get_records_select('course', 'id <> ?', [SITEID], 'fullname ASC', 'id, fullname');
        } else if (empty($scopeids)) {
            $records = [];
        } else {
            [$insql, $inparams] = $DB->get_in_or_equal($scopeids, SQL_PARAMS_NAMED, 'sc');
            $records = $DB->get_records_select('course', "id {$insql}", $inparams, 'fullname ASC', 'id, fullname');
        }

        foreach ($records as $c) {
            $courses[] = ['id' => (int)$c->id, 'name' => format_string($c->fullname)];
        }

        // A partir de aqui, TODO se restringe a los usuarios del ambito: un
        // tablero de curso no debe ofrecer dominios ni paises que solo
        // existen en otros cursos de la plataforma.
        $userjoin = '';
        $userwhere = 'u.deleted = 0 AND u.confirmed = 1';
        $userparams = [];

        if ($scopeids !== null) {
            if (empty($scopeids)) {
                $userwhere .= ' AND 1 = 0';
            } else {
                [$insql, $inparams] = $DB->get_in_or_equal($scopeids, SQL_PARAMS_NAMED, 'sc2');
                $userwhere .= " AND EXISTS (
                                   SELECT 1
                                     FROM {user_enrolments} ue_f
                                     JOIN {enrol} e_f ON e_f.id = ue_f.enrolid
                                    WHERE ue_f.userid = u.id AND e_f.courseid {$insql})";
                $userparams += $inparams;
            }
        }

        // Paises presentes en el ambito.
        $countries = $DB->get_fieldset_sql(
            "SELECT DISTINCT u.country FROM {user} u {$userjoin}
              WHERE {$userwhere} AND u.country <> ''", $userparams);
        sort($countries);

        // Dominios: se calculan en PHP porque SUBSTRING_INDEX no existe en
        // PostgreSQL, y solo sobre los usuarios del ambito.
        $emails = $DB->get_fieldset_sql(
            "SELECT u.email FROM {user} u {$userjoin}
              WHERE {$userwhere} AND u.email <> ''", $userparams);
        $domains = [];
        foreach ($emails as $email) {
            $at = strrchr($email, '@');
            if ($at !== false) {
                $domains[\core_text::strtolower(substr($at, 1))] = true;
            }
        }
        $domains = array_keys($domains);
        sort($domains, SORT_NATURAL | SORT_FLAG_CASE);

        // Campos de perfil: vacios si no estan configurados, y limitados a los
        // valores que realmente tienen los usuarios del ambito.
        $estados = [];
        if (($fid = config::estado_fieldid()) !== null) {
            $estados = $DB->get_fieldset_sql(
                "SELECT DISTINCT uid.data
                   FROM {user_info_data} uid
                   JOIN {user} u ON u.id = uid.userid
                  WHERE uid.fieldid = :fid AND uid.data <> '' AND {$userwhere}",
                $userparams + ['fid' => $fid]);
            sort($estados, SORT_NATURAL | SORT_FLAG_CASE);
        }

        $supervisores = [];
        if (($fid = config::supervisor_fieldid()) !== null) {
            $supervisores = $DB->get_fieldset_sql(
                "SELECT DISTINCT uid.data
                   FROM {user_info_data} uid
                   JOIN {user} u ON u.id = uid.userid
                  WHERE uid.fieldid = :fid AND uid.data <> '' AND {$userwhere}",
                $userparams + ['fid' => $fid]);
            sort($supervisores, SORT_NATURAL | SORT_FLAG_CASE);
        }

        return [
            'categories'   => $scope->get_categories(),
            'roles'        => $scope->get_roles(),
            'rootcategory' => $scope->get_root_category(),
            'courses'      => $courses,
            'countries'    => array_values($countries),
            'domains'      => array_values($domains),
            'estados'      => array_values($estados),
            'supervisores' => array_values($supervisores),
        ];
    }

    /**
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'categories' => new external_multiple_structure(new external_single_structure([
                'id'     => new external_value(PARAM_INT, 'ID de la categoria'),
                'name'   => new external_value(PARAM_TEXT, 'Nombre'),
                'parent' => new external_value(PARAM_INT, 'Categoria padre; 0 = raiz'),
                'depth'  => new external_value(PARAM_INT, 'Profundidad'),
            ])),
            'roles' => new external_multiple_structure(new external_single_structure([
                'id'    => new external_value(PARAM_INT, 'ID del rol'),
                'name'  => new external_value(PARAM_TEXT, 'Nombre localizado'),
                'count' => new external_value(PARAM_INT, 'Usuarios con ese rol en el ambito'),
            ])),
            'rootcategory' => new external_value(PARAM_INT, 'Raiz del arbol para este ambito'),
            'courses' => new external_multiple_structure(new external_single_structure([
                'id'   => new external_value(PARAM_INT, 'ID del curso'),
                'name' => new external_value(PARAM_TEXT, 'Nombre del curso'),
            ])),
            'countries'    => new external_multiple_structure(new external_value(PARAM_TEXT, 'Pais')),
            'domains'      => new external_multiple_structure(new external_value(PARAM_TEXT, 'Dominio')),
            'estados'      => new external_multiple_structure(new external_value(PARAM_TEXT, 'Estado')),
            'supervisores' => new external_multiple_structure(new external_value(PARAM_TEXT, 'Supervisor')),
        ]);
    }
}
