<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Callbacks de navegacion.
 *
 * Estos callbacks SIGUEN VIGENTES en Moodle 4.5: navigationlib.php los invoca
 * mediante get_plugins_with_function(). No confundir con el antiguo
 * _before_footer(), que si fue migrado al sistema de hooks PSR-14 y aqui se
 * implementa en db/hooks.php.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use local_learninganalytics\local\scope;

/**
 * Anade el tablero al menu de un curso.
 *
 * @param navigation_node $navigation
 * @param stdClass $course
 * @param context_course $context
 */
function local_learninganalytics_extend_navigation_course($navigation, $course, $context) {
    if (!get_config('local_learninganalytics', 'enablecourse')) {
        return;
    }

    if (!has_capability('local/learninganalytics:view', $context)) {
        return;
    }

    $url = new moodle_url('/local/learninganalytics/index.php', ['contextid' => $context->id]);

    // La pagina /report/view.php lista los HIJOS del nodo 'coursereports', asi
    // que ahi es donde debe colgar un informe para aparecer en «Informes».
    // Colgarlo del nodo raiz solo lo mostraria en el menu «Mas».
    // Este callback se ejecuta despues de que el nucleo cree ese nodo, de modo
    // que a estas alturas ya existe; el fallback cubre temas que lo omitan.
    $reportnode = $navigation->find('coursereports', navigation_node::TYPE_CONTAINER);
    $target = $reportnode ?: $navigation;

    $target->add(
        get_string('pluginname', 'local_learninganalytics'),
        $url,
        navigation_node::TYPE_SETTING,
        null,
        'local_learninganalytics',
        new pix_icon('i/report', '')
    );
}

/**
 * Anade el tablero a los ajustes de una categoria.
 *
 * @param navigation_node $navigation
 * @param context_coursecat $context
 */
function local_learninganalytics_extend_navigation_category_settings($navigation, $context) {
    if (!get_config('local_learninganalytics', 'enablecategory')) {
        return;
    }

    if (!has_capability('local/learninganalytics:view', $context)) {
        return;
    }

    $url = new moodle_url('/local/learninganalytics/index.php', ['contextid' => $context->id]);

    $navigation->add(
        get_string('pluginname', 'local_learninganalytics'),
        $url,
        navigation_node::TYPE_SETTING,
        null,
        'local_learninganalytics_cat',
        new pix_icon('i/report', '')
    );
}

/**
 * Sirve los archivos del plugin.
 *
 * El logo de correo se sirve SIN exigir sesion: quien abre el correo no esta
 * autenticado, y si el archivo requiriese login la imagen no cargaria nunca.
 * Solo se abre esa area concreta; cualquier otra se rechaza.
 *
 * @param stdClass $course
 * @param stdClass $cm
 * @param context $context
 * @param string $filearea
 * @param array $args
 * @param bool $forcedownload
 * @param array $options
 * @return bool false si el archivo no existe o el area no es publica.
 */
function local_learninganalytics_pluginfile($course, $cm, $context, $filearea,
        $args, $forcedownload, array $options = []) {

    if ($context->contextlevel !== CONTEXT_SYSTEM) {
        return false;
    }

    $publicareas = [
        \local_learninganalytics\local\mailer::LOGO_FILEAREA,
        \local_learninganalytics\local\mailer::LOGO_PNG_FILEAREA,
    ];

    if (!in_array($filearea, $publicareas, true)) {
        return false;
    }

    // El primer argumento es el itemid: hay que retirarlo antes de componer
    // la ruta, o quedaria como parte de ella y el archivo no se encontraria.
    $itemid = (int)array_shift($args);
    $filename = array_pop($args);
    $filepath = $args ? '/' . implode('/', $args) . '/' : '/';

    $fs = get_file_storage();
    $file = $fs->get_file($context->id, 'local_learninganalytics', $filearea, $itemid,
        $filepath, $filename);

    if (!$file || $file->is_directory()) {
        return false;
    }

    // Cache larga: el logo cambia rara vez y lo pide cada cliente de correo.
    send_stored_file($file, DAYSECS, 0, $forcedownload, $options);
}
