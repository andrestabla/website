<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics;

use local_learninganalytics\local\config;
use local_learninganalytics\local\report_query;

/**
 * Tests for report_query.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \local_learninganalytics\local\report_query
 */
final class report_query_test extends \advanced_testcase {

    /**
     * Los usuarios con timecreated = 0 no deben producir un punto en 1969-12.
     */
    public function test_growth_excludes_epoch_zero(): void {
        global $DB;
        $this->resetAfterTest();

        $withdate = $this->getDataGenerator()->create_user(['timecreated' => mktime(0, 0, 0, 3, 1, 2025)]);
        $nodate = $this->getDataGenerator()->create_user();
        $DB->set_field('user', 'timecreated', 0, ['id' => $nodate->id]);

        $growth = (new report_query([]))->get_growth();

        $this->assertNotEmpty($growth['labels']);
        foreach ($growth['labels'] as $label) {
            $this->assertStringNotContainsString('1969', $label);
            $this->assertStringNotContainsString('1970', $label);
        }
        $this->assertContains('2025-03', $growth['labels']);
        $this->assertNotNull($withdate);
    }

    /**
     * Los meses deben salir ordenados cronologicamente.
     */
    public function test_growth_is_sorted(): void {
        $this->resetAfterTest();

        $this->getDataGenerator()->create_user(['timecreated' => mktime(0, 0, 0, 9, 1, 2025)]);
        $this->getDataGenerator()->create_user(['timecreated' => mktime(0, 0, 0, 1, 1, 2025)]);
        $this->getDataGenerator()->create_user(['timecreated' => mktime(0, 0, 0, 5, 1, 2025)]);

        $labels = (new report_query([]))->get_growth()['labels'];
        $sorted = $labels;
        sort($sorted);

        $this->assertSame($sorted, $labels);
    }

    /**
     * "Usuarios por dominio" debe devolver los 10 MAYORES, no los 10 primeros.
     */
    public function test_domains_returns_top_ten_by_count(): void {
        $this->resetAfterTest();

        // 12 dominios; "big.example" debe quedar primero por volumen aunque
        // se cree el ultimo.
        for ($i = 1; $i <= 12; $i++) {
            $this->getDataGenerator()->create_user(['email' => "u{$i}@d{$i}.example"]);
        }
        for ($i = 0; $i < 5; $i++) {
            $this->getDataGenerator()->create_user(['email' => "big{$i}@big.example"]);
        }

        $domains = (new report_query([]))->get_domains();

        $this->assertLessThanOrEqual(10, count($domains['labels']));
        $this->assertSame('big.example', $domains['labels'][0]);
        $this->assertSame(5, $domains['values'][0]);
    }

    /**
     * La tasa de certificacion nunca debe superar el 100 %.
     */
    public function test_certification_rate_never_exceeds_hundred(): void {
        $this->resetAfterTest();

        $this->getDataGenerator()->create_user();
        $kpis = (new report_query([]))->get_kpis();

        $this->assertLessThanOrEqual(100, $kpis['certrate']);
        $this->assertGreaterThanOrEqual(0, $kpis['certrate']);
    }

    /**
     * Un filtro sin resultados devuelve estructuras vacias, sin avisos de PHP.
     */
    public function test_empty_filter_returns_empty_structures(): void {
        $this->resetAfterTest();

        $result = (new report_query(['search' => 'no-existe-este-usuario-xyz']))->run();

        $this->assertIsArray($result['users']);
        $this->assertIsArray($result['progress']);
        $this->assertSame([], $result['users']);
        $this->assertSame([], $result['progress']);
        $this->assertSame(0, $result['kpis']['users']);
    }

    /**
     * Sin campos de perfil configurados el informe funciona igual.
     */
    public function test_works_without_profile_fields_configured(): void {
        $this->resetAfterTest();
        config::reset_caches();

        set_config('field_estado', '', 'local_learninganalytics');
        set_config('field_supervisor', '', 'local_learninganalytics');

        $this->getDataGenerator()->create_user();
        $result = (new report_query([]))->run();

        $this->assertFalse($result['hasestado']);
        $this->assertFalse($result['hassupervisor']);
        $this->assertNotEmpty($result['users']);
        $this->assertSame('', $result['users'][0]['estado']);
    }

    /**
     * Varios metodos de matriculacion no deben duplicar al usuario.
     */
    public function test_multiple_enrolments_do_not_duplicate_user(): void {
        $this->resetAfterTest();

        $course = $this->getDataGenerator()->create_course();
        $user = $this->getDataGenerator()->create_user();

        $this->getDataGenerator()->enrol_user($user->id, $course->id, null, 'manual');
        $this->getDataGenerator()->enrol_user($user->id, $course->id, null, 'self');

        $users = (new report_query(['courseid' => $course->id]))->get_users();
        $ids = array_column($users, 'id');

        $this->assertSame(array_unique($ids), $ids);
    }
}
