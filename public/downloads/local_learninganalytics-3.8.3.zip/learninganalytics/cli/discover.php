<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Script de descubrimiento para la migracion.
 *
 * Informa a que corresponden en ESTA plataforma los identificadores que la
 * version anterior tenia cableados, para poder configurarlos correctamente.
 *
 * Uso:  sudo -u <usuario-web> php local/learninganalytics/cli/discover.php
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('CLI_SCRIPT', true);

require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/clilib.php');

cli_heading('Campos de perfil personalizados');
$fields = $DB->get_records('user_info_field', null, 'id', 'id, shortname, name, datatype');
if (!$fields) {
    cli_writeln('  (ninguno definido)');
}
foreach ($fields as $f) {
    cli_writeln(sprintf('%4d  %-24s %-32s %s', $f->id, $f->shortname, $f->name, $f->datatype));
}

cli_heading('Cursos');
foreach ($DB->get_records_select('course', 'id <> ?', [SITEID], 'id', 'id, shortname, fullname') as $c) {
    cli_writeln(sprintf('%4d  %-24s %s', $c->id, $c->shortname, $c->fullname));
}

cli_heading('Tareas (para el mapa de firmas)');
foreach ($DB->get_records('assign', null, 'course, id', 'id, course, name') as $a) {
    cli_writeln(sprintf('%4d  curso %-4d %s', $a->id, $a->course, $a->name));
}

cli_heading('Requisitos');
$dbman = $DB->get_manager();
cli_writeln('mod_customcert .......... ' . ($dbman->table_exists('customcert') ? 'SI' : 'NO'));
cli_writeln('Motor de BD ............. ' . $CFG->dbtype);
cli_writeln('Release ................. ' . $CFG->release);
cli_writeln('PHP ..................... ' . PHP_VERSION);

cli_heading('Ajustes actuales del plugin');
foreach (['field_estado', 'field_supervisor', 'sender_username', 'signature_map'] as $name) {
    $value = get_config('local_learninganalytics', $name);
    cli_writeln(sprintf('%-18s = %s', $name, ($value === false || $value === '') ? '(sin configurar)' : $value));
}

cli_heading('Calidad de datos');
cli_writeln('Usuarios con timecreated = 0: ' .
    $DB->count_records_select('user', 'deleted = 0 AND confirmed = 1 AND timecreated = 0'));
cli_writeln('Usuarios activos: ' . $DB->count_records('user', ['deleted' => 0, 'confirmed' => 1]));
cli_writeln('Matriculaciones: ' . $DB->count_records('user_enrolments'));
