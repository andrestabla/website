<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_learninganalytics\local\report_query;
use local_learninganalytics\local\scope;

/**
 * Devuelve los datos analiticos del dashboard.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class get_report extends external_api {

    /**
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid'   => new external_value(PARAM_INT, 'ID de curso, 0 = todos', VALUE_DEFAULT, 0),
            'country'    => new external_value(PARAM_ALPHA, 'Codigo ISO de pais', VALUE_DEFAULT, ''),
            'domain'     => new external_value(PARAM_HOST, 'Dominio de correo', VALUE_DEFAULT, ''),
            'estado'     => new external_value(PARAM_TEXT, 'Estado', VALUE_DEFAULT, ''),
            'supervisor' => new external_value(PARAM_TEXT, 'Supervisor', VALUE_DEFAULT, ''),
            'startdate'  => new external_value(PARAM_INT, 'Marca de tiempo inicial', VALUE_DEFAULT, 0),
            'enddate'    => new external_value(PARAM_INT, 'Marca de tiempo final', VALUE_DEFAULT, 0),
            'userid'     => new external_value(PARAM_INT, 'Usuario concreto', VALUE_DEFAULT, 0),
            'search'     => new external_value(PARAM_TEXT, 'Busqueda por nombre o correo', VALUE_DEFAULT, ''),
            'contextid'  => new external_value(PARAM_INT, 'Contexto del ambito; 0 = plataforma', VALUE_DEFAULT, 0),
            'categoryid' => new external_value(PARAM_INT, 'Categoria seleccionada en la cascada', VALUE_DEFAULT, 0),
            'roleid'     => new external_value(PARAM_INT, 'Rol dentro del ambito', VALUE_DEFAULT, 0),
        ]);
    }

    /**
     * @param int $courseid
     * @param string $country
     * @param string $domain
     * @param string $estado
     * @param string $supervisor
     * @param int $startdate
     * @param int $enddate
     * @param int $userid
     * @param string $search
     * @return array
     */
    public static function execute(int $courseid = 0, string $country = '', string $domain = '',
            string $estado = '', string $supervisor = '', int $startdate = 0, int $enddate = 0,
            int $userid = 0, string $search = '', int $contextid = 0, int $categoryid = 0, int $roleid = 0): array {

        $params = self::validate_parameters(self::execute_parameters(), [
            'courseid'   => $courseid,
            'country'    => $country,
            'domain'     => $domain,
            'estado'     => $estado,
            'supervisor' => $supervisor,
            'startdate'  => $startdate,
            'enddate'    => $enddate,
            'userid'     => $userid,
            'search'     => $search,
            'contextid'  => $contextid,
            'categoryid' => $categoryid,
            'roleid'     => $roleid,
        ]);

        // El ambito lo fija el contexto solicitado, y la capacidad se
        // comprueba CONTRA ESE contexto: un profesor con permiso en su curso
        // no puede pedir el contexto de otro curso ni el de plataforma.
        $scope = scope::from_contextid($params['contextid']);
        $context = $scope->get_context();

        self::validate_context($context);
        // Esta comprobacion es la que faltaba en ajax.php: sin ella cualquier
        // usuario autenticado podia descargar el padron completo.
        require_capability('local/learninganalytics:view', $context);

        if (!$scope->is_enabled()) {
            throw new \moodle_exception('levelnotenabled', 'local_learninganalytics');
        }

        return (new report_query($params, $scope))->run();
    }

    /**
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        $series = new external_single_structure([
            'labels' => new external_multiple_structure(new external_value(PARAM_TEXT, 'Etiqueta')),
            'values' => new external_multiple_structure(new external_value(PARAM_INT, 'Valor')),
        ]);

        $countryseries = new external_single_structure([
            'labels' => new external_multiple_structure(new external_value(PARAM_TEXT, 'Nombre de pais')),
            'values' => new external_multiple_structure(new external_value(PARAM_INT, 'Usuarios')),
            'codes'  => new external_multiple_structure(new external_value(PARAM_TEXT, 'Codigo ISO')),
        ]);

        // Los cursos llevan identificador para poder filtrar al pulsar la barra.
        $courseseries = new external_single_structure([
            'labels' => new external_multiple_structure(new external_value(PARAM_TEXT, 'Nombre del curso')),
            'values' => new external_multiple_structure(new external_value(PARAM_INT, 'Matriculaciones')),
            'ids'    => new external_multiple_structure(new external_value(PARAM_INT, 'ID del curso')),
        ]);

        return new external_single_structure([
            'kpis' => new external_single_structure([
                'users'        => new external_value(PARAM_INT, 'Usuarios'),
                'enrolments'   => new external_value(PARAM_INT, 'Matriculaciones'),
                'certificates' => new external_value(PARAM_INT, 'Certificados emitidos'),
                'certrate'     => new external_value(PARAM_FLOAT, 'Tasa de certificacion'),
            ]),
            'growth'       => $series,
            'domains'      => $series,
            'countries'    => $countryseries,
            'certificates' => $series,
            'activity'     => $series,
            'topcourses'   => $courseseries,
            'certsplit'    => $series,
            'users' => new external_multiple_structure(new external_single_structure([
                'id'          => new external_value(PARAM_INT, 'ID'),
                'fullname'    => new external_value(PARAM_TEXT, 'Nombre completo'),
                'email'       => new external_value(PARAM_TEXT, 'Correo'),
                'country'     => new external_value(PARAM_TEXT, 'Pais'),
                'estado'      => new external_value(PARAM_TEXT, 'Estado'),
                'supervisor'  => new external_value(PARAM_TEXT, 'Supervisor'),
                'lastaccess'  => new external_value(PARAM_TEXT, 'Ultimo acceso'),
                'timecreated' => new external_value(PARAM_INT, 'Fecha de creacion'),
            ])),
            'progress' => new external_multiple_structure(new external_single_structure([
                'userid'     => new external_value(PARAM_INT, 'ID de usuario'),
                'fullname'   => new external_value(PARAM_TEXT, 'Nombre completo'),
                'email'      => new external_value(PARAM_TEXT, 'Correo'),
                'courseid'   => new external_value(PARAM_INT, 'ID de curso'),
                'coursename' => new external_value(PARAM_TEXT, 'Curso'),
                'signed'     => new external_value(PARAM_ALPHA, 'yes | no | na'),
                'timestart'  => new external_value(PARAM_TEXT, 'Inicio de matricula'),
            ])),
            'hascerts'      => new external_value(PARAM_BOOL, 'mod_customcert disponible'),
            'hasestado'     => new external_value(PARAM_BOOL, 'Campo Estado configurado'),
            'hassupervisor' => new external_value(PARAM_BOOL, 'Campo Supervisor configurado'),
            'scopelevel'    => new external_value(PARAM_ALPHA, 'site | category | course'),
            'generated'     => new external_value(PARAM_INT, 'Momento del calculo, en segundos'),
        ]);
    }
}
