<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;

/**
 * Privacy provider.
 *
 * El plugin guarda una cosa suya: el historico de consultas de IA de cada
 * usuario (pregunta y respuesta). Ademas, cuando la analitica conversacional
 * esta activa, la pregunta viaja con cifras agregadas del tablero a Algoritmo
 * T, que la procesa con un proveedor de IA. Ambas cosas se declaran aqui, y
 * el historico se puede exportar y borrar por usuario, que es exactamente lo
 * que un responsable de datos va a pedir.
 *
 * Los tableros en si no almacenan nada: presentan datos que ya existen en
 * Moodle. La auditoria del reenvio de credenciales usa la API de eventos,
 * cuya privacidad gestionan los almacenes de registro del nucleo.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider,
    \core_privacy\local\request\core_userlist_provider {

    /**
     * Declara los datos que el plugin guarda y los que envia fuera.
     *
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('local_learninganalytics_ai', [
            'userid'      => 'privacy:metadata:ai:userid',
            'contextid'   => 'privacy:metadata:ai:contextid',
            'mode'        => 'privacy:metadata:ai:mode',
            'question'    => 'privacy:metadata:ai:question',
            'answer'      => 'privacy:metadata:ai:answer',
            'timecreated' => 'privacy:metadata:ai:timecreated',
        ], 'privacy:metadata:ai');

        $collection->add_external_location_link('algoritmot', [
            'question' => 'privacy:metadata:algoritmot:question',
            'series'   => 'privacy:metadata:algoritmot:series',
        ], 'privacy:metadata:algoritmot');

        return $collection;
    }

    /**
     * Contextos donde el usuario tiene consultas guardadas.
     *
     * @param int $userid
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();

        $contextlist->add_from_sql(
            "SELECT DISTINCT ctx.id
               FROM {context} ctx
               JOIN {local_learninganalytics_ai} ai ON ai.contextid = ctx.id
              WHERE ai.userid = :userid",
            ['userid' => $userid]
        );

        return $contextlist;
    }

    /**
     * Usuarios con consultas guardadas en un contexto.
     *
     * @param userlist $userlist
     */
    public static function get_users_in_context(userlist $userlist): void {
        $userlist->add_from_sql('userid',
            "SELECT userid FROM {local_learninganalytics_ai} WHERE contextid = :contextid",
            ['contextid' => $userlist->get_context()->id]
        );
    }

    /**
     * Exporta el historico de consultas del usuario, contexto a contexto.
     *
     * @param approved_contextlist $contextlist
     */
    public static function export_user_data(approved_contextlist $contextlist): void {
        global $DB;

        $userid = $contextlist->get_user()->id;

        foreach ($contextlist->get_contexts() as $context) {
            $records = $DB->get_records('local_learninganalytics_ai',
                ['userid' => $userid, 'contextid' => $context->id], 'timecreated ASC');

            if (empty($records)) {
                continue;
            }

            $queries = [];
            foreach ($records as $r) {
                $queries[] = (object)[
                    'question'    => $r->question,
                    'answer'      => $r->answer,
                    'mode'        => $r->mode,
                    'timecreated' => \core_privacy\local\request\transform::datetime($r->timecreated),
                ];
            }

            writer::with_context($context)->export_data(
                [get_string('ai_history', 'local_learninganalytics')],
                (object)['queries' => $queries]
            );
        }
    }

    /**
     * Borra todas las consultas guardadas en un contexto.
     *
     * @param \context $context
     */
    public static function delete_data_for_all_users_in_context(\context $context): void {
        global $DB;
        $DB->delete_records('local_learninganalytics_ai', ['contextid' => $context->id]);
    }

    /**
     * Borra las consultas del usuario en los contextos aprobados.
     *
     * @param approved_contextlist $contextlist
     */
    public static function delete_data_for_user(approved_contextlist $contextlist): void {
        global $DB;

        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            $DB->delete_records('local_learninganalytics_ai',
                ['userid' => $userid, 'contextid' => $context->id]);
        }
    }

    /**
     * Borra las consultas de una lista de usuarios en un contexto.
     *
     * @param approved_userlist $userlist
     */
    public static function delete_data_for_users(approved_userlist $userlist): void {
        global $DB;

        $userids = $userlist->get_userids();
        if (empty($userids)) {
            return;
        }

        [$insql, $params] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'pu');
        $params['contextid'] = $userlist->get_context()->id;
        $DB->delete_records_select('local_learninganalytics_ai',
            "contextid = :contextid AND userid {$insql}", $params);
    }
}
