<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Descarga del informe en CSV, XLSX o PDF.
 *
 * Recibe los FILTROS y recalcula los datos en el servidor, aplicando capacidad
 * y ambito: nadie puede descargar por parametro lo que no veria en el tablero.
 *
 * Las imagenes de las graficas llegan desde el navegador como PNG en base64,
 * porque el servidor no puede dibujar un lienzo de Chart.js.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../config.php');

use local_learninganalytics\local\exporter;
use local_learninganalytics\local\scope;

$contextid = optional_param('contextid', 0, PARAM_INT);
$format    = optional_param('format', 'csv', PARAM_ALPHA);
$target    = optional_param('target', 'all', PARAM_ALPHANUMEXT);

require_login();
require_sesskey();

$scope = scope::from_contextid($contextid);
$context = $scope->get_context();

require_capability('local/learninganalytics:view', $context);

if (!$scope->is_enabled()) {
    throw new moodle_exception('levelnotenabled', 'local_learninganalytics');
}

$filterdefs = [
    'courseid' => PARAM_INT, 'categoryid' => PARAM_INT, 'roleid' => PARAM_INT,
    'country' => PARAM_ALPHA, 'domain' => PARAM_HOST, 'estado' => PARAM_TEXT,
    'supervisor' => PARAM_TEXT, 'startdate' => PARAM_INT, 'enddate' => PARAM_INT,
    'userid' => PARAM_INT, 'search' => PARAM_TEXT, 'lastaccess' => PARAM_ALPHANUM,
    'progressmin' => PARAM_INT, 'progressmax' => PARAM_INT,
    'grademin' => PARAM_INT, 'grademax' => PARAM_INT,
];

$filters = [];
foreach ($filterdefs as $name => $type) {
    $default = in_array($name, ['progressmax', 'grademax'], true) ? 100 : 0;
    if (in_array($type, [PARAM_TEXT, PARAM_ALPHA, PARAM_HOST, PARAM_ALPHANUM], true)) {
        $default = '';
    }
    $filters[$name] = optional_param($name, $default, $type);
}
$filters['contextid'] = $contextid;

// CSV es parte del nivel gratuito; el resto de formatos, de la licencia.
if ($format !== 'csv'
        && !\local_learninganalytics\local\licence::has_feature(
            \local_learninganalytics\local\licence::FEATURE_EXPORT)) {
    throw new moodle_exception('lic_required', 'local_learninganalytics');
}

$exporter = new exporter($scope, $filters);
$datasets = $exporter->get_datasets($target);

$stub = clean_filename(strtolower($exporter->get_report_title()));
$stub = preg_replace('/[^a-z0-9]+/', '-', \core_text::specialtoascii($stub));
$stub = trim($stub, '-') ?: 'learning-analytics';
$filename = $stub . '-' . userdate(time(), '%Y%m%d-%H%M');

switch ($format) {

    // ---------------------------------------------------------------------
    case 'csv':
        require_once($CFG->libdir . '/csvlib.class.php');

        $csv = new csv_export_writer();
        $csv->set_filename($filename);

        foreach ($datasets as $i => $dataset) {
            if ($i > 0) {
                $csv->add_data(['']);   // Linea en blanco entre secciones.
            }
            $csv->add_data([$dataset['title']]);
            $csv->add_data($dataset['headers']);
            foreach ($dataset['rows'] as $row) {
                $csv->add_data($row);
            }
        }

        $csv->download_file();
        break;

    // ---------------------------------------------------------------------
    case 'xlsx':
        require_once($CFG->libdir . '/excellib.class.php');

        $workbook = new MoodleExcelWorkbook('-');
        $workbook->send($filename);

        $used = [];
        foreach ($datasets as $dataset) {
            // Excel limita el nombre de hoja a 31 caracteres y no admite duplicados.
            $name = \core_text::substr($dataset['title'], 0, 28);
            $suffix = 1;
            $base = $name;
            while (isset($used[$name])) {
                $name = $base . ' ' . (++$suffix);
            }
            $used[$name] = true;

            $sheet = $workbook->add_worksheet($name);
            $bold = $workbook->add_format(['bold' => 1]);

            foreach ($dataset['headers'] as $col => $header) {
                $sheet->write_string(0, $col, $header, $bold);
            }

            foreach ($dataset['rows'] as $r => $row) {
                foreach ($row as $c => $value) {
                    if (is_int($value) || is_float($value)) {
                        $sheet->write_number($r + 1, $c, $value);
                    } else {
                        $sheet->write_string($r + 1, $c, (string)$value);
                    }
                }
            }
        }

        $workbook->close();
        break;

    // ---------------------------------------------------------------------
    case 'pdf':
        // Las imagenes llegan del navegador porque el servidor no puede
        // dibujar un lienzo de Chart.js. Cada una viene con su titulo.
        $images = optional_param_array('images', [], PARAM_RAW);
        $titles = optional_param_array('imagetitles', [], PARAM_TEXT);

        $charts = [];
        foreach ($images as $i => $data) {
            $binary = local_learninganalytics_decode_png($data);
            if ($binary === null) {
                continue;
            }
            $path = make_request_directory() . '/chart' . $i . '.png';
            file_put_contents($path, $binary);
            $charts[] = [
                'path'  => $path,
                'title' => $titles[$i] ?? '',
            ];
        }

        // El analisis de IA que este visible en el tablero viaja con el
        // formulario y se incluye como seccion. No se genera aqui: incluirlo
        // no gasta ninguna consulta de la bolsa.
        $aiquestion = optional_param('aiquestion', '', PARAM_TEXT);
        $aitext = optional_param('aitext', '', PARAM_TEXT);

        $report = new \local_learninganalytics\local\pdf_report($exporter);
        if ($aitext !== '') {
            $report->set_ai_section($aiquestion, $aitext);
        }
        $pdf = $report->render($datasets, $charts);

        send_file($pdf, $filename . '.pdf', 0, 0, true, true, 'application/pdf');
        break;

    // ---------------------------------------------------------------------
    default:
        throw new moodle_exception('exp_unknownformat', 'local_learninganalytics');
}

/**
 * Decodifica un PNG recibido como data URI.
 *
 * @param string $data
 * @return string|null
 */
function local_learninganalytics_decode_png(string $data): ?string {
    if (strpos($data, 'data:image/png;base64,') !== 0) {
        return null;
    }

    $binary = base64_decode(substr($data, 22), true);

    // Se comprueba la firma PNG: no basta con que el prefijo diga que lo es.
    if ($binary === false || substr($binary, 0, 8) !== "\x89PNG\r\n\x1a\n") {
        return null;
    }

    return $binary;
}
