<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Learning Analytics dashboard (plataforma, categoria o curso).
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../config.php');

use local_learninganalytics\local\config;
use local_learninganalytics\local\report_query;
use local_learninganalytics\local\licence;
use local_learninganalytics\local\scope;

$contextid = optional_param('contextid', 0, PARAM_INT);

require_login();

$scope = scope::from_contextid($contextid);
$context = $scope->get_context();

// La capacidad se comprueba contra el contexto del ambito: un profesor con el
// permiso en su curso pasa aqui, pero no en el contexto de sistema.
require_capability('local/learninganalytics:view', $context);

// Un nivel desactivado en los ajustes no es accesible ni por URL directa.
if (!$scope->is_enabled()) {
    throw new moodle_exception('levelnotenabled', 'local_learninganalytics', new moodle_url('/'));
}

$PAGE->set_context($context);
$PAGE->set_url($scope->get_url());
$PAGE->set_title(get_string('dashboard', 'local_learninganalytics'));
$PAGE->set_heading($scope->get_heading());

// En curso y categoria la pagina cuelga de su propia navegacion.
if ($scope->get_level() === scope::LEVEL_COURSE) {
    $PAGE->set_pagelayout('incourse');
    $PAGE->set_course($DB->get_record('course', ['id' => $scope->get_instanceid()], '*', MUST_EXIST));
} else if ($scope->get_level() === scope::LEVEL_CATEGORY) {
    $PAGE->set_pagelayout('admin');
    $PAGE->set_secondary_active_tab('local_learninganalytics_cat');
} else {
    $PAGE->set_pagelayout('report');
}

// El aviso de "campos sin configurar" solo tiene sentido si la plataforma
// tiene campos de perfil personalizados que mapear. Si no hay ninguno, no hay
// nada que configurar y el aviso seria ruido.
$hasprofilefields = $DB->record_exists_select('user_info_field', '1 = 1');

// La accion de correo depende de la capacidad propia del plugin, no de la
// mensajeria interna de Moodle: son canales distintos.
$canmessage = has_capability('local/learninganalytics:sendmessage', $context);

$templatedata = [
    'contextid'     => (int)$context->id,
    'hasprofilefields' => $hasprofilefields,
    'canmessage'    => $canmessage && licence::has_feature(licence::FEATURE_MESSAGING),
    'licensed'      => licence::get_status()->valid,
    'showupsell'    => !licence::get_status()->valid
                          && has_capability('moodle/site:config', context_system::instance()),
    'ecosystemurl'  => 'https://www.algoritmot.com/learning_analytics',
    'canbulkmessage' => $canmessage
        && licence::has_feature(licence::FEATURE_MESSAGING)
        && has_capability('local/learninganalytics:sendbulkmessage', $context),
    'bulkmessageurl' => (new moodle_url('/local/learninganalytics/bulkmessage.php'))->out(false),
    'exporturl'     => (new moodle_url('/local/learninganalytics/export.php'))->out(false),
    'aihistory'     => local_learninganalytics_ai_history(),
    'aienabled'     => licence::ai_status()->enabled,
    'airemaining'   => licence::ai_status()->remaining,
    'scopelevel'    => $scope->get_level(),
    'iscourse'      => $scope->get_level() === scope::LEVEL_COURSE,
    'hascerts'      => report_query::certificates_available(),
    'hasestado'     => config::estado_fieldid() !== null,
    'hassupervisor' => config::supervisor_fieldid() !== null,
    'canresend'     => has_capability('local/learninganalytics:resendcredentials',
                          context_system::instance()),
    'cansettings'   => has_capability('moodle/site:config', context_system::instance()),
    'settingsurl'   => (new moodle_url('/admin/settings.php',
                          ['section' => 'local_learninganalytics_settings']))->out(false),
];

// Las librerias las resuelve AMD y los estilos los carga Moodle desde
// styles.css: ni una etiqueta <script> ni dependencias de CDN.
$PAGE->requires->js_call_amd('local_learninganalytics/dashboard', 'init',
    [['contextid' => (int)$context->id, 'wwwroot' => $CFG->wwwroot]]);

echo $OUTPUT->header();
echo $OUTPUT->render_from_template('local_learninganalytics/dashboard', $templatedata);

/**
 * Ultimas consultas de IA del usuario actual, listas para la plantilla.
 *
 * Solo las propias: el historico es personal, no de la plataforma.
 *
 * @return array
 */
function local_learninganalytics_ai_history(): array {
    global $DB, $USER;

    $out = [];
    try {
        $records = $DB->get_records('local_learninganalytics_ai',
            ['userid' => $USER->id], 'timecreated DESC',
            'id, mode, question, answer, timecreated', 0, 20);
    } catch (\dml_exception $e) {
        // La tabla aparece con la actualizacion: si aun no existe, el tablero
        // no debe caerse por el historico.
        return $out;
    }

    foreach ($records as $r) {
        $out[] = [
            'question'  => $r->question,
            'answer'    => $r->answer,
            'date'      => userdate($r->timecreated, get_string('strftimedatetimeshort', 'langconfig')),
            'modelabel' => get_string($r->mode === 'report' ? 'ai_mode_report' : 'ai_mode_answer',
                'local_learninganalytics'),
        ];
    }
    return $out;
}
echo $OUTPUT->footer();
