<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

defined('MOODLE_INTERNAL') || die();

/**
 * Pasos de actualizacion del plugin.
 *
 * @param int $oldversion
 * @return bool
 */
function xmldb_local_learninganalytics_upgrade($oldversion) {
    global $DB;

    if ($oldversion < 2026082406) {
        // La marca de la ultima comprobacion de IA se escribe ANTES de salir a
        // la red, para que dos peticiones simultaneas no consulten a la vez.
        // El efecto colateral es que un intento fallido deja la marca puesta y
        // bloquea el reintento durante horas. Al actualizar se borra: asi una
        // plataforma que acaba de contratar la funcion la ve de inmediato en
        // vez de esperar a la revalidacion del dia siguiente.
        unset_config('aicheck', 'local_learninganalytics');

        upgrade_plugin_savepoint(true, 2026082406, 'local', 'learninganalytics');
    }

    if ($oldversion < 2026082412) {
        // Historico de consultas de IA. Las instalaciones nuevas lo crean via
        // install.xml; las existentes pasan por aqui.
        $dbman = $DB->get_manager();
        $table = new xmldb_table('local_learninganalytics_ai');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('contextid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('mode', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, 'answer');
        $table->add_field('question', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL);
        $table->add_field('answer', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_index('useridtime', XMLDB_INDEX_NOTUNIQUE, ['userid', 'timecreated']);
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }
        upgrade_plugin_savepoint(true, 2026082412, 'local', 'learninganalytics');
    }

    return true;
}
