<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Envio masivo de mensajes a los usuarios que devuelve un filtro.
 *
 * Flujo en dos pasos deliberado: primero se muestra a cuantas personas y a
 * quienes va a llegar el mensaje, y solo despues se envia. La lista se
 * recalcula siempre en el servidor a partir de los filtros, respetando la
 * capacidad y el ambito, de modo que nadie puede alcanzar por parametro a
 * usuarios que no veria en el tablero.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../config.php');

use core_message\api as message_api;
use local_learninganalytics\form\bulkmessage_form;
use local_learninganalytics\local\course_report;
use local_learninganalytics\local\report_query;
use local_learninganalytics\local\scope;

$contextid = optional_param('contextid', 0, PARAM_INT);
$source    = optional_param('source', 'report', PARAM_ALPHA);

require_login();

$scope = scope::from_contextid($contextid);
$context = $scope->get_context();

require_capability('local/learninganalytics:sendbulkmessage', $context);

if (!$scope->is_enabled()) {
    throw new moodle_exception('levelnotenabled', 'local_learninganalytics');
}

if (empty($CFG->messaging)) {
    throw new moodle_exception('messagingdisabled', 'local_learninganalytics');
}

if (!\local_learninganalytics\local\licence::has_feature(
        \local_learninganalytics\local\licence::FEATURE_MESSAGING)) {
    throw new moodle_exception('lic_required', 'local_learninganalytics');
}

$returnurl = $scope->get_url();

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/learninganalytics/bulkmessage.php', ['contextid' => $contextid]));
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('bulkmessage', 'local_learninganalytics'));
$PAGE->set_heading(get_string('bulkmessage', 'local_learninganalytics'));

// ---------------------------------------------------------------------------
// Filtros: se recogen con su tipo y se reenvian como campos ocultos.
// ---------------------------------------------------------------------------
$filterdefs = [
    'courseid'    => PARAM_INT,
    'categoryid'  => PARAM_INT,
    'roleid'      => PARAM_INT,
    'country'     => PARAM_ALPHA,
    'domain'      => PARAM_HOST,
    'estado'      => PARAM_TEXT,
    'supervisor'  => PARAM_TEXT,
    'startdate'   => PARAM_INT,
    'enddate'     => PARAM_INT,
    'userid'      => PARAM_INT,
    'search'      => PARAM_TEXT,
    'lastaccess'  => PARAM_ALPHANUM,
    'progressmin' => PARAM_INT,
    'progressmax' => PARAM_INT,
    'grademin'    => PARAM_INT,
    'grademax'    => PARAM_INT,
    'status'      => PARAM_ALPHA,
];

$filters = [];
foreach ($filterdefs as $name => $type) {
    $default = in_array($name, ['progressmax', 'grademax'], true) ? 100 : 0;
    if (in_array($type, [PARAM_TEXT, PARAM_ALPHA, PARAM_HOST, PARAM_ALPHANUM], true)) {
        $default = '';
    }
    $filters[$name] = optional_param($name, $default, $type);
}
$filters['contextid'] = $contextid;

// ---------------------------------------------------------------------------
// Destinatarios: recalculados en el servidor, nunca recibidos del navegador.
// ---------------------------------------------------------------------------
if ($source === 'course' && $scope->get_level() === scope::LEVEL_COURSE) {
    $data = (new course_report($scope->get_instanceid(), $filters))->run();
    $recipients = array_map(fn($r) => (object)[
        'id' => $r['userid'], 'fullname' => $r['fullname'],
    ], $data['students']);
} else {
    $data = (new report_query($filters, $scope))->run();
    $recipients = array_map(fn($r) => (object)[
        'id' => $r['id'], 'fullname' => $r['fullname'],
    ], $data['users']);
}

// Nunca escribirse a uno mismo en un envio masivo.
$recipients = array_values(array_filter($recipients, fn($r) => $r->id != $USER->id));

$limit = (int)get_config('local_learninganalytics', 'bulkmessagelimit');
if ($limit <= 0) {
    $limit = 200;
}

$hidden = array_merge($filters, ['source' => $source]);
$form = new bulkmessage_form($PAGE->url, ['hidden' => $hidden]);

// ---------------------------------------------------------------------------
// Envio.
// ---------------------------------------------------------------------------
if ($form->is_cancelled()) {
    redirect($returnurl);
}

$submitted = $form->get_data();

if ($submitted && !empty($recipients) && count($recipients) <= $limit) {
    require_sesskey();

    $text = trim($submitted->messagetext);
    $channel = ($submitted->channel ?? 'email') === 'message' ? 'message' : 'email';
    $subject = trim($submitted->subject ?? '');
    $sent = $blocked = $failed = 0;
    $details = [];

    // El cuerpo maquetado se genera una sola vez: es igual para todos.
    $html = $channel === 'email'
        ? \local_learninganalytics\local\mailer::render_html($text)
        : '';

    foreach ($recipients as $recipient) {
        $user = $DB->get_record('user', ['id' => $recipient->id, 'deleted' => 0]);
        if (!$user) {
            continue;
        }

        if ($channel === 'email') {
            // Sin direccion no hay envio posible, y conviene decirlo.
            if (empty($user->email)) {
                $blocked++;
                $details[] = ['name' => $recipient->fullname, 'status' => 'noaddress'];
                continue;
            }

            if (email_to_user($user, $USER, $subject, $text, $html)) {
                \local_learninganalytics\event\bulk_message_sent::create([
                    'context'       => $context,
                    'objectid'      => $recipient->id,
                    'relateduserid' => $recipient->id,
                ])->trigger();

                $sent++;
                $details[] = ['name' => $recipient->fullname, 'status' => 'sent'];
            } else {
                $failed++;
                $details[] = ['name' => $recipient->fullname, 'status' => 'failed'];
            }

            continue;
        }

        // Mensajeria interna: respeta privacidad y bloqueos del destinatario.
        if (!message_api::can_send_message($recipient->id, $USER->id)) {
            $blocked++;
            $details[] = ['name' => $recipient->fullname, 'status' => 'blocked'];
            continue;
        }

        try {
            $conversationid = message_api::get_conversation_between_users([$USER->id, $recipient->id]);

            if (!$conversationid) {
                $conversation = message_api::create_conversation(
                    message_api::MESSAGE_CONVERSATION_TYPE_INDIVIDUAL,
                    [$USER->id, $recipient->id]
                );
                $conversationid = $conversation->id;
            }

            message_api::send_message_to_conversation(
                $USER->id, $conversationid, $text, FORMAT_PLAIN);

            // Auditoria por destinatario: quien, a quien y cuando.
            \local_learninganalytics\event\bulk_message_sent::create([
                'context'       => $context,
                'objectid'      => $recipient->id,
                'relateduserid' => $recipient->id,
            ])->trigger();

            $sent++;
            $details[] = ['name' => $recipient->fullname, 'status' => 'sent'];
        } catch (Throwable $e) {
            $failed++;
            $details[] = ['name' => $recipient->fullname, 'status' => 'failed'];
        }
    }

    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('bulkmessageresults', 'local_learninganalytics'), 3);

    echo $OUTPUT->notification(
        get_string('bulkmessagesummary', 'local_learninganalytics',
            (object)['sent' => $sent, 'blocked' => $blocked, 'failed' => $failed]),
        $sent > 0 ? \core\output\notification::NOTIFY_SUCCESS
                  : \core\output\notification::NOTIFY_WARNING
    );

    if ($blocked > 0 || $failed > 0) {
        $list = [];
        foreach ($details as $d) {
            if ($d['status'] !== 'sent') {
                $list[] = html_writer::tag('li', s($d['name']) . ' — ' .
                    get_string('bulkmessage' . $d['status'], 'local_learninganalytics'));
            }
        }
        echo html_writer::tag('ul', implode('', $list));
    }

    echo $OUTPUT->continue_button($returnurl);
    echo $OUTPUT->footer();
    exit;
}

// ---------------------------------------------------------------------------
// Confirmacion.
// ---------------------------------------------------------------------------
echo $OUTPUT->header();

if (empty($recipients)) {
    echo $OUTPUT->notification(
        get_string('bulkmessagenorecipients', 'local_learninganalytics'),
        \core\output\notification::NOTIFY_WARNING);
    echo $OUTPUT->continue_button($returnurl);
    echo $OUTPUT->footer();
    exit;
}

if (count($recipients) > $limit) {
    // Se rechaza en lugar de recortar: un envio truncado en silencio es peor
    // que uno que no sale.
    echo $OUTPUT->notification(
        get_string('bulkmessagetoomany', 'local_learninganalytics',
            (object)['count' => count($recipients), 'limit' => $limit]),
        \core\output\notification::NOTIFY_ERROR);
    echo $OUTPUT->continue_button($returnurl);
    echo $OUTPUT->footer();
    exit;
}

echo $OUTPUT->heading(get_string('bulkmessageconfirm', 'local_learninganalytics',
    count($recipients)), 3);

// La lista completa a la vista: quien envia debe ver exactamente a quien llega.
$names = [];
foreach ($recipients as $r) {
    $names[] = html_writer::tag('li', s($r->fullname));
}

echo html_writer::start_div('card mb-3');
echo html_writer::start_div('card-body');
echo html_writer::tag('p', get_string('bulkmessagerecipients', 'local_learninganalytics'));
echo html_writer::tag('ul', implode('', $names),
    ['class' => 'local-la-recipients', 'style' => 'max-height:16rem;overflow-y:auto;']);
echo html_writer::end_div();
echo html_writer::end_div();

$form->display();

echo $OUTPUT->footer();
