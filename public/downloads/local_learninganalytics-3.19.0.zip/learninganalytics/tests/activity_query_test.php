<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics;

use local_learninganalytics\local\activity_query;
use local_learninganalytics\task\aggregate_time;

/**
 * Tests de la regla de actividad significativa y de la agregacion de tiempo.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \local_learninganalytics\local\activity_query
 * @covers     \local_learninganalytics\task\aggregate_time
 */
final class activity_query_test extends \advanced_testcase {

    /**
     * Inserta una fila de permanencia.
     *
     * @param int $userid
     * @param int $courseid
     * @param int $day
     * @param int $seconds
     * @param int $events
     */
    protected function row(int $userid, int $courseid, int $day, int $seconds, int $events = 1): void {
        global $DB;
        $DB->insert_record(activity_query::TABLE, (object)[
            'userid' => $userid, 'courseid' => $courseid,
            'day' => activity_query::day_start($day), 'seconds' => $seconds, 'events' => $events,
        ]);
    }

    /**
     * La regla por defecto son 7 horas en 7 dias; el estado sale de ahi.
     */
    public function test_status_thresholds(): void {
        $this->resetAfterTest();

        $this->assertSame(7 * HOURSECS, activity_query::threshold_seconds());
        $this->assertSame(7, activity_query::window_days());

        $this->assertSame(activity_query::STATUS_ACTIVE, activity_query::status(7 * HOURSECS));
        $this->assertSame(activity_query::STATUS_LOW, activity_query::status(7 * HOURSECS - 1));
        $this->assertSame(activity_query::STATUS_LOW, activity_query::status(0, 3));
        $this->assertSame(activity_query::STATUS_NONE, activity_query::status(0, 0));

        set_config('activehours', 2.5, 'local_learninganalytics');
        set_config('activewindow', 14, 'local_learninganalytics');
        $this->assertSame(9000, activity_query::threshold_seconds());
        $this->assertSame(14, activity_query::window_days());
    }

    /**
     * Totales en la ventana, limitados al curso cuando se pide.
     */
    public function test_totals_and_annotate(): void {
        $this->resetAfterTest();

        $now = time();
        $c1 = $this->getDataGenerator()->create_course();
        $c2 = $this->getDataGenerator()->create_course();
        $u = $this->getDataGenerator()->create_user();

        $this->row($u->id, $c1->id, $now, 4 * HOURSECS);
        $this->row($u->id, $c2->id, $now - DAYSECS, 4 * HOURSECS);
        $this->row($u->id, $c1->id, $now - 20 * DAYSECS, 10 * HOURSECS);   // Fuera de la ventana.

        $people = activity_query::annotate([$u->id => ['fullname' => 'X']], null);
        $this->assertSame(8.0, $people[$u->id]['hours']);
        $this->assertSame(2, $people[$u->id]['days']);
        $this->assertSame(activity_query::STATUS_ACTIVE, $people[$u->id]['status']);

        // Solo el curso 1: 4 horas, por debajo de la regla.
        $people = activity_query::annotate([$u->id => ['fullname' => 'X']], [$c1->id]);
        $this->assertSame(4.0, $people[$u->id]['hours']);
        $this->assertSame(activity_query::STATUS_LOW, $people[$u->id]['status']);

        // Ventanas: la mas reciente (0) y la de hace tres semanas (2).
        $windows = activity_query::windows([$u->id], null, 4, $now);
        $this->assertSame(8 * HOURSECS, $windows[$u->id][0]);
        $this->assertSame(10 * HOURSECS, $windows[$u->id][2]);
        $this->assertArrayNotHasKey(1, $windows[$u->id]);
    }

    /**
     * El filtro de estado en SQL debe coincidir con el estado calculado.
     */
    public function test_status_sql(): void {
        global $DB;
        $this->resetAfterTest();

        $now = time();
        $course = $this->getDataGenerator()->create_course();
        $active = $this->getDataGenerator()->create_user();
        $low = $this->getDataGenerator()->create_user();
        $none = $this->getDataGenerator()->create_user();

        $this->row($active->id, $course->id, $now, 8 * HOURSECS);
        $this->row($low->id, $course->id, $now, HOURSECS);

        foreach (['active' => $active, 'low' => $low, 'none' => $none] as $status => $expected) {
            [$where, $params] = activity_query::status_sql($status, null);
            $ids = $DB->get_fieldset_sql(
                "SELECT u.id FROM {user} u WHERE u.deleted = 0 AND u.id > 2{$where}", $params);
            $this->assertSame([(int)$expected->id], array_map('intval', $ids), "estado {$status}");
        }

        [$where, $params] = activity_query::status_sql('bogus', null);
        $this->assertSame('', $where);
        $this->assertSame([], $params);
    }

    /**
     * Bloque completo: reparto, regularidad y lista de personas por debajo.
     */
    public function test_build_block(): void {
        $this->resetAfterTest();

        $now = time();
        $course = $this->getDataGenerator()->create_course();
        $a = $this->getDataGenerator()->create_user(['firstname' => 'Ana']);
        $b = $this->getDataGenerator()->create_user(['firstname' => 'Bea']);

        for ($w = 0; $w < 4; $w++) {
            $this->row($a->id, $course->id, $now - $w * 7 * DAYSECS - DAYSECS, 8 * HOURSECS);
        }
        $this->row($b->id, $course->id, $now, HOURSECS);

        $people = activity_query::annotate([
            $a->id => ['fullname' => 'Ana', 'email' => 'a@x', 'lastaccesstext' => ''],
            $b->id => ['fullname' => 'Bea', 'email' => 'b@x', 'lastaccesstext' => ''],
        ], [$course->id]);
        $block = activity_query::build_block($people, [$course->id]);

        $this->assertTrue($block['available']);
        $this->assertSame(2, $block['total']);
        $this->assertSame(1, $block['active']);
        $this->assertSame(1, $block['low']);
        $this->assertSame(0, $block['none']);
        $this->assertSame(50.0, $block['activerate']);
        $this->assertSame(1, $block['regular']);
        $this->assertCount(1, $block['users']);
        $this->assertSame('Bea', $block['users'][0]['fullname']);
        $this->assertSame(activity_query::STATUS_LOW, $block['users'][0]['status']);
        $this->assertCount(activity_query::SERIES_WINDOWS, $block['series']['values']);
        $this->assertSame([1, 1, 0], $block['dist']['values']);
    }

    /**
     * Sin datos, el bloque avisa y no revienta.
     */
    public function test_build_block_without_data(): void {
        $this->resetAfterTest();

        $block = activity_query::build_block([1 => ['fullname' => 'X']], null);
        $this->assertFalse($block['available']);
        $this->assertSame([], $block['users']);
    }

    /**
     * La agregacion suma huecos cortos al curso del primer evento, cierra la
     * sesion en huecos largos y enlaza con el ultimo evento de la ejecucion
     * anterior.
     */
    public function test_accumulate(): void {
        $this->resetAfterTest();

        $task = new aggregate_time();
        $base = activity_query::day_start(time() - 2 * DAYSECS) + 10 * HOURSECS;
        $day = activity_query::day_start($base);

        $events = [
            (object)['userid' => 5, 'courseid' => 2, 'timecreated' => $base],
            (object)['userid' => 5, 'courseid' => 3, 'timecreated' => $base + 600],      // 10 min en el curso 2.
            (object)['userid' => 5, 'courseid' => 3, 'timecreated' => $base + 5000],     // Hueco de 73 min: sesion cerrada.
            (object)['userid' => 5, 'courseid' => 3, 'timecreated' => $base + 5300],     // 5 min en el curso 3.
            (object)['userid' => 9, 'courseid' => 2, 'timecreated' => $base + 100],
        ];

        // El usuario 9 viene con un evento previo de hace 60 s, de la ejecucion anterior.
        $last = [9 => ['courseid' => 2, 'timecreated' => $base + 40], 5 => null];
        $buckets = [];
        $task->accumulate($events, $last, $buckets);

        $this->assertSame(600, $buckets["5-2-{$day}"]['seconds']);
        $this->assertSame(1, $buckets["5-2-{$day}"]['events']);
        $this->assertSame(300, $buckets["5-3-{$day}"]['seconds']);
        $this->assertSame(3, $buckets["5-3-{$day}"]['events']);
        $this->assertSame(60, $buckets["9-2-{$day}"]['seconds']);

        $this->assertSame($base + 5300, $last[5]['timecreated']);
        $this->assertSame(3, $last[5]['courseid']);
        $this->assertTrue($last[9]['dirty']);
    }
}
