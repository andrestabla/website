<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics;

use local_learninganalytics\local\evaluation_query;

/**
 * Tests del bloque de evaluacion y entregas.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \local_learninganalytics\local\evaluation_query
 */
final class evaluation_query_test extends \advanced_testcase {

    /**
     * Sin tareas ni cuestionarios el bloque se declara no disponible.
     */
    public function test_empty_course(): void {
        $this->resetAfterTest();
        $course = $this->getDataGenerator()->create_course();
        $user = $this->getDataGenerator()->create_and_enrol($course, 'student');

        $block = (new evaluation_query($course->id, [$user->id]))->run();

        $this->assertFalse($block['available']);
        $this->assertSame([], $block['items']);
    }

    /**
     * Entregas a tiempo, tarde y pendientes de calificar en una tarea vencida.
     */
    public function test_assignment_submissions(): void {
        global $DB;
        $this->resetAfterTest();

        $now = time();
        $course = $this->getDataGenerator()->create_course();
        $ontime = $this->getDataGenerator()->create_and_enrol($course, 'student');
        $late = $this->getDataGenerator()->create_and_enrol($course, 'student');
        $missing = $this->getDataGenerator()->create_and_enrol($course, 'student');

        $assign = $this->getDataGenerator()->create_module('assign', [
            'course' => $course->id, 'duedate' => $now - 2 * DAYSECS, 'attemptreopenmethod' => 'manual',
        ]);

        // Entrega a tiempo, calificada con comentario al dia siguiente.
        $sid = $DB->insert_record('assign_submission', (object)[
            'assignment' => $assign->id, 'userid' => $ontime->id, 'status' => 'submitted',
            'latest' => 1, 'attemptnumber' => 1,
            'timecreated' => $now - 4 * DAYSECS, 'timemodified' => $now - 3 * DAYSECS,
        ]);
        $gid = $DB->insert_record('assign_grades', (object)[
            'assignment' => $assign->id, 'userid' => $ontime->id, 'grade' => 80, 'grader' => 2,
            'attemptnumber' => 1, 'timecreated' => $now - 2 * DAYSECS, 'timemodified' => $now - 2 * DAYSECS,
        ]);
        $DB->insert_record('assignfeedback_comments', (object)[
            'assignment' => $assign->id, 'grade' => $gid, 'commenttext' => 'Bien', 'commentformat' => 1,
        ]);

        // Entrega tarde, sin calificar.
        $DB->insert_record('assign_submission', (object)[
            'assignment' => $assign->id, 'userid' => $late->id, 'status' => 'submitted',
            'latest' => 1, 'attemptnumber' => 0,
            'timecreated' => $now - DAYSECS, 'timemodified' => $now - DAYSECS,
        ]);

        $block = (new evaluation_query($course->id, [$ontime->id, $late->id, $missing->id]))->run();

        $this->assertTrue($block['available']);
        $this->assertCount(1, $block['items']);
        $it = $block['items'][0];

        $this->assertSame('assign', $it['type']);
        $this->assertSame(3, $it['expected']);
        $this->assertSame(2, $it['delivered']);
        $this->assertSame(1, $it['ontime']);
        $this->assertSame(1, $it['graded']);
        $this->assertSame(1, $it['feedback']);
        $this->assertSame(1, $it['feedbackintime']);
        $this->assertSame(1, $it['resubmitted']);      // attemptnumber 1 = reenvio.
        $this->assertSame(2, $it['resubmittable']);
        $this->assertSame(1, $it['pendinggrading']);
        $this->assertFalse($it['uptodate']);

        $this->assertSame(1, $block['ontime']);
        $this->assertSame(3, $block['ontimeexpected']);
        $this->assertSame(33.3, $block['ontimerate']);
        $this->assertSame(1, $block['itemsdue']);
        $this->assertSame(0, $block['itemsuptodate']);
        $this->assertSame(100.0, $block['feedbackrate']);
        $this->assertFalse($block['hasmastery']);
        $this->assertNotNull($sid);
    }

    /**
     * Cuestionarios: completados, ganancia entre intentos y aprobado.
     */
    public function test_quiz_attempts_and_mastery(): void {
        global $DB;
        $this->resetAfterTest();

        $course = $this->getDataGenerator()->create_course();
        $a = $this->getDataGenerator()->create_and_enrol($course, 'student');
        $b = $this->getDataGenerator()->create_and_enrol($course, 'student');

        $quiz = $this->getDataGenerator()->create_module('quiz', [
            'course' => $course->id, 'grade' => 100, 'sumgrades' => 10, 'gradepass' => 60,
        ]);
        $DB->set_field('quiz', 'sumgrades', 10, ['id' => $quiz->id]);

        foreach ([[$a->id, 1, 4], [$a->id, 2, 9], [$b->id, 1, 5]] as [$uid, $n, $sum]) {
            $DB->insert_record('quiz_attempts', (object)[
                'quiz' => $quiz->id, 'userid' => $uid, 'attempt' => $n, 'uniqueid' => $uid * 10 + $n,
                'layout' => '', 'state' => 'finished', 'sumgrades' => $sum, 'preview' => 0,
                'currentpage' => 0, 'timestart' => 1, 'timefinish' => 2, 'timemodified' => 2,
            ]);
        }

        // Nota final en el libro: 90 y 50 sobre 100, aprobado en 60.
        $item = $DB->get_record('grade_items', ['itemmodule' => 'quiz', 'iteminstance' => $quiz->id]);
        $DB->set_field('grade_items', 'gradepass', 60, ['id' => $item->id]);
        foreach ([[$a->id, 90], [$b->id, 50]] as [$uid, $grade]) {
            $DB->insert_record('grade_grades', (object)[
                'itemid' => $item->id, 'userid' => $uid, 'finalgrade' => $grade, 'rawgrademax' => 100,
            ]);
        }

        $block = (new evaluation_query($course->id, [$a->id, $b->id]))->run();
        $it = $block['items'][0];

        $this->assertSame('quiz', $it['type']);
        $this->assertSame(2, $it['expected']);          // Sin cierre: todos.
        $this->assertSame(2, $it['delivered']);
        $this->assertSame(1, $it['gainstudents']);
        $this->assertSame(50.0, $it['gain']);            // De 4 a 9 sobre 10.
        $this->assertSame(60.0, $it['gradepass']);
        $this->assertSame(1, $it['mastery']);
        $this->assertSame(2, $it['masteryof']);

        $this->assertSame(100.0, $block['quizrate']);
        $this->assertTrue($block['hasgain']);
        $this->assertSame(50.0, $block['gain']);
        $this->assertTrue($block['hasmastery']);
        $this->assertSame(50.0, $block['masteryrate']);
        $this->assertSame(0, $block['itemsdue']);       // Sin fecha de cierre no vence.
    }
}
