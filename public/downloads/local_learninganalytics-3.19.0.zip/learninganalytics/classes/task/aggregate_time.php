<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\task;

use local_learninganalytics\local\activity_query;

/**
 * Agrega el registro estandar en permanencia diaria por usuario y curso.
 *
 * Moodle no guarda tiempo de permanencia. Se deduce igual que en el informe
 * de curso: se recorren los eventos de cada persona en orden y se suma el
 * hueco entre dos consecutivos mientras no supere el corte de inactividad.
 * El hueco se atribuye al curso del PRIMER evento, que es la pagina en la
 * que la persona estaba durante ese tiempo.
 *
 * Es incremental: guarda el id del ultimo evento procesado y el ultimo
 * evento de cada persona, de modo que una sesion partida entre dos
 * ejecuciones se enlaza sin contarla dos veces. Trabaja por tramos con un
 * presupuesto de tiempo, asi que la primera carga de un historico grande se
 * reparte entre varias ejecuciones sin bloquear el cron.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class aggregate_time extends \core\task\scheduled_task {

    /** Corte de inactividad: mas de esto entre dos eventos cierra la sesion. */
    const IDLE_CUTOFF = 1800;

    /** Segundos de trabajo por ejecucion antes de dejar el cursor y salir. */
    const TIME_BUDGET = 240;

    /** Filas por tramo si el ajuste no dice otra cosa. */
    const DEFAULT_ROWS = 200000;

    /** Dias de historico que se cargan la primera vez si no hay ajuste. */
    const DEFAULT_BACKFILL = 90;

    /**
     * @return string
     */
    public function get_name(): string {
        return get_string('task_aggregate', 'local_learninganalytics');
    }

    /**
     * Ejecuta la agregacion.
     */
    public function execute(): void {
        global $DB;

        $dbman = $DB->get_manager();
        if (!$dbman->table_exists('logstore_standard_log')
                || !$dbman->table_exists(activity_query::TABLE)) {
            mtrace('Learning Analytics: sin registro estandar o sin tabla de permanencia; nada que agregar.');
            return;
        }

        $rows = (int)get_config('local_learninganalytics', 'taskrows');
        if ($rows <= 0) {
            $rows = self::DEFAULT_ROWS;
        }

        $cursor = get_config('local_learninganalytics', 'timecursor');
        if ($cursor === false || $cursor === '') {
            $cursor = $this->initial_cursor();
            set_config('timecursor', $cursor, 'local_learninganalytics');
            mtrace("Learning Analytics: primera ejecucion, cursor inicial en el evento {$cursor}.");
        }
        $cursor = (int)$cursor;

        $started = time();
        $totalrows = 0;

        do {
            [$processed, $cursor] = $this->process_chunk($cursor, $rows);
            $totalrows += $processed;
            set_config('timecursor', $cursor, 'local_learninganalytics');
            mtrace("Learning Analytics: {$processed} eventos agregados; cursor en {$cursor}.");
        } while ($processed >= $rows && (time() - $started) < self::TIME_BUDGET);

        if ($processed >= $rows) {
            mtrace('Learning Analytics: queda historico pendiente; continuara en la proxima ejecucion.');
        }

        mtrace("Learning Analytics: {$totalrows} eventos en total.");
    }

    /**
     * Id del evento anterior al primero que entra en el historico inicial.
     *
     * @return int
     */
    protected function initial_cursor(): int {
        global $DB;

        $days = (int)get_config('local_learninganalytics', 'backfilldays');
        if ($days <= 0) {
            $days = self::DEFAULT_BACKFILL;
        }

        $first = $DB->get_field_sql(
            'SELECT MIN(id) FROM {logstore_standard_log} WHERE timecreated >= :since',
            ['since' => time() - $days * DAYSECS]
        );

        if ($first) {
            return (int)$first - 1;
        }

        // Sin eventos en el periodo: se parte del final y solo se agrega lo nuevo.
        return (int)$DB->get_field_sql('SELECT COALESCE(MAX(id), 0) FROM {logstore_standard_log}');
    }

    /**
     * Procesa hasta $limit eventos posteriores al cursor.
     *
     * @param int $cursor
     * @param int $limit
     * @return array [eventos procesados, nuevo cursor]
     */
    protected function process_chunk(int $cursor, int $limit): array {
        global $DB;

        // Se descartan la CLI y las restauraciones (no son personas usando la
        // plataforma), el usuario 0 (invitados y procesos) y las sesiones de
        // "entrar como", que son un administrador y no el estudiante.
        $sql = "SELECT id, userid, courseid, timecreated
                  FROM {logstore_standard_log}
                 WHERE id > :cursor
                       AND userid > 0
                       AND realuserid IS NULL
                       AND origin <> 'cli' AND origin <> 'restore'
              ORDER BY id";

        $rs = $DB->get_recordset_sql($sql, ['cursor' => $cursor], 0, $limit);

        $last = [];
        $buckets = [];
        $processed = 0;
        $newcursor = $cursor;

        $events = (function() use ($rs, &$processed, &$newcursor) {
            foreach ($rs as $r) {
                $processed++;
                $newcursor = (int)$r->id;
                yield $r;
            }
        })();

        $this->accumulate($events, $last, $buckets);
        $rs->close();

        if ($processed === 0) {
            // Ninguna fila posterior al cursor pasa el filtro (todo era CLI,
            // restauraciones o invitados): se salta al final para no releer
            // las mismas filas cada media hora.
            $skip = (int)$DB->get_field_sql('SELECT COALESCE(MAX(id), 0) FROM {logstore_standard_log}');
            return [0, max($cursor, $skip)];
        }

        $this->flush($buckets, $last);

        return [$processed, $newcursor];
    }

    /**
     * Recorre eventos y acumula segundos y eventos por usuario, curso y dia.
     *
     * Es puro respecto a la base de datos salvo por la carga perezosa del
     * ultimo evento de cada persona, que se puede inyectar en $last para las
     * pruebas.
     *
     * @param iterable $events Objetos con userid, courseid, timecreated, en orden.
     * @param array $last userid => ['courseid' => int, 'timecreated' => int]
     * @param array $buckets "userid-courseid-day" => ['userid', 'courseid', 'day', 'seconds', 'events']
     */
    public function accumulate(iterable $events, array &$last, array &$buckets): void {
        foreach ($events as $e) {
            $uid = (int)$e->userid;
            $course = (int)$e->courseid;
            $t = (int)$e->timecreated;

            if (!array_key_exists($uid, $last)) {
                $last[$uid] = $this->load_last($uid);
            }

            $prev = $last[$uid];
            if ($prev !== null) {
                $delta = $t - (int)$prev['timecreated'];
                if ($delta > 0 && $delta <= self::IDLE_CUTOFF) {
                    $this->add($buckets, $uid, (int)$prev['courseid'],
                        activity_query::day_start((int)$prev['timecreated']), $delta, 0);
                }
            }

            $this->add($buckets, $uid, $course, activity_query::day_start($t), 0, 1);

            // Los eventos van en orden de id, que casi siempre es el de
            // tiempo. Si llega uno anterior al ultimo visto, no se retrocede.
            if ($prev === null || $t >= (int)$prev['timecreated']) {
                $last[$uid] = ['courseid' => $course, 'timecreated' => $t, 'dirty' => true];
            }
        }
    }

    /**
     * Suma a un cubo.
     *
     * @param array $buckets
     * @param int $uid
     * @param int $course
     * @param int $day
     * @param int $seconds
     * @param int $events
     */
    protected function add(array &$buckets, int $uid, int $course, int $day, int $seconds, int $events): void {
        $key = "{$uid}-{$course}-{$day}";
        if (!isset($buckets[$key])) {
            $buckets[$key] = [
                'userid' => $uid, 'courseid' => $course, 'day' => $day,
                'seconds' => 0, 'events' => 0,
            ];
        }
        $buckets[$key]['seconds'] += $seconds;
        $buckets[$key]['events'] += $events;
    }

    /**
     * Ultimo evento conocido de una persona, de la ejecucion anterior.
     *
     * @param int $uid
     * @return array|null
     */
    protected function load_last(int $uid): ?array {
        global $DB;

        $r = $DB->get_record(activity_query::LAST_TABLE, ['userid' => $uid], 'courseid, timecreated');
        if (!$r) {
            return null;
        }
        return ['courseid' => (int)$r->courseid, 'timecreated' => (int)$r->timecreated];
    }

    /**
     * Vuelca los cubos y los ultimos eventos a la base de datos.
     *
     * @param array $buckets
     * @param array $last
     */
    protected function flush(array $buckets, array $last): void {
        global $DB;

        $transaction = $DB->start_delegated_transaction();

        foreach ($buckets as $b) {
            $existing = $DB->get_record(activity_query::TABLE,
                ['userid' => $b['userid'], 'courseid' => $b['courseid'], 'day' => $b['day']],
                'id, seconds, events');

            if ($existing) {
                $DB->update_record(activity_query::TABLE, (object)[
                    'id'      => $existing->id,
                    'seconds' => (int)$existing->seconds + $b['seconds'],
                    'events'  => (int)$existing->events + $b['events'],
                ]);
            } else {
                $DB->insert_record(activity_query::TABLE, (object)$b, false);
            }
        }

        foreach ($last as $uid => $l) {
            if ($l === null || empty($l['dirty'])) {
                continue;
            }
            $existing = $DB->get_record(activity_query::LAST_TABLE, ['userid' => $uid], 'id');
            $record = (object)[
                'userid' => $uid, 'courseid' => $l['courseid'], 'timecreated' => $l['timecreated'],
            ];
            if ($existing) {
                $record->id = $existing->id;
                $DB->update_record(activity_query::LAST_TABLE, $record);
            } else {
                $DB->insert_record(activity_query::LAST_TABLE, $record, false);
            }
        }

        $transaction->allow_commit();
    }
}
