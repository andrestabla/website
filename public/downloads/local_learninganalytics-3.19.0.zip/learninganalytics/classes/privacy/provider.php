<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;
use local_learninganalytics\local\activity_query;

/**
 * Privacy provider.
 *
 * El plugin guarda tres cosas suyas:
 *  - El historico de consultas de IA de cada usuario (pregunta y respuesta).
 *  - La permanencia diaria estimada por usuario y curso, agregada desde el
 *    registro estandar por la tarea programada. Son cifras derivadas, pero
 *    siguen siendo datos de actividad de una persona identificada.
 *  - El ultimo evento visto de cada usuario, que solo sirve para enlazar
 *    sesiones entre ejecuciones de la tarea.
 * Ademas, cuando la analitica conversacional esta activa, la pregunta viaja
 * con cifras agregadas del tablero a Algoritmo T. Todo se declara aqui y
 * todo se puede exportar y borrar por usuario.
 *
 * Los tableros en si no almacenan nada mas: presentan datos que ya existen
 * en Moodle. La auditoria del reenvio de credenciales y de los envios usa la
 * API de eventos, cuya privacidad gestionan los almacenes de registro.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider,
    \core_privacy\local\request\core_userlist_provider {

    /**
     * Declara los datos que el plugin guarda y los que envia fuera.
     *
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('local_learninganalytics_ai', [
            'userid'      => 'privacy:metadata:ai:userid',
            'contextid'   => 'privacy:metadata:ai:contextid',
            'mode'        => 'privacy:metadata:ai:mode',
            'question'    => 'privacy:metadata:ai:question',
            'answer'      => 'privacy:metadata:ai:answer',
            'timecreated' => 'privacy:metadata:ai:timecreated',
        ], 'privacy:metadata:ai');

        $collection->add_database_table('local_learninganalytics_time', [
            'userid'   => 'privacy:metadata:time:userid',
            'courseid' => 'privacy:metadata:time:courseid',
            'day'      => 'privacy:metadata:time:day',
            'seconds'  => 'privacy:metadata:time:seconds',
            'events'   => 'privacy:metadata:time:events',
        ], 'privacy:metadata:time');

        $collection->add_database_table('local_learninganalytics_last', [
            'userid'      => 'privacy:metadata:last:userid',
            'courseid'    => 'privacy:metadata:last:courseid',
            'timecreated' => 'privacy:metadata:last:timecreated',
        ], 'privacy:metadata:last');

        $collection->add_external_location_link('algoritmot', [
            'question' => 'privacy:metadata:algoritmot:question',
            'series'   => 'privacy:metadata:algoritmot:series',
        ], 'privacy:metadata:algoritmot');

        return $collection;
    }

    /**
     * Contextos donde el usuario tiene datos guardados.
     *
     * La permanencia cuelga del contexto del curso; la que no pertenece a
     * ningun curso (courseid 0) y el cursor por usuario cuelgan del sistema.
     *
     * @param int $userid
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();

        $contextlist->add_from_sql(
            "SELECT DISTINCT ctx.id
               FROM {context} ctx
               JOIN {local_learninganalytics_ai} ai ON ai.contextid = ctx.id
              WHERE ai.userid = :userid",
            ['userid' => $userid]
        );

        $contextlist->add_from_sql(
            "SELECT DISTINCT ctx.id
               FROM {context} ctx
               JOIN {local_learninganalytics_time} t ON t.courseid = ctx.instanceid
              WHERE ctx.contextlevel = :courselevel AND t.userid = :userid",
            ['courselevel' => CONTEXT_COURSE, 'userid' => $userid]
        );

        $contextlist->add_from_sql(
            "SELECT ctx.id
               FROM {context} ctx
              WHERE ctx.contextlevel = :systemlevel
                    AND (EXISTS (SELECT 1 FROM {local_learninganalytics_time} t
                                  WHERE t.userid = :userid1 AND t.courseid = 0)
                         OR EXISTS (SELECT 1 FROM {local_learninganalytics_last} l
                                     WHERE l.userid = :userid2))",
            ['systemlevel' => CONTEXT_SYSTEM, 'userid1' => $userid, 'userid2' => $userid]
        );

        return $contextlist;
    }

    /**
     * Usuarios con datos guardados en un contexto.
     *
     * @param userlist $userlist
     */
    public static function get_users_in_context(userlist $userlist): void {
        $context = $userlist->get_context();

        $userlist->add_from_sql('userid',
            "SELECT userid FROM {local_learninganalytics_ai} WHERE contextid = :contextid",
            ['contextid' => $context->id]
        );

        if ($context instanceof \context_course) {
            $userlist->add_from_sql('userid',
                "SELECT DISTINCT userid FROM {local_learninganalytics_time} WHERE courseid = :courseid",
                ['courseid' => $context->instanceid]
            );
        } else if ($context instanceof \context_system) {
            $userlist->add_from_sql('userid',
                "SELECT DISTINCT userid FROM {local_learninganalytics_time} WHERE courseid = 0", []);
            $userlist->add_from_sql('userid',
                "SELECT userid FROM {local_learninganalytics_last}", []);
        }
    }

    /**
     * Exporta los datos del usuario, contexto a contexto.
     *
     * @param approved_contextlist $contextlist
     */
    public static function export_user_data(approved_contextlist $contextlist): void {
        global $DB;

        $userid = $contextlist->get_user()->id;

        foreach ($contextlist->get_contexts() as $context) {
            $records = $DB->get_records('local_learninganalytics_ai',
                ['userid' => $userid, 'contextid' => $context->id], 'timecreated ASC');

            if (!empty($records)) {
                $queries = [];
                foreach ($records as $r) {
                    $queries[] = (object)[
                        'question'    => $r->question,
                        'answer'      => $r->answer,
                        'mode'        => $r->mode,
                        'timecreated' => \core_privacy\local\request\transform::datetime($r->timecreated),
                    ];
                }

                writer::with_context($context)->export_data(
                    [get_string('ai_history', 'local_learninganalytics')],
                    (object)['queries' => $queries]
                );
            }

            $courseid = null;
            if ($context instanceof \context_course) {
                $courseid = (int)$context->instanceid;
            } else if ($context instanceof \context_system) {
                $courseid = 0;
            }
            if ($courseid === null) {
                continue;
            }

            $rows = $DB->get_records(activity_query::TABLE,
                ['userid' => $userid, 'courseid' => $courseid], 'day ASC');
            if (!empty($rows)) {
                $days = [];
                foreach ($rows as $r) {
                    $days[] = (object)[
                        'day'     => \core_privacy\local\request\transform::date($r->day),
                        'seconds' => (int)$r->seconds,
                        'events'  => (int)$r->events,
                    ];
                }
                writer::with_context($context)->export_data(
                    [get_string('privacy:export:time', 'local_learninganalytics')],
                    (object)['days' => $days]
                );
            }

            if ($courseid === 0) {
                $last = $DB->get_record(activity_query::LAST_TABLE, ['userid' => $userid]);
                if ($last) {
                    writer::with_context($context)->export_data(
                        [get_string('privacy:export:last', 'local_learninganalytics')],
                        (object)[
                            'courseid'    => (int)$last->courseid,
                            'timecreated' => \core_privacy\local\request\transform::datetime($last->timecreated),
                        ]
                    );
                }
            }
        }
    }

    /**
     * Borra todos los datos guardados en un contexto.
     *
     * @param \context $context
     */
    public static function delete_data_for_all_users_in_context(\context $context): void {
        global $DB;

        $DB->delete_records('local_learninganalytics_ai', ['contextid' => $context->id]);

        if ($context instanceof \context_course) {
            $DB->delete_records(activity_query::TABLE, ['courseid' => $context->instanceid]);
        } else if ($context instanceof \context_system) {
            $DB->delete_records(activity_query::TABLE, ['courseid' => 0]);
            $DB->delete_records(activity_query::LAST_TABLE);
        }
    }

    /**
     * Borra los datos del usuario en los contextos aprobados.
     *
     * @param approved_contextlist $contextlist
     */
    public static function delete_data_for_user(approved_contextlist $contextlist): void {
        global $DB;

        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            $DB->delete_records('local_learninganalytics_ai',
                ['userid' => $userid, 'contextid' => $context->id]);

            if ($context instanceof \context_course) {
                $DB->delete_records(activity_query::TABLE,
                    ['userid' => $userid, 'courseid' => $context->instanceid]);
            } else if ($context instanceof \context_system) {
                $DB->delete_records(activity_query::TABLE, ['userid' => $userid, 'courseid' => 0]);
                $DB->delete_records(activity_query::LAST_TABLE, ['userid' => $userid]);
            }
        }
    }

    /**
     * Borra los datos de una lista de usuarios en un contexto.
     *
     * @param approved_userlist $userlist
     */
    public static function delete_data_for_users(approved_userlist $userlist): void {
        global $DB;

        $userids = $userlist->get_userids();
        if (empty($userids)) {
            return;
        }

        $context = $userlist->get_context();
        [$insql, $params] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'pu');

        $DB->delete_records_select('local_learninganalytics_ai',
            "contextid = :contextid AND userid {$insql}", $params + ['contextid' => $context->id]);

        if ($context instanceof \context_course) {
            $DB->delete_records_select(activity_query::TABLE,
                "courseid = :courseid AND userid {$insql}", $params + ['courseid' => $context->instanceid]);
        } else if ($context instanceof \context_system) {
            $DB->delete_records_select(activity_query::TABLE,
                "courseid = 0 AND userid {$insql}", $params);
            $DB->delete_records_select(activity_query::LAST_TABLE, "userid {$insql}", $params);
        }
    }
}
