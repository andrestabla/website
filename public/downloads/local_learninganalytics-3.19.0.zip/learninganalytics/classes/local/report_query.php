<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Toda la logica de consulta del dashboard, aislada y testeable.
 *
 * Reglas que se respetan aqui:
 *  - Nada de identificadores cableados: todo sale de local\config.
 *  - SQL portable: sin SUBSTRING_INDEX ni funciones propias de MySQL.
 *  - Sin duplicados por multiples matriculaciones (GROUP BY explicito).
 *  - Fechas en el huso del usuario, no del servidor.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class report_query {

    /** @var array Filtros ya validados por external_api. */
    protected $filters;

    /** @var string Fragmento WHERE comun. */
    protected $where = '';

    /** @var string Fragmento JOIN comun. */
    protected $joins = '';

    /** @var array Parametros del SQL. */
    protected $params = [];

    /** @var scope Ambito (plataforma, categoria o curso). */
    protected $scope;

    /** @var array|null Cursos del ambito; null = sin restriccion. */
    protected $scopecourseids = null;

    /** @var bool|null Cache de has_certificates(). */
    protected $hascerts = null;

    /**
     * @param array $filters courseid, country, domain, estado, supervisor,
     *                       startdate, enddate, userid, search, contextid
     * @param scope|null $scope Ambito ya resuelto; si no se pasa, se deduce
     *                          de filters['contextid'].
     */
    public function __construct(array $filters, ?scope $scope = null) {
        $this->scope = $scope ?? scope::from_contextid((int)($filters['contextid'] ?? 0));
        $this->scopecourseids = $this->scope->get_course_ids();

        // El filtro de categoria estrecha el ambito, nunca lo amplia: se
        // interseca con los cursos que el contexto ya permitia ver.
        if (!empty($filters['categoryid'])) {
            $incategory = scope::courses_in_category((int)$filters['categoryid']);
            $this->scopecourseids = $this->scopecourseids === null
                ? $incategory
                : array_values(array_intersect($this->scopecourseids, $incategory));
        }

        $this->filters = $filters + [
            'courseid'   => 0,
            'country'    => '',
            'domain'     => '',
            'estado'     => '',
            'supervisor' => '',
            'startdate'  => 0,
            'enddate'    => 0,
            'userid'     => 0,
            'search'     => '',
            'categoryid' => 0,
            'roleid'     => 0,
            'status'     => '',
        ];
        $this->build_base();
    }

    /**
     * Indica si hay datos de certificados disponibles.
     *
     * Se comprueba en runtime en lugar de declarar mod_customcert como
     * dependencia dura, para que el plugin instale igual sin el.
     *
     * @return bool
     */
    public static function certificates_available(): bool {
        global $DB;
        $dbman = $DB->get_manager();
        return $dbman->table_exists('customcert') && $dbman->table_exists('customcert_issues');
    }

    /**
     * Indica si en ESTE ambito hay realmente actividades de certificado.
     *
     * Que el plugin este instalado no significa que el curso que se esta
     * mirando emita certificados. El tablero solo debe mostrar lo que existe
     * en el ambito, asi que un curso sin certificados no ensena esa seccion.
     *
     * @return bool
     */
    public function has_certificates(): bool {
        global $DB;

        if ($this->hascerts !== null) {
            return $this->hascerts;
        }

        if (!self::certificates_available()) {
            return $this->hascerts = false;
        }

        if ($this->scopecourseids === null) {
            return $this->hascerts = $DB->record_exists_select('customcert', '1 = 1');
        }

        if (empty($this->scopecourseids)) {
            return $this->hascerts = false;
        }

        [$insql, $params] = $DB->get_in_or_equal($this->scopecourseids, SQL_PARAMS_NAMED, 'cs');

        return $this->hascerts = $DB->record_exists_select('customcert', "course {$insql}", $params);
    }

    /**
     * Fragmento que limita los certificados a los cursos del ambito.
     *
     * Sin esto, el tablero de un curso contaria los certificados que sus
     * estudiantes obtuvieron en OTROS cursos.
     *
     * @return array [join, where, params]
     */
    protected function certificate_scope_sql(): array {
        global $DB;

        if ($this->scopecourseids === null) {
            return ['', '', []];
        }

        if (empty($this->scopecourseids)) {
            return ['', ' AND 1 = 0', []];
        }

        [$insql, $params] = $DB->get_in_or_equal($this->scopecourseids, SQL_PARAMS_NAMED, 'ccs');

        return [
            ' JOIN {customcert} cc ON cc.id = ci.customcertid',
            " AND cc.course {$insql}",
            $params,
        ];
    }

    /**
     * Construye el WHERE/JOIN comun a todas las consultas.
     */
    protected function build_base(): void {
        global $DB;

        $f = $this->filters;

        // Sin licencia no hay filtros: las metricas de cortesia describen
        // siempre la plataforma completa.
        if (!licence::has_feature(licence::FEATURE_FILTERS)) {
            $f = array_merge($f, [
                'courseid' => 0, 'categoryid' => 0, 'roleid' => 0,
                'country' => '', 'domain' => '', 'estado' => '', 'supervisor' => '',
                'startdate' => 0, 'enddate' => 0, 'userid' => 0, 'search' => '',
                'status' => '',
            ]);
            $this->filters = $f;
        }

        $where = 'u.deleted = 0 AND u.confirmed = 1';
        $joins = '';
        $params = [];

        if ($f['country'] !== '') {
            $where .= ' AND u.country = :country';
            $params['country'] = $f['country'];
        }

        // Portable: sql_like resuelve escapado y sensibilidad segun el motor.
        if ($f['domain'] !== '') {
            $where .= ' AND ' . $DB->sql_like('u.email', ':domain', false);
            $params['domain'] = '%@' . $DB->sql_like_escape($f['domain']);
        }

        if (!empty($f['userid'])) {
            $where .= ' AND u.id = :uid';
            $params['uid'] = (int)$f['userid'];
        } else if ($f['search'] !== '') {
            $fullnamesql = $DB->sql_concat('u.firstname', "' '", 'u.lastname');
            $where .= ' AND (' . $DB->sql_like($fullnamesql, ':name1', false)
                    . ' OR ' . $DB->sql_like('u.email', ':name2', false) . ')';
            $escaped = '%' . $DB->sql_like_escape($f['search']) . '%';
            $params['name1'] = $escaped;
            $params['name2'] = $escaped;
        }

        // Campos de perfil: solo si estan configurados Y el filtro se usa.
        $estadoid = config::estado_fieldid();
        if ($f['estado'] !== '' && $estadoid !== null) {
            $joins .= ' JOIN {user_info_data} ud_e ON ud_e.userid = u.id AND ud_e.fieldid = :fid_e';
            $where .= ' AND ud_e.data = :estado';
            $params['fid_e'] = $estadoid;
            $params['estado'] = $f['estado'];
        }

        $supervisorid = config::supervisor_fieldid();
        if ($f['supervisor'] !== '' && $supervisorid !== null) {
            $joins .= ' JOIN {user_info_data} ud_s ON ud_s.userid = u.id AND ud_s.fieldid = :fid_s';
            $where .= ' AND ud_s.data = :supervisor';
            $params['fid_s'] = $supervisorid;
            $params['supervisor'] = $f['supervisor'];
        }

        // Filtro por curso: EXISTS en lugar de JOIN, para no duplicar filas
        // cuando un usuario tiene varios metodos de matriculacion.
        if (!empty($f['courseid'])) {
            $where .= ' AND EXISTS (
                            SELECT 1
                              FROM {user_enrolments} ue_f
                              JOIN {enrol} e_f ON e_f.id = ue_f.enrolid
                             WHERE ue_f.userid = u.id AND e_f.courseid = :courseid)';
            $params['courseid'] = (int)$f['courseid'];
        }

        // Filtro por rol: el usuario debe tener ese rol en un contexto que
        // afecte al ambito. En plataforma vale cualquier contexto.
        if (!empty($f['roleid'])) {
            $ctxids = $this->scope->get_role_context_ids();
            $ctxwhere = '';

            if ($ctxids !== null) {
                if (empty($ctxids)) {
                    $where .= ' AND 1 = 0';
                } else {
                    [$cinsql, $cinparams] = $DB->get_in_or_equal($ctxids, SQL_PARAMS_NAMED, 'rctx');
                    $ctxwhere = " AND ra_r.contextid {$cinsql}";
                    $params += $cinparams;
                }
            }

            $where .= " AND EXISTS (
                            SELECT 1
                              FROM {role_assignments} ra_r
                             WHERE ra_r.userid = u.id
                                   AND ra_r.roleid = :roleid{$ctxwhere})";
            $params['roleid'] = (int)$f['roleid'];
        }

        // Restriccion de ambito: en categoria o curso, solo usuarios
        // matriculados en los cursos que abarca ese contexto.
        if ($this->scopecourseids !== null) {
            if (empty($this->scopecourseids)) {
                $where .= ' AND 1 = 0';   // Ambito vacio: no hay nada que mostrar.
            } else {
                [$insql, $inparams] = $DB->get_in_or_equal($this->scopecourseids, SQL_PARAMS_NAMED, 'scp');
                $where .= " AND EXISTS (
                                SELECT 1
                                  FROM {user_enrolments} ue_s
                                  JOIN {enrol} e_s ON e_s.id = ue_s.enrolid
                                 WHERE ue_s.userid = u.id AND e_s.courseid {$insql})";
                $params += $inparams;
            }
        }

        // Filtro por actividad significativa: se resuelve en SQL contra la
        // tabla de permanencia, con la misma regla que el bloque de riesgo.
        if (!empty($f['status'])) {
            [$ssql, $sparams] = activity_query::status_sql((string)$f['status'], $this->scopecourseids);
            $where .= $ssql;
            $params += $sparams;
        }

        if (!empty($f['startdate'])) {
            $where .= ' AND u.timecreated >= :startdate';
            $params['startdate'] = (int)$f['startdate'];
        }
        if (!empty($f['enddate'])) {
            $where .= ' AND u.timecreated <= :enddate';
            $params['enddate'] = (int)$f['enddate'];
        }

        $this->where = $where;
        $this->joins = $joins;
        $this->params = $params;
    }

    /**
     * Ejecuta el informe completo.
     *
     * @return array Estructura que consume el modulo AMD.
     */
    public function run(): array {
        // Sin licencia el informe se limita a las metricas de cortesia. El
        // recorte se hace AQUI, en el servidor: ocultar tarjetas en el
        // navegador no impediria pedir los datos al servicio web.
        if (!licence::has_feature(licence::FEATURE_TABLES)) {
            return $this->run_free();
        }

        $users = $this->get_users();

        return [
            'kpis'         => $this->get_kpis($users),
            'growth'       => $this->get_growth(),
            'domains'      => $this->get_domains(),
            'countries'    => $this->get_countries(),
            'certificates' => $this->get_certificates_series(),
            'activity'     => $this->get_activity(),
            'topcourses'   => $this->get_top_courses(),
            'certsplit'    => $this->get_certification_split(),
            'users'        => $users,
            'progress'     => $this->get_progress(),
            'risk'         => $this->get_risk($users),
            'hascerts'     => $this->has_certificates(),
            'hasestado'    => config::estado_fieldid() !== null,
            'hassupervisor' => config::supervisor_fieldid() !== null,
            'scopelevel'    => $this->scope->get_level(),
            'generated'     => time(),
        ];
    }

    /**
     * Version gratuita del informe.
     *
     * Incluye solo lo que el plugin ofrece sin licencia: cifras clave,
     * crecimiento de usuarios y cursos con mas matriculaciones.
     *
     * @return array
     */
    protected function run_free(): array {
        $empty = ['labels' => [], 'values' => []];

        return [
            'kpis'          => $this->get_kpis(),
            'growth'        => $this->get_growth(),
            'topcourses'    => $this->get_top_courses(),
            'domains'       => $empty,
            'countries'     => ['labels' => [], 'values' => [], 'codes' => []],
            'certificates'  => $empty,
            'activity'      => $empty,
            'certsplit'     => $empty,
            'users'         => [],
            'progress'      => [],
            'risk'          => activity_query::empty_block(),
            'hascerts'      => $this->has_certificates(),
            'hasestado'     => false,
            'hassupervisor' => false,
            'generated'     => time(),
            'scopelevel'    => $this->scope->get_level(),
        ];
    }

    /**
     * Bloque de permanencia y riesgo sobre el padron ya filtrado.
     *
     * Se calcula sobre las MISMAS personas que muestra la tabla de usuarios,
     * de modo que las tarjetas describen exactamente lo que se ve. Los cursos
     * se limitan al ambito: en un curso solo cuenta el tiempo en ese curso.
     *
     * @param array $users Salida de get_users().
     * @return array
     */
    public function get_risk(array $users): array {
        $people = [];
        foreach ($users as $u) {
            $people[(int)$u['id']] = [
                'fullname'       => $u['fullname'],
                'email'          => $u['email'],
                'lastaccesstext' => $u['lastaccess'],
            ];
        }

        $people = activity_query::annotate($people, $this->scopecourseids);

        return activity_query::build_block($people, $this->scopecourseids);
    }

    /**
     * Padron de usuarios que cumplen los filtros.
     *
     * @return array
     */
    public function get_users(): array {
        global $DB;

        $estadoid = config::estado_fieldid();
        $supervisorid = config::supervisor_fieldid();
        $params = $this->params;

        // Subconsultas correlacionadas para los campos de perfil: evitan
        // multiplicar filas y permiten que el campo no este configurado.
        $estadosel = "'' AS estado";
        if ($estadoid !== null) {
            $estadosel = '(SELECT uid_e.data FROM {user_info_data} uid_e
                            WHERE uid_e.userid = u.id AND uid_e.fieldid = :sel_fid_e) AS estado';
            $params['sel_fid_e'] = $estadoid;
        }

        $supsel = "'' AS supervisor";
        if ($supervisorid !== null) {
            $supsel = '(SELECT uid_s.data FROM {user_info_data} uid_s
                         WHERE uid_s.userid = u.id AND uid_s.fieldid = :sel_fid_s) AS supervisor';
            $params['sel_fid_s'] = $supervisorid;
        }

        [$nameselects] = $this->name_field_sql('u');

        $sql = "SELECT u.id{$nameselects}, u.email, u.country,
                       u.timecreated, u.lastaccess,
                       {$estadosel}, {$supsel}
                  FROM {user} u
                       {$this->joins}
                 WHERE {$this->where}
              ORDER BY u.lastname, u.firstname";

        $records = $DB->get_records_sql($sql, $params);
        $out = [];

        foreach ($records as $r) {
            $out[] = [
                'id'         => (int)$r->id,
                // fullname() respeta la configuracion de nombres del sitio.
                'fullname'   => fullname($r),
                'email'      => $r->email,
                'country'    => $r->country,
                'estado'     => (string)$r->estado,
                'supervisor' => (string)$r->supervisor,
                // userdate() usa el huso del usuario que mira, no el del servidor.
                'lastaccess' => $r->lastaccess
                    ? userdate($r->lastaccess, get_string('strftimedatetimeshort'))
                    : get_string('never', 'local_learninganalytics'),
                'timecreated' => (int)$r->timecreated,
            ];
        }

        return $out;
    }

    /**
     * Indicadores de cabecera.
     *
     * @param array|null $users Padron ya calculado, para no repetir la consulta.
     * @return array
     */
    public function get_kpis(?array $users = null): array {
        global $DB;

        $totalusers = $users !== null
            ? count($users)
            : $DB->count_records_sql("SELECT COUNT(DISTINCT u.id) FROM {user} u {$this->joins} WHERE {$this->where}", $this->params);

        $enrolments = $DB->count_records_sql(
            "SELECT COUNT(1)
               FROM {user_enrolments} ue
               JOIN {enrol} e ON e.id = ue.enrolid
               JOIN {user} u ON u.id = ue.userid
                    {$this->joins}
              WHERE {$this->where}", $this->params);

        $certificates = 0;
        $certifiedusers = 0;

        if ($this->has_certificates()) {
            [$cjoin, $cwhere, $cparams] = $this->certificate_scope_sql();

            $certificates = $DB->count_records_sql(
                "SELECT COUNT(1)
                   FROM {customcert_issues} ci
                        {$cjoin}
                   JOIN {user} u ON u.id = ci.userid
                        {$this->joins}
                  WHERE {$this->where}{$cwhere}", $this->params + $cparams);

            // Tasa de certificacion: usuarios DISTINTOS con al menos un
            // certificado. Contar emisiones hacia que superara el 100 %.
            $certifiedusers = $DB->count_records_sql(
                "SELECT COUNT(DISTINCT ci.userid)
                   FROM {customcert_issues} ci
                        {$cjoin}
                   JOIN {user} u ON u.id = ci.userid
                        {$this->joins}
                  WHERE {$this->where}{$cwhere}", $this->params + $cparams);
        }

        $rate = $totalusers > 0 ? round(($certifiedusers / $totalusers) * 100, 1) : 0.0;

        return [
            'users'        => (int)$totalusers,
            'enrolments'   => (int)$enrolments,
            'certificates' => (int)$certificates,
            'certrate'     => $rate,
        ];
    }

    /**
     * Serie de crecimiento de usuarios por mes.
     *
     * @return array
     */
    public function get_growth(): array {
        global $DB;

        // timecreated = 0 se excluye: date('Y-m', 0) devuelve 1969-12 y
        // ensuciaba el eje X con un punto imposible.
        $sql = "SELECT u.id, u.timecreated
                  FROM {user} u
                       {$this->joins}
                 WHERE {$this->where} AND u.timecreated > 0";

        $counts = [];
        foreach ($DB->get_records_sql($sql, $this->params) as $r) {
            $key = userdate($r->timecreated, '%Y-%m');
            $counts[$key] = ($counts[$key] ?? 0) + 1;
        }

        ksort($counts);   // Sin esto los meses salian desordenados.

        return $this->to_series($counts);
    }

    /**
     * Usuarios por dominio de correo, los 10 mayores.
     *
     * @return array
     */
    public function get_domains(): array {
        global $DB;

        // Portable: el dominio se calcula en PHP. SUBSTRING_INDEX no existe
        // en PostgreSQL y dejaba los filtros vacios alli.
        $sql = "SELECT u.id, u.email
                  FROM {user} u
                       {$this->joins}
                 WHERE {$this->where} AND u.email <> ''";

        $counts = [];
        foreach ($DB->get_records_sql($sql, $this->params) as $r) {
            $at = strrchr($r->email, '@');
            if ($at === false) {
                continue;
            }
            $domain = strtolower(substr($at, 1));
            $counts[$domain] = ($counts[$domain] ?? 0) + 1;
        }

        arsort($counts);                      // Ordenar ANTES de cortar.
        $counts = array_slice($counts, 0, 10, true);

        return $this->to_series($counts);
    }

    /**
     * Usuarios por pais.
     *
     * @return array
     */
    public function get_countries(): array {
        global $DB;

        $sql = "SELECT u.country, COUNT(DISTINCT u.id) AS total
                  FROM {user} u
                       {$this->joins}
                 WHERE {$this->where} AND u.country <> ''
              GROUP BY u.country
              ORDER BY total DESC";

        // El mapa necesita el codigo ISO; la leyenda, el nombre legible.
        $countrynames = get_string_manager()->get_list_of_countries(true);

        $labels = [];
        $values = [];
        $codes = [];

        foreach ($DB->get_records_sql($sql, $this->params) as $r) {
            $code = \core_text::strtoupper($r->country);
            $codes[] = $code;
            $labels[] = $countrynames[$code] ?? $code;
            $values[] = (int)$r->total;
        }

        return ['labels' => $labels, 'values' => $values, 'codes' => $codes];
    }

    /**
     * Serie de certificados emitidos por mes.
     *
     * @return array
     */
    public function get_certificates_series(): array {
        global $DB;

        if (!$this->has_certificates()) {
            return ['labels' => [], 'values' => []];
        }

        [$cjoin, $cwhere, $cparams] = $this->certificate_scope_sql();

        $sql = "SELECT ci.id, ci.timecreated
                  FROM {customcert_issues} ci
                       {$cjoin}
                  JOIN {user} u ON u.id = ci.userid
                       {$this->joins}
                 WHERE {$this->where}{$cwhere} AND ci.timecreated > 0";

        $counts = [];
        foreach ($DB->get_records_sql($sql, $this->params + $cparams) as $r) {
            $key = userdate($r->timecreated, '%Y-%m');
            $counts[$key] = ($counts[$key] ?? 0) + 1;
        }

        ksort($counts);

        return $this->to_series($counts);
    }

    /**
     * Progreso por usuario y curso, con la columna "Firmado".
     *
     * @return array
     */
    public function get_progress(): array {
        global $DB;

        $progresslist = [];   // Inicializado siempre: si el bucle no itera,
                              // json_encode recibia una variable indefinida.

        $signaturemap = config::signature_map();

        [$nameselects, $namegroupby] = $this->name_field_sql('u');

        // El listado de cursos tambien se limita al ambito.
        $scopefilter = '';
        $scopeparams = [];
        if ($this->scopecourseids !== null) {
            if (empty($this->scopecourseids)) {
                $scopefilter = ' AND 1 = 0';
            } else {
                [$insql, $scopeparams] = $DB->get_in_or_equal($this->scopecourseids, SQL_PARAMS_NAMED, 'pscp');
                $scopefilter = " AND c.id {$insql}";
            }
        }

        $sql = "SELECT " . $DB->sql_concat('u.id', "'-'", 'c.id') . " AS uniqueid,
                       u.id AS userid{$nameselects}, u.email,
                       c.id AS courseid, c.fullname AS coursename,
                       MIN(ue.timestart) AS timestart
                  FROM {user} u
                       {$this->joins}
                  JOIN {user_enrolments} ue ON ue.userid = u.id
                  JOIN {enrol} e ON e.id = ue.enrolid
                  JOIN {course} c ON c.id = e.courseid
                 WHERE {$this->where} AND c.id <> " . SITEID . "{$scopefilter}
              GROUP BY u.id{$namegroupby}, u.email, c.id, c.fullname
              ORDER BY u.lastname, u.firstname, c.fullname";

        $records = $DB->get_records_sql($sql, $this->params + $scopeparams);

        // Firmas: una sola consulta por curso configurado, no una por fila.
        $signed = [];
        foreach ($signaturemap as $courseid => $assignid) {
            $subs = $DB->get_fieldset_select(
                'assign_submission',
                'userid',
                "assignment = :aid AND status = :status",
                ['aid' => $assignid, 'status' => 'submitted']
            );
            foreach ($subs as $uid) {
                $signed[$courseid][(int)$uid] = true;
            }
        }

        foreach ($records as $r) {
            $courseid = (int)$r->courseid;
            $userid = (int)$r->userid;

            if (!array_key_exists($courseid, $signaturemap)) {
                $signedvalue = 'na';        // El curso no tiene tarea de firma.
            } else {
                $signedvalue = !empty($signed[$courseid][$userid]) ? 'yes' : 'no';
            }

            $progresslist[] = [
                'userid'     => $userid,
                'fullname'   => fullname($r),
                'email'      => $r->email,
                'courseid'   => $courseid,
                'coursename' => format_string($r->coursename),
                'signed'     => $signedvalue,
                'timestart'  => $r->timestart
                    ? userdate($r->timestart, get_string('strftimedate'))
                    : '',
            ];
        }

        return $progresslist;
    }

    /**
     * Distribucion de usuarios por antiguedad del ultimo acceso.
     *
     * Es el indicador de uso real que faltaba: cuantos siguen entrando.
     *
     * @return array
     */
    public function get_activity(): array {
        global $DB;

        $sql = "SELECT u.id, u.lastaccess
                  FROM {user} u
                       {$this->joins}
                 WHERE {$this->where}";

        $now = time();
        $buckets = [
            'act_7'    => 0,
            'act_30'   => 0,
            'act_90'   => 0,
            'act_older' => 0,
            'act_never' => 0,
        ];

        foreach ($DB->get_records_sql($sql, $this->params) as $r) {
            if (empty($r->lastaccess)) {
                $buckets['act_never']++;
                continue;
            }
            $days = ($now - $r->lastaccess) / DAYSECS;
            if ($days <= 7) {
                $buckets['act_7']++;
            } else if ($days <= 30) {
                $buckets['act_30']++;
            } else if ($days <= 90) {
                $buckets['act_90']++;
            } else {
                $buckets['act_older']++;
            }
        }

        $labels = [];
        $values = [];
        foreach ($buckets as $key => $count) {
            $labels[] = get_string($key, 'local_learninganalytics');
            $values[] = $count;
        }

        return ['labels' => $labels, 'values' => $values];
    }

    /**
     * Cursos con mas matriculaciones dentro del ambito, los 10 mayores.
     *
     * @return array
     */
    public function get_top_courses(): array {
        global $DB;

        $scopefilter = '';
        $scopeparams = [];
        if ($this->scopecourseids !== null) {
            if (empty($this->scopecourseids)) {
                return ['labels' => [], 'values' => [], 'ids' => []];
            }
            [$insql, $scopeparams] = $DB->get_in_or_equal($this->scopecourseids, SQL_PARAMS_NAMED, 'tcp');
            $scopefilter = " AND c.id {$insql}";
        }

        $sql = "SELECT c.id, c.fullname, COUNT(DISTINCT u.id) AS total
                  FROM {user} u
                       {$this->joins}
                  JOIN {user_enrolments} ue ON ue.userid = u.id
                  JOIN {enrol} e ON e.id = ue.enrolid
                  JOIN {course} c ON c.id = e.courseid
                 WHERE {$this->where} AND c.id <> " . SITEID . "{$scopefilter}
              GROUP BY c.id, c.fullname
              ORDER BY total DESC";

        $records = $DB->get_records_sql($sql, $this->params + $scopeparams, 0, 10);

        $labels = [];
        $values = [];
        // El identificador viaja junto a la etiqueta para que al pulsar una
        // barra se pueda filtrar por ese curso: el nombre no sirve, porque se
        // recorta unas lineas mas abajo y ya no coincide con el del desplegable.
        $ids = [];
        foreach ($records as $r) {
            $name = format_string($r->fullname);
            // Nombres largos rompen la lectura del eje.
            $labels[] = \core_text::strlen($name) > 42
                ? \core_text::substr($name, 0, 40) . '...'
                : $name;
            $values[] = (int)$r->total;
            $ids[] = (int)$r->id;
        }

        return ['labels' => $labels, 'values' => $values, 'ids' => $ids];
    }

    /**
     * Usuarios con certificado frente a usuarios sin certificado.
     *
     * @return array
     */
    public function get_certification_split(): array {
        global $DB;

        if (!$this->has_certificates()) {
            return ['labels' => [], 'values' => []];
        }

        [$cjoin, $cwhere, $cparams] = $this->certificate_scope_sql();

        $total = $DB->count_records_sql(
            "SELECT COUNT(DISTINCT u.id) FROM {user} u {$this->joins} WHERE {$this->where}",
            $this->params);

        $certified = $DB->count_records_sql(
            "SELECT COUNT(DISTINCT ci.userid)
               FROM {customcert_issues} ci
                    {$cjoin}
               JOIN {user} u ON u.id = ci.userid
                    {$this->joins}
              WHERE {$this->where}{$cwhere}", $this->params + $cparams);

        return [
            'labels' => [
                get_string('cert_with', 'local_learninganalytics'),
                get_string('cert_without', 'local_learninganalytics'),
            ],
            'values' => [(int)$certified, (int)max(0, $total - $certified)],
        ];
    }

    /**
     * Fragmentos SQL con TODOS los campos de nombre que fullname() necesita.
     *
     * Sin firstnamephonetic, lastnamephonetic, middlename y alternatename,
     * fullname() emite un aviso de debugging por cada usuario procesado.
     *
     * @param string $alias Alias de la tabla user.
     * @return array [selects, groupby] ambos con coma inicial.
     */
    protected function name_field_sql(string $alias = 'u'): array {
        $fields = \core_user\fields::for_name()->get_required_fields();
        $parts = [];
        foreach ($fields as $field) {
            $parts[] = "{$alias}.{$field}";
        }
        $list = ', ' . implode(', ', $parts);

        return [$list, $list];
    }

    /**
     * Convierte un mapa clave => valor en la estructura de series del grafico.
     *
     * @param array $counts
     * @return array
     */
    protected function to_series(array $counts): array {
        return [
            'labels' => array_map('strval', array_keys($counts)),
            'values' => array_map('intval', array_values($counts)),
        ];
    }
}
