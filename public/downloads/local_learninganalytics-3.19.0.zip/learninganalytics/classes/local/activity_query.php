<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Permanencia y riesgo: consultas sobre la tabla de tiempo agregado.
 *
 * La regla de "actividad significativa" es una sola, y vive aqui: un usuario
 * esta activo si acumula al menos N horas de permanencia en los ultimos D
 * dias (por defecto 7 horas en 7 dias, configurable). Todos los indicadores
 * de la seccion de riesgo se derivan de esa regla, de modo que el tablero
 * de plataforma y el de curso no pueden discrepar en lo que llaman "activo".
 *
 * La tabla local_learninganalytics_time la rellena la tarea programada
 * aggregate_time a partir del registro estandar. Aqui no se lee el registro
 * nunca: sobre una tabla de decenas de millones de filas cada consulta seria
 * un recorrido completo.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class activity_query {

    /** Tabla de permanencia diaria. */
    const TABLE = 'local_learninganalytics_time';

    /** Tabla con el ultimo evento procesado por usuario. */
    const LAST_TABLE = 'local_learninganalytics_last';

    /** Estado: cumple la regla. */
    const STATUS_ACTIVE = 'active';

    /** Estado: tiene actividad, pero por debajo de la regla. */
    const STATUS_LOW = 'low';

    /** Estado: ni un evento en la ventana. */
    const STATUS_NONE = 'none';

    /** Ventanas que se miran para la regularidad (3 de 4). */
    const REGULAR_WINDOWS = 4;

    /** Ventanas activas necesarias para ser regular. */
    const REGULAR_NEEDED = 3;

    /** Ventanas que se dibujan en la serie historica. */
    const SERIES_WINDOWS = 8;

    /** Horizonte maximo hacia atras para entrada temprana y reactivacion. */
    const LOOKBACK = 90 * DAYSECS;

    /** Dias de margen tras matricula o mensaje. */
    const FOLLOWUP_DAYS = 7;

    /** Tamano de los tramos de identificadores en las clausulas IN. */
    const CHUNK = 1000;

    /**
     * Segundos de permanencia que exige la regla.
     *
     * @return int
     */
    public static function threshold_seconds(): int {
        $hours = (float)get_config('local_learninganalytics', 'activehours');
        if ($hours <= 0) {
            $hours = 7;
        }
        return (int)round($hours * HOURSECS);
    }

    /**
     * Horas de la regla, tal como se muestran.
     *
     * @return float
     */
    public static function threshold_hours(): float {
        return round(self::threshold_seconds() / HOURSECS, 1);
    }

    /**
     * Dias de la ventana de observacion.
     *
     * @return int
     */
    public static function window_days(): int {
        $days = (int)get_config('local_learninganalytics', 'activewindow');
        return $days > 0 ? $days : 7;
    }

    /**
     * Segundos de la ventana.
     *
     * @return int
     */
    public static function window_seconds(): int {
        return self::window_days() * DAYSECS;
    }

    /**
     * Inicio del dia (UTC) al que pertenece una marca de tiempo.
     *
     * Se usa UTC a proposito: es el unico calendario comun a una plataforma
     * con usuarios en varios husos, y la granularidad de la regla es de dias.
     *
     * @param int $timestamp
     * @return int
     */
    public static function day_start(int $timestamp): int {
        return $timestamp - ($timestamp % DAYSECS);
    }

    /**
     * Indica si la tabla existe y la tarea ya ha dejado datos.
     *
     * @return bool
     */
    public static function has_data(): bool {
        global $DB;

        if (!$DB->get_manager()->table_exists(self::TABLE)) {
            return false;
        }

        return $DB->record_exists_select(self::TABLE, '1 = 1');
    }

    /**
     * Primer dia con datos, o 0 si no hay ninguno.
     *
     * @return int
     */
    public static function coverage_start(): int {
        global $DB;

        if (!$DB->get_manager()->table_exists(self::TABLE)) {
            return 0;
        }

        return (int)$DB->get_field_sql('SELECT MIN(day) FROM {' . self::TABLE . '}');
    }

    /**
     * Estado de un usuario a partir de sus segundos en la ventana.
     *
     * @param int $seconds
     * @param int $events
     * @return string
     */
    public static function status(int $seconds, int $events = 0): string {
        if ($seconds >= self::threshold_seconds()) {
            return self::STATUS_ACTIVE;
        }
        if ($seconds > 0 || $events > 0) {
            return self::STATUS_LOW;
        }
        return self::STATUS_NONE;
    }

    /**
     * Fragmento SQL que limita los cursos, o cadena vacia sin restriccion.
     *
     * @param array|null $courseids
     * @param string $alias
     * @param string $prefix
     * @return array [sql, params]
     */
    protected static function course_sql(?array $courseids, string $alias, string $prefix): array {
        global $DB;

        if ($courseids === null) {
            return ['', []];
        }
        if (empty($courseids)) {
            return [' AND 1 = 0', []];
        }
        [$insql, $params] = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED, $prefix);
        return [" AND {$alias}.courseid {$insql}", $params];
    }

    /**
     * Segundos, eventos y dias distintos por usuario dentro de [from, to).
     *
     * @param array $userids
     * @param array|null $courseids null = sin restriccion
     * @param int $from
     * @param int $to
     * @return array userid => ['seconds' => int, 'events' => int, 'days' => int]
     */
    public static function totals(array $userids, ?array $courseids, int $from, int $to): array {
        global $DB;

        $out = [];
        if (empty($userids) || !$DB->get_manager()->table_exists(self::TABLE)) {
            return $out;
        }

        [$csql, $cparams] = self::course_sql($courseids, 't', 'tc');

        foreach (array_chunk(array_values($userids), self::CHUNK) as $i => $chunk) {
            [$usql, $uparams] = $DB->get_in_or_equal($chunk, SQL_PARAMS_NAMED, 'tu' . $i);

            $sql = "SELECT t.userid, SUM(t.seconds) AS seconds, SUM(t.events) AS events,
                           COUNT(DISTINCT t.day) AS days
                      FROM {" . self::TABLE . "} t
                     WHERE t.day >= :dfrom AND t.day < :dto AND t.userid {$usql}{$csql}
                  GROUP BY t.userid";

            $records = $DB->get_records_sql($sql,
                $uparams + $cparams + ['dfrom' => $from, 'dto' => $to]);

            foreach ($records as $r) {
                $out[(int)$r->userid] = [
                    'seconds' => (int)$r->seconds,
                    'events'  => (int)$r->events,
                    'days'    => (int)$r->days,
                ];
            }
        }

        return $out;
    }

    /**
     * Segundos por usuario y ventana, para las ultimas N ventanas.
     *
     * La ventana 0 es la mas reciente y termina ahora; la 1 es la anterior,
     * y asi sucesivamente. Cada dia se asigna a la ventana donde cae su
     * inicio.
     *
     * @param array $userids
     * @param array|null $courseids
     * @param int $windows
     * @param int|null $now Solo para pruebas.
     * @return array userid => [indice => segundos]
     */
    public static function windows(array $userids, ?array $courseids, int $windows, ?int $now = null): array {
        global $DB;

        $out = [];
        if (empty($userids) || !$DB->get_manager()->table_exists(self::TABLE)) {
            return $out;
        }

        $now = $now ?? time();
        $w = self::window_seconds();
        $from = $now - $windows * $w;

        [$csql, $cparams] = self::course_sql($courseids, 't', 'wc');

        foreach (array_chunk(array_values($userids), self::CHUNK) as $i => $chunk) {
            [$usql, $uparams] = $DB->get_in_or_equal($chunk, SQL_PARAMS_NAMED, 'wu' . $i);

            $sql = "SELECT " . $DB->sql_concat('t.userid', "'-'", 't.day') . " AS uid,
                           t.userid, t.day, SUM(t.seconds) AS seconds
                      FROM {" . self::TABLE . "} t
                     WHERE t.day >= :dfrom AND t.day <= :dto AND t.userid {$usql}{$csql}
                  GROUP BY t.userid, t.day";

            $records = $DB->get_records_sql($sql,
                $uparams + $cparams + ['dfrom' => $from, 'dto' => $now]);

            foreach ($records as $r) {
                $index = intdiv(max(0, $now - (int)$r->day - 1), $w);
                if ($index >= $windows) {
                    continue;
                }
                $uid = (int)$r->userid;
                $out[$uid][$index] = ($out[$uid][$index] ?? 0) + (int)$r->seconds;
            }
        }

        return $out;
    }

    /**
     * Condicion SQL sobre u.id para el filtro de estado de actividad.
     *
     * Se resuelve en la base de datos y no cargando ids en memoria, porque en
     * plataforma el padron puede ser de decenas de miles de personas.
     *
     * @param string $status active | low | none
     * @param array|null $courseids
     * @param string $useralias
     * @return array [where, params] where vacio si el estado no es valido
     */
    public static function status_sql(string $status, ?array $courseids, string $useralias = 'u'): array {
        global $DB;

        if (!in_array($status, [self::STATUS_ACTIVE, self::STATUS_LOW, self::STATUS_NONE], true)
                || !$DB->get_manager()->table_exists(self::TABLE)) {
            return ['', []];
        }

        $from = time() - self::window_seconds();
        $params = ['stfrom' => $from, 'stfrom2' => $from, 'stsecs' => self::threshold_seconds()];

        [$csql, $cparams] = self::course_sql($courseids, 'st', 'stc');
        [$csql2, $cparams2] = self::course_sql($courseids, 'st2', 'stc2');
        $params += $cparams + $cparams2;

        $any = "EXISTS (SELECT 1
                          FROM {" . self::TABLE . "} st
                         WHERE st.userid = {$useralias}.id AND st.day >= :stfrom{$csql})";

        $active = "EXISTS (SELECT 1
                             FROM {" . self::TABLE . "} st2
                            WHERE st2.userid = {$useralias}.id AND st2.day >= :stfrom2{$csql2}
                         GROUP BY st2.userid
                           HAVING SUM(st2.seconds) >= :stsecs)";

        switch ($status) {
            case self::STATUS_ACTIVE:
                unset($params['stfrom']);
                foreach (array_keys($cparams) as $k) {
                    unset($params[$k]);
                }
                return [" AND {$active}", $params];
            case self::STATUS_LOW:
                return [" AND {$any} AND NOT {$active}", $params];
            default:
                unset($params['stfrom2'], $params['stsecs']);
                foreach (array_keys($cparams2) as $k) {
                    unset($params[$k]);
                }
                return [" AND NOT {$any}", $params];
        }
    }

    /**
     * Entrada temprana: matriculas recientes con actividad en su curso en
     * los primeros dias.
     *
     * Solo entran matriculas con al menos FOLLOWUP_DAYS de antiguedad (aun
     * pueden entrar) y posteriores al primer dia con datos (antes no se
     * puede saber).
     *
     * @param array $userids
     * @param array|null $courseids
     * @return array ['total' => int, 'entered' => int]
     */
    public static function early_entry(array $userids, ?array $courseids): array {
        global $DB;

        $out = ['total' => 0, 'entered' => 0];
        $coverage = self::coverage_start();
        if (empty($userids) || $coverage === 0) {
            return $out;
        }

        $now = time();
        $followup = self::FOLLOWUP_DAYS * DAYSECS;
        $from = max($coverage, $now - self::LOOKBACK);
        $to = $now - $followup;
        if ($from >= $to) {
            return $out;
        }

        [$csql, $cparams] = self::course_sql($courseids, 'e', 'eec');

        foreach (array_chunk(array_values($userids), self::CHUNK) as $i => $chunk) {
            [$usql, $uparams] = $DB->get_in_or_equal($chunk, SQL_PARAMS_NAMED, 'eeu' . $i);

            // Muchas matriculas no tienen fecha de inicio: entonces vale la
            // fecha en que se creo la matricula.
            $start = '(CASE WHEN ue.timestart > 0 THEN ue.timestart ELSE ue.timecreated END)';

            $sql = "SELECT COUNT(*) AS total,
                           SUM(CASE WHEN EXISTS (
                                   SELECT 1
                                     FROM {" . self::TABLE . "} t
                                    WHERE t.userid = ue.userid
                                          AND t.courseid = e.courseid
                                          AND t.day >= {$start} - :daysecs
                                          AND t.day <= {$start} + :followup)
                               THEN 1 ELSE 0 END) AS entered
                      FROM {user_enrolments} ue
                      JOIN {enrol} e ON e.id = ue.enrolid
                     WHERE {$start} >= :efrom AND {$start} <= :eto
                           AND e.courseid <> :siteid
                           AND ue.userid {$usql}{$csql}";

            $r = $DB->get_record_sql($sql, $uparams + $cparams + [
                'daysecs' => DAYSECS, 'followup' => $followup,
                'efrom' => $from, 'eto' => $to, 'siteid' => SITEID,
            ]);

            $out['total'] += (int)($r->total ?? 0);
            $out['entered'] += (int)($r->entered ?? 0);
        }

        return $out;
    }

    /**
     * Reactivacion: personas a las que el tablero escribio (correo o mensaje
     * masivo) y que volvieron a tener actividad en los dias siguientes.
     *
     * Es el unico indicador que solo este plugin puede medir, porque los
     * envios quedan en sus propios eventos del registro.
     *
     * @param array $userids
     * @param array|null $courseids
     * @return array ['total' => int, 'reactivated' => int]
     */
    public static function reactivation(array $userids, ?array $courseids): array {
        global $DB;

        $out = ['total' => 0, 'reactivated' => 0];
        $coverage = self::coverage_start();
        if (empty($userids) || $coverage === 0
                || !$DB->get_manager()->table_exists('logstore_standard_log')) {
            return $out;
        }

        $now = time();
        $followup = self::FOLLOWUP_DAYS * DAYSECS;
        $from = max($coverage, $now - self::LOOKBACK);
        $to = $now - $followup;
        if ($from >= $to) {
            return $out;
        }

        [$csql, $cparams] = self::course_sql($courseids, 't', 'rac');

        foreach (array_chunk(array_values($userids), self::CHUNK) as $i => $chunk) {
            [$usql, $uparams] = $DB->get_in_or_equal($chunk, SQL_PARAMS_NAMED, 'rau' . $i);

            // Un mensaje por persona: el primero del periodo. Si se le
            // escribio varias veces, cuenta la primera vez.
            $sql = "SELECT COUNT(*) AS total,
                           SUM(CASE WHEN EXISTS (
                                   SELECT 1
                                     FROM {" . self::TABLE . "} t
                                    WHERE t.userid = m.userid
                                          AND t.day > m.sent - :daysecs
                                          AND t.day <= m.sent + :followup{$csql})
                               THEN 1 ELSE 0 END) AS reactivated
                      FROM (SELECT l.relateduserid AS userid, MIN(l.timecreated) AS sent
                              FROM {logstore_standard_log} l
                             WHERE l.eventname IN (:ev1, :ev2)
                                   AND l.timecreated >= :rfrom AND l.timecreated <= :rto
                                   AND l.relateduserid {$usql}
                          GROUP BY l.relateduserid) m";

            $r = $DB->get_record_sql($sql, $uparams + $cparams + [
                'daysecs'  => DAYSECS,
                'followup' => $followup,
                'ev1'      => '\\local_learninganalytics\\event\\email_sent',
                'ev2'      => '\\local_learninganalytics\\event\\bulk_message_sent',
                'rfrom'    => $from,
                'rto'      => $to,
            ]);

            $out['total'] += (int)($r->total ?? 0);
            $out['reactivated'] += (int)($r->reactivated ?? 0);
        }

        return $out;
    }

    /**
     * Porcentaje redondeado, 0 si el denominador es 0.
     *
     * @param int $part
     * @param int $total
     * @return float
     */
    public static function rate(int $part, int $total): float {
        return $total > 0 ? round($part / $total * 100, 1) : 0.0;
    }

    /**
     * Bloque de riesgo vacio, para el nivel gratuito o sin datos.
     *
     * @return array
     */
    public static function empty_block(): array {
        return [
            'available'    => false,
            'hours'        => self::threshold_hours(),
            'window'       => self::window_days(),
            'since'        => '',
            'total'        => 0,
            'active'       => 0,
            'low'          => 0,
            'none'         => 0,
            'activerate'   => 0.0,
            'regular'      => 0,
            'regularrate'  => 0.0,
            'avgdays'      => 0.0,
            'earlytotal'   => 0,
            'earlyentered' => 0,
            'earlyrate'    => 0.0,
            'reacttotal'   => 0,
            'reactivated'  => 0,
            'reactrate'    => 0.0,
            'overduedue'   => 0,
            'overduepending' => 0,
            'overduerate'  => 0.0,
            'earlyexit'    => 0,
            'earlyexitrate' => 0.0,
            'series'       => ['labels' => [], 'values' => []],
            'dist'         => ['labels' => [], 'values' => []],
            'users'        => [],
        ];
    }

    /**
     * Enriquece a cada persona con su actividad en la ventana.
     *
     * @param array $people userid => datos (fullname, email, lastaccess...)
     * @param array|null $courseids
     * @return array El mismo array con seconds, hours, days, weeks y status.
     */
    public static function annotate(array $people, ?array $courseids): array {
        if (empty($people)) {
            return $people;
        }

        $ids = array_keys($people);
        $now = time();
        $totals = self::totals($ids, $courseids, $now - self::window_seconds(), $now + DAYSECS);
        $windows = self::windows($ids, $courseids, self::REGULAR_WINDOWS, $now);
        $threshold = self::threshold_seconds();

        foreach ($people as $uid => &$p) {
            $t = $totals[$uid] ?? ['seconds' => 0, 'events' => 0, 'days' => 0];
            $weeks = 0;
            foreach ($windows[$uid] ?? [] as $seconds) {
                if ($seconds >= $threshold) {
                    $weeks++;
                }
            }
            $p['seconds'] = $t['seconds'];
            $p['hours']   = round($t['seconds'] / HOURSECS, 1);
            $p['days']    = $t['days'];
            $p['weeks']   = $weeks;
            $p['status']  = self::status($t['seconds'], $t['events']);
        }
        unset($p);

        return $people;
    }

    /**
     * Bloque completo de permanencia y riesgo para un conjunto de personas.
     *
     * @param array $people userid => datos ya anotados por annotate(). Se
     *              aceptan claves opcionales progress, overduepending y
     *              overduedue, que se copian a la tabla de personas.
     * @param array|null $courseids
     * @return array
     */
    public static function build_block(array $people, ?array $courseids): array {
        $block = self::empty_block();

        if (!self::has_data()) {
            return $block;
        }

        $block['available'] = true;
        $coverage = self::coverage_start();
        $block['since'] = $coverage ? userdate($coverage, get_string('strftimedate', 'langconfig')) : '';

        $ids = array_keys($people);
        $n = count($people);
        $block['total'] = $n;

        $daysum = 0;
        $withdays = 0;
        $rows = [];
        foreach ($people as $uid => $p) {
            $status = $p['status'] ?? self::STATUS_NONE;
            $block[$status]++;
            if (($p['weeks'] ?? 0) >= self::REGULAR_NEEDED) {
                $block['regular']++;
            }
            if (($p['days'] ?? 0) > 0) {
                $daysum += $p['days'];
                $withdays++;
            }
            if ($status !== self::STATUS_ACTIVE) {
                $rows[] = [
                    'userid'     => (int)$uid,
                    'fullname'   => (string)($p['fullname'] ?? ''),
                    'email'      => (string)($p['email'] ?? ''),
                    'hours'      => (float)($p['hours'] ?? 0),
                    'days'       => (int)($p['days'] ?? 0),
                    'weeks'      => (int)($p['weeks'] ?? 0),
                    'lastaccess' => (string)($p['lastaccesstext'] ?? ''),
                    'status'     => $status,
                    'progress'   => isset($p['progress']) ? (float)$p['progress'] : null,
                    'overduepending' => (int)($p['overduepending'] ?? 0),
                    'overduedue' => (int)($p['overduedue'] ?? 0),
                ];
            }
        }

        // Quien menos actividad tiene va primero: es a quien hay que escribir.
        usort($rows, function($a, $b) {
            return [$a['hours'], $a['days'], $a['fullname']] <=> [$b['hours'], $b['days'], $b['fullname']];
        });

        $block['users'] = $rows;
        $block['activerate'] = self::rate($block['active'], $n);
        $block['regularrate'] = self::rate($block['regular'], $n);
        $block['avgdays'] = $withdays ? round($daysum / $withdays, 1) : 0.0;

        $early = self::early_entry($ids, $courseids);
        $block['earlytotal'] = $early['total'];
        $block['earlyentered'] = $early['entered'];
        $block['earlyrate'] = self::rate($early['entered'], $early['total']);

        $react = self::reactivation($ids, $courseids);
        $block['reacttotal'] = $react['total'];
        $block['reactivated'] = $react['reactivated'];
        $block['reactrate'] = self::rate($react['reactivated'], $react['total']);

        $block['dist'] = [
            'labels' => [
                get_string('status_active', 'local_learninganalytics'),
                get_string('status_low', 'local_learninganalytics'),
                get_string('status_none', 'local_learninganalytics'),
            ],
            'values' => [$block['active'], $block['low'], $block['none']],
        ];

        $block['series'] = self::series($ids, $courseids);

        return $block;
    }

    /**
     * Personas activas por ventana, de la mas antigua a la mas reciente.
     *
     * @param array $userids
     * @param array|null $courseids
     * @return array labels, values
     */
    public static function series(array $userids, ?array $courseids): array {
        $now = time();
        $w = self::window_seconds();
        $threshold = self::threshold_seconds();
        $windows = self::windows($userids, $courseids, self::SERIES_WINDOWS, $now);

        $counts = array_fill(0, self::SERIES_WINDOWS, 0);
        foreach ($windows as $perwindow) {
            foreach ($perwindow as $index => $seconds) {
                if ($seconds >= $threshold) {
                    $counts[$index]++;
                }
            }
        }

        $labels = [];
        $values = [];
        for ($i = self::SERIES_WINDOWS - 1; $i >= 0; $i--) {
            $start = $now - ($i + 1) * $w;
            $labels[] = userdate($start, get_string('strftimedateshort', 'langconfig'));
            $values[] = $counts[$i];
        }

        return ['labels' => $labels, 'values' => $values];
    }
}
