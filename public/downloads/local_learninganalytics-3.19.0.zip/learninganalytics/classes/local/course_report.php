<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Analitica especifica de un curso.
 *
 * Cubre progreso (total, por seccion y por actividad), calificaciones (media
 * del curso y por actividad) y tiempo de permanencia estimado.
 *
 * Se degrada con elegancia: si el curso no tiene seguimiento de finalizacion,
 * o no tiene libro de calificaciones, o no hay registros, las secciones
 * correspondientes se marcan como no disponibles en lugar de fallar.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class course_report {

    /** Corte de inactividad: mas de esto entre dos eventos cierra la sesion. */
    const IDLE_CUTOFF = 1800;

    /** Tope de filas de registro a procesar, para no ahogar la peticion. */
    const LOG_ROW_CAP = 300000;

    /** @var int */
    protected $courseid;

    /** @var \stdClass */
    protected $course;

    /** @var \context_course */
    protected $context;

    /** @var array Filtros ya validados. */
    protected $filters;

    /** @var bool Si se alcanzo el tope de registros. */
    protected $logcapped = false;

    /**
     * @param int $courseid
     * @param array $filters userid, lastaccess, progressmin, progressmax,
     *                       grademin, grademax
     */
    public function __construct(int $courseid, array $filters = []) {
        global $DB;

        $this->courseid = $courseid;
        $this->course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $this->context = \context_course::instance($courseid);

        $this->filters = $filters + [
            'userid'      => 0,
            'lastaccess'  => '',
            'progressmin' => 0,
            'progressmax' => 100,
            'grademin'    => 0,
            'grademax'    => 100,
            'roleid'      => 0,
            'status'      => '',
        ];
    }

    /**
     * Ejecuta el informe completo del curso.
     *
     * @return array
     */
    public function run(): array {
        $students = $this->get_students();

        $completion = $this->get_completion_data(array_keys($students));
        $grades = $this->get_grade_data(array_keys($students));
        $times = $this->get_time_data(array_keys($students));

        $modules = $this->get_trackable_modules();
        $totalmodules = count($modules);

        // Fila por estudiante con todas sus metricas.
        $rows = [];
        foreach ($students as $userid => $user) {
            $done = $completion['peruser'][$userid] ?? [];
            $progress = $totalmodules > 0
                ? round((count($done) / $totalmodules) * 100, 1)
                : 0.0;

            $rows[] = [
                'userid'     => (int)$userid,
                'fullname'   => fullname($user),
                'email'      => $user->email,
                'progress'   => $progress,
                'grade'      => isset($grades['peruser'][$userid])
                    ? round($grades['peruser'][$userid], 1) : null,
                'lastaccess' => (int)($user->lastaccess ?? 0),
                'lastaccessformatted' => !empty($user->lastaccess)
                    ? userdate($user->lastaccess, get_string('strftimedatetimeshort'))
                    : get_string('never', 'local_learninganalytics'),
                'timespent'  => (int)($times[$userid] ?? 0),
                'timespentformatted' => $this->format_duration((int)($times[$userid] ?? 0)),
                'completedids' => $done,
            ];
        }

        // Permanencia en la ventana y actividades vencidas, por estudiante.
        $rows = $this->attach_activity($rows);
        $rows = $this->attach_overdue($rows);

        // Los filtros se aplican sobre las filas ya calculadas, de modo que
        // KPIs y graficas describen exactamente el conjunto que se ve.
        $rows = $this->apply_filters($rows);

        return [
            'kpis'        => $this->build_kpis($rows, $totalmodules),
            'risk'        => $this->build_risk($rows),
            'evaluation'  => (new evaluation_query($this->courseid, array_column($rows, 'userid')))->run(),
            'sections'    => $this->build_sections($rows, $modules),
            'activities'  => $this->build_activities($rows, $modules, $grades),
            'students'    => $this->strip_internals($rows),
            'coursename'  => format_string($this->course->fullname),
            'hascompletion' => $totalmodules > 0,
            'hasgrades'   => $grades['hasitems'],
            'haslogs'     => $times !== [],
            'logcapped'   => $this->logcapped,
            'totalmodules' => $totalmodules,
        ];
    }

    /**
     * Estudiantes del curso.
     *
     * Se usa la capacidad moodle/course:isincompletionreports, que es la que
     * el propio informe de finalizacion de Moodle emplea para decidir quien
     * cuenta como estudiante. Frente a mirar las asignaciones de rol en el
     * contexto del curso, esto ademas respeta los roles heredados de la
     * categoria y excluye las matriculaciones suspendidas o caducadas.
     *
     * @return array userid => registro de usuario
     */
    protected function get_students(): array {
        $namefields = implode(',', array_map(
            fn($f) => "u.{$f}",
            \core_user\fields::for_name()->get_required_fields()
        ));

        if (!empty($this->filters['roleid'])) {
            // Con un rol elegido se muestran sus miembros, no los estudiantes:
            // asi el panel sirve tambien para ver docentes o gestores.
            // El tercer parametro incluye los roles heredados de la categoria.
            $students = get_role_users(
                (int)$this->filters['roleid'],
                $this->context,
                true,
                "u.id, {$namefields}, u.email"
            );
        } else {
            $students = get_enrolled_users(
                $this->context,
                'moodle/course:isincompletionreports',
                0,
                "u.id, {$namefields}, u.email"
            );
        }

        if (!empty($this->filters['userid'])) {
            $wanted = (int)$this->filters['userid'];
            $students = array_filter($students, fn($u) => (int)$u->id === $wanted);
        }

        // "Ultimo acceso" en un panel de curso significa ultimo acceso AL
        // CURSO, no al sitio: eso vive en user_lastaccess, no en user.
        $this->attach_course_lastaccess($students);

        return $students;
    }

    /**
     * Anade a cada usuario su ultimo acceso al curso.
     *
     * @param array $students
     */
    protected function attach_course_lastaccess(array &$students): void {
        global $DB;

        foreach ($students as $u) {
            $u->lastaccess = 0;
        }

        if (empty($students)) {
            return;
        }

        [$usql, $uparams] = $DB->get_in_or_equal(array_keys($students), SQL_PARAMS_NAMED, 'la');

        $sql = "SELECT userid, timeaccess
                  FROM {user_lastaccess}
                 WHERE courseid = :courseid AND userid {$usql}";

        foreach ($DB->get_records_sql($sql, $uparams + ['courseid' => $this->courseid]) as $r) {
            if (isset($students[$r->userid])) {
                $students[$r->userid]->lastaccess = (int)$r->timeaccess;
            }
        }
    }

    /**
     * Modulos del curso con seguimiento de finalizacion activo.
     *
     * @return array cmid => datos del modulo
     */
    protected function get_trackable_modules(): array {
        global $DB;

        $sql = "SELECT cm.id, cm.section, cm.instance, m.name AS modname
                  FROM {course_modules} cm
                  JOIN {modules} m ON m.id = cm.module
                 WHERE cm.course = :courseid
                       AND cm.completion > 0
                       AND cm.visible = 1
                       AND cm.deletioninprogress = 0";

        $modules = $DB->get_records_sql($sql, ['courseid' => $this->courseid]);
        if (empty($modules)) {
            return [];
        }

        // Nombre legible de cada actividad y de su seccion.
        $sections = $DB->get_records('course_sections', ['course' => $this->courseid],
            'section', 'id, section, name');

        foreach ($modules as $cm) {
            $raw = $DB->get_field($cm->modname, 'name', ['id' => $cm->instance]) ?: $cm->modname;
            $cm->name = $this->clean_name($raw);
            $section = $sections[$cm->section] ?? null;
            if ($section) {
                $cm->sectionname = !empty($section->name)
                    ? format_string($section->name)
                    : get_string('sectionnumber', 'local_learninganalytics', $section->section);
                $cm->sectionnum = (int)$section->section;
            } else {
                $cm->sectionname = get_string('nosection', 'local_learninganalytics');
                $cm->sectionnum = 0;
            }
        }

        return $modules;
    }

    /**
     * Finalizaciones por usuario.
     *
     * @param array $userids
     * @return array
     */
    protected function get_completion_data(array $userids): array {
        global $DB;

        $out = ['peruser' => []];
        if (empty($userids)) {
            return $out;
        }

        $modules = $this->get_trackable_modules();
        if (empty($modules)) {
            return $out;
        }

        [$usql, $uparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'u');
        [$msql, $mparams] = $DB->get_in_or_equal(array_keys($modules), SQL_PARAMS_NAMED, 'm');

        // Estados 1 (completo) y 2 (completo con aprobado) cuentan como hecho;
        // el 3 es "completo pero suspendido" y no debe contar como logro.
        $sql = "SELECT cmc.id, cmc.userid, cmc.coursemoduleid
                  FROM {course_modules_completion} cmc
                 WHERE cmc.userid {$usql}
                       AND cmc.coursemoduleid {$msql}
                       AND cmc.completionstate IN (1, 2)";

        foreach ($DB->get_records_sql($sql, $uparams + $mparams) as $r) {
            $out['peruser'][(int)$r->userid][] = (int)$r->coursemoduleid;
        }

        return $out;
    }

    /**
     * Calificaciones: total del curso por usuario y media por actividad.
     *
     * @param array $userids
     * @return array
     */
    protected function get_grade_data(array $userids): array {
        global $DB;

        $out = ['peruser' => [], 'peritem' => [], 'hasitems' => false];
        if (empty($userids)) {
            return $out;
        }

        [$usql, $uparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'u');

        // Total del curso, normalizado a porcentaje.
        $sql = "SELECT gg.id, gg.userid, gg.finalgrade, gi.grademax
                  FROM {grade_grades} gg
                  JOIN {grade_items} gi ON gi.id = gg.itemid
                 WHERE gi.courseid = :courseid
                       AND gi.itemtype = 'course'
                       AND gg.userid {$usql}
                       AND gg.finalgrade IS NOT NULL";

        foreach ($DB->get_records_sql($sql, $uparams + ['courseid' => $this->courseid]) as $r) {
            if ($r->grademax > 0) {
                $out['peruser'][(int)$r->userid] = ($r->finalgrade / $r->grademax) * 100;
            }
        }

        // Media por actividad, tambien en porcentaje para poder compararlas.
        $sql = "SELECT gi.id, gi.itemname, gi.iteminstance, gi.itemmodule, gi.grademax,
                       AVG(gg.finalgrade) AS media, COUNT(gg.id) AS n
                  FROM {grade_items} gi
                  JOIN {grade_grades} gg ON gg.itemid = gi.id AND gg.finalgrade IS NOT NULL
                 WHERE gi.courseid = :courseid
                       AND gi.itemtype = 'mod'
                       AND gg.userid {$usql}
              GROUP BY gi.id, gi.itemname, gi.iteminstance, gi.itemmodule, gi.grademax
              ORDER BY gi.sortorder";

        foreach ($DB->get_records_sql($sql, $uparams + ['courseid' => $this->courseid]) as $r) {
            $out['hasitems'] = true;
            $out['peritem'][] = [
                'name'    => format_string($r->itemname ?: $r->itemmodule),
                'average' => $r->grademax > 0 ? round(($r->media / $r->grademax) * 100, 1) : 0.0,
                'count'   => (int)$r->n,
                'module'  => $r->itemmodule,
                'instance' => (int)$r->iteminstance,
            ];
        }

        return $out;
    }

    /**
     * Tiempo de permanencia estimado por usuario, en segundos.
     *
     * Moodle no almacena tiempo de permanencia: se deduce agrupando los
     * eventos del registro por usuario y sumando los intervalos entre eventos
     * consecutivos, cerrando la sesion cuando el hueco supera IDLE_CUTOFF.
     * Es una estimacion, no una medida exacta.
     *
     * @param array $userids
     * @return array userid => segundos
     */
    protected function get_time_data(array $userids): array {
        global $DB;

        if (empty($userids) || !$DB->get_manager()->table_exists('logstore_standard_log')) {
            return [];
        }

        [$usql, $uparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'u');
        $params = $uparams + ['courseid' => $this->courseid];

        $sql = "SELECT id, userid, timecreated
                  FROM {logstore_standard_log}
                 WHERE courseid = :courseid AND userid {$usql}
              ORDER BY userid, timecreated";

        $times = [];
        $last = [];
        $rows = 0;

        // Recordset: la tabla de registros puede ser enorme y no cabe en memoria.
        $rs = $DB->get_recordset_sql($sql, $params, 0, self::LOG_ROW_CAP);
        foreach ($rs as $r) {
            $rows++;
            $uid = (int)$r->userid;
            $t = (int)$r->timecreated;

            if (isset($last[$uid])) {
                $delta = $t - $last[$uid];
                if ($delta > 0 && $delta <= self::IDLE_CUTOFF) {
                    $times[$uid] = ($times[$uid] ?? 0) + $delta;
                }
            }
            $last[$uid] = $t;
        }
        $rs->close();

        if ($rows >= self::LOG_ROW_CAP) {
            // No callar un recorte: una cifra truncada que parece completa
            // es peor que una cifra ausente.
            $this->logcapped = true;
        }

        return $times;
    }

    /**
     * Aplica los filtros de ultimo acceso, progreso y calificacion.
     *
     * @param array $rows
     * @return array
     */
    protected function apply_filters(array $rows): array {
        $f = $this->filters;
        $now = time();

        return array_values(array_filter($rows, function($row) use ($f, $now) {

            if ($row['progress'] < $f['progressmin'] || $row['progress'] > $f['progressmax']) {
                return false;
            }

            // Estado de actividad: la misma regla que el bloque de riesgo.
            if ($f['status'] !== '' && ($row['status'] ?? '') !== $f['status']) {
                return false;
            }

            // Un usuario sin nota solo se descarta si el filtro se ha movido:
            // con el rango completo debe seguir apareciendo.
            if ($f['grademin'] > 0 || $f['grademax'] < 100) {
                if ($row['grade'] === null) {
                    return false;
                }
                if ($row['grade'] < $f['grademin'] || $row['grade'] > $f['grademax']) {
                    return false;
                }
            }

            if ($f['lastaccess'] !== '') {
                $la = $row['lastaccess'];
                if ($f['lastaccess'] === 'never') {
                    return empty($la);
                }
                if (empty($la)) {
                    return false;
                }
                $days = ($now - $la) / DAYSECS;
                if ($f['lastaccess'] === '7' && $days > 7) {
                    return false;
                }
                if ($f['lastaccess'] === '30' && $days > 30) {
                    return false;
                }
                if ($f['lastaccess'] === '90' && $days > 90) {
                    return false;
                }
                if ($f['lastaccess'] === 'older' && $days <= 90) {
                    return false;
                }
            }

            return true;
        }));
    }

    /**
     * Indicadores de cabecera del curso.
     *
     * @param array $rows
     * @param int $totalmodules
     * @return array
     */
    protected function build_kpis(array $rows, int $totalmodules): array {
        $n = count($rows);

        $progress = $n ? array_sum(array_column($rows, 'progress')) / $n : 0;
        $grades = array_filter(array_column($rows, 'grade'), fn($g) => $g !== null);
        $times = array_column($rows, 'timespent');
        $avgtime = $times ? array_sum($times) / max(1, count(array_filter($times))) : 0;

        return [
            'students'     => $n,
            'avgprogress'  => round($progress, 1),
            'avggrade'     => $grades ? round(array_sum($grades) / count($grades), 1) : 0.0,
            'gradedcount'  => count($grades),
            'avgtime'      => (int)round($avgtime),
            'avgtimeformatted' => $this->format_duration((int)round($avgtime)),
            'totalmodules' => $totalmodules,
            'completed'    => $n ? count(array_filter($rows, fn($r) => $r['progress'] >= 100)) : 0,
        ];
    }

    /**
     * Progreso medio por seccion.
     *
     * @param array $rows
     * @param array $modules
     * @return array
     */
    protected function build_sections(array $rows, array $modules): array {
        if (empty($modules) || empty($rows)) {
            return ['labels' => [], 'values' => []];
        }

        // Agrupar los modulos por seccion, conservando el orden del curso.
        $bysection = [];
        foreach ($modules as $cm) {
            $bysection[$cm->sectionnum]['name'] = $cm->sectionname;
            $bysection[$cm->sectionnum]['cmids'][] = (int)$cm->id;
        }
        ksort($bysection);

        $labels = [];
        $values = [];

        foreach ($bysection as $section) {
            $total = count($section['cmids']) * count($rows);
            $done = 0;
            foreach ($rows as $row) {
                $done += count(array_intersect($row['completedids'], $section['cmids']));
            }
            $labels[] = $section['name'];
            $values[] = $total > 0 ? round(($done / $total) * 100, 1) : 0.0;
        }

        return ['labels' => $labels, 'values' => $values];
    }

    /**
     * Progreso por actividad y su calificacion media.
     *
     * @param array $rows
     * @param array $modules
     * @param array $grades
     * @return array
     */
    protected function build_activities(array $rows, array $modules, array $grades): array {
        $out = [];
        $studentcount = count($rows);

        foreach ($modules as $cm) {
            $done = 0;
            foreach ($rows as $row) {
                if (in_array((int)$cm->id, $row['completedids'], true)) {
                    $done++;
                }
            }

            // Emparejar con la calificacion media de la misma actividad.
            $average = null;
            foreach ($grades['peritem'] as $item) {
                if ($item['module'] === $cm->modname && $item['instance'] === (int)$cm->instance) {
                    $average = $item['average'];
                    break;
                }
            }

            $out[] = [
                'cmid'        => (int)$cm->id,
                'name'        => $cm->name,
                'sectionname' => $cm->sectionname,
                'modname'     => $cm->modname,
                'completed'   => $done,
                'progress'    => $studentcount > 0 ? round(($done / $studentcount) * 100, 1) : 0.0,
                'average'     => $average,
            ];
        }

        return $out;
    }

    /**
     * Quita los campos internos que no deben viajar al navegador.
     *
     * @param array $rows
     * @return array
     */
    protected function strip_internals(array $rows): array {
        return array_map(function($row) {
            unset($row['completedids'], $row['seconds']);
            return $row;
        }, $rows);
    }

    /**
     * Anade a cada fila su permanencia en la ventana y su estado de actividad.
     *
     * Solo cuenta el tiempo en ESTE curso: un estudiante muy activo en otro
     * curso no esta activo aqui.
     *
     * @param array $rows
     * @return array
     */
    protected function attach_activity(array $rows): array {
        $people = [];
        foreach ($rows as $i => $row) {
            $people[$row['userid']] = ['index' => $i];
        }

        $people = activity_query::annotate($people, [$this->courseid]);

        foreach ($people as $p) {
            $i = $p['index'];
            $rows[$i]['seconds'] = $p['seconds'];
            $rows[$i]['hours']   = $p['hours'];
            $rows[$i]['days']    = $p['days'];
            $rows[$i]['weeks']   = $p['weeks'];
            $rows[$i]['status']  = $p['status'];
        }

        return $rows;
    }

    /**
     * Anade a cada fila sus actividades vencidas: cuantas tenian fecha limite
     * ya pasada y cuantas de ellas siguen sin entrega ni intento.
     *
     * Cubre tareas (fecha de entrega) y cuestionarios (fecha de cierre), con
     * las excepciones por usuario. Las excepciones por grupo no se aplican.
     *
     * @param array $rows
     * @return array
     */
    protected function attach_overdue(array $rows): array {
        global $DB;

        foreach ($rows as &$row) {
            $row['overduedue'] = 0;
            $row['overduepending'] = 0;
        }
        unset($row);

        if (empty($rows)) {
            return $rows;
        }

        $userids = array_column($rows, 'userid');
        $index = array_flip($userids);
        $now = time();

        [$usql, $uparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'ou');

        // Tareas visibles con fecha de entrega, que admiten entregas.
        $assigns = $DB->get_records_sql(
            "SELECT a.id, a.duedate
               FROM {assign} a
               JOIN {course_modules} cm ON cm.instance = a.id
               JOIN {modules} m ON m.id = cm.module AND m.name = 'assign'
              WHERE a.course = :courseid AND a.duedate > 0 AND a.nosubmissions = 0
                    AND cm.visible = 1 AND cm.deletioninprogress = 0",
            ['courseid' => $this->courseid]);

        $deadlines = [];   // "a-<id>" o "q-<id>" => [userid => fecha limite efectiva]
        if (!empty($assigns)) {
            [$asql, $aparams] = $DB->get_in_or_equal(array_keys($assigns), SQL_PARAMS_NAMED, 'oa');

            $overrides = $DB->get_records_sql(
                "SELECT id, assignid, userid, duedate
                   FROM {assign_overrides}
                  WHERE userid IS NOT NULL AND duedate IS NOT NULL AND assignid {$asql}", $aparams);

            foreach ($assigns as $a) {
                foreach ($userids as $uid) {
                    $deadlines['a-' . $a->id][$uid] = (int)$a->duedate;
                }
            }
            foreach ($overrides as $o) {
                if (isset($index[$o->userid])) {
                    $deadlines['a-' . $o->assignid][(int)$o->userid] = (int)$o->duedate;
                }
            }

            $submitted = $DB->get_records_sql(
                "SELECT " . $DB->sql_concat('assignment', "'-'", 'userid') . " AS uid, assignment, userid
                   FROM {assign_submission}
                  WHERE latest = 1 AND status = 'submitted' AND assignment {$asql} AND userid {$usql}",
                $aparams + $uparams);
            $done = [];
            foreach ($submitted as $sub) {
                $done['a-' . $sub->assignment][(int)$sub->userid] = true;
            }
        } else {
            $done = [];
        }

        // Cuestionarios visibles con fecha de cierre.
        $quizzes = $DB->get_records_sql(
            "SELECT q.id, q.timeclose
               FROM {quiz} q
               JOIN {course_modules} cm ON cm.instance = q.id
               JOIN {modules} m ON m.id = cm.module AND m.name = 'quiz'
              WHERE q.course = :courseid AND q.timeclose > 0
                    AND cm.visible = 1 AND cm.deletioninprogress = 0",
            ['courseid' => $this->courseid]);

        if (!empty($quizzes)) {
            [$qsql, $qparams] = $DB->get_in_or_equal(array_keys($quizzes), SQL_PARAMS_NAMED, 'oq');

            $overrides = $DB->get_records_sql(
                "SELECT id, quiz, userid, timeclose
                   FROM {quiz_overrides}
                  WHERE userid IS NOT NULL AND timeclose IS NOT NULL AND quiz {$qsql}", $qparams);

            foreach ($quizzes as $q) {
                foreach ($userids as $uid) {
                    $deadlines['q-' . $q->id][$uid] = (int)$q->timeclose;
                }
            }
            foreach ($overrides as $o) {
                if (isset($index[$o->userid])) {
                    $deadlines['q-' . $o->quiz][(int)$o->userid] = (int)$o->timeclose;
                }
            }

            $attempted = $DB->get_records_sql(
                "SELECT " . $DB->sql_concat('quiz', "'-'", 'userid') . " AS uid, quiz, userid
                   FROM {quiz_attempts}
                  WHERE state = 'finished' AND quiz {$qsql} AND userid {$usql}
               GROUP BY quiz, userid",
                $qparams + $uparams);
            foreach ($attempted as $att) {
                $done['q-' . $att->quiz][(int)$att->userid] = true;
            }
        }

        foreach ($deadlines as $key => $perUser) {
            foreach ($perUser as $uid => $deadline) {
                // Una excepcion puede quitar la fecha (0): entonces no vence.
                if ($deadline <= 0 || $deadline >= $now || !isset($index[$uid])) {
                    continue;
                }
                $i = $index[$uid];
                $rows[$i]['overduedue']++;
                if (empty($done[$key][$uid])) {
                    $rows[$i]['overduepending']++;
                }
            }
        }

        return $rows;
    }

    /**
     * Bloque de permanencia y riesgo del curso, sobre las filas ya filtradas.
     *
     * Suma a lo comun de activity_query dos cifras propias del curso: las
     * actividades vencidas pendientes y la salida temprana.
     *
     * @param array $rows
     * @return array
     */
    protected function build_risk(array $rows): array {
        $people = [];
        $due = 0;
        $pending = 0;
        $earlyexit = 0;

        foreach ($rows as $row) {
            $people[$row['userid']] = [
                'fullname'       => $row['fullname'],
                'email'          => $row['email'],
                'lastaccesstext' => $row['lastaccessformatted'],
                'progress'       => $row['progress'],
                'seconds'        => $row['seconds'] ?? 0,
                'hours'          => $row['hours'] ?? 0.0,
                'days'           => $row['days'] ?? 0,
                'weeks'          => $row['weeks'] ?? 0,
                'status'         => $row['status'] ?? activity_query::STATUS_NONE,
                'overduedue'     => $row['overduedue'] ?? 0,
                'overduepending' => $row['overduepending'] ?? 0,
            ];
            $due += $row['overduedue'] ?? 0;
            $pending += $row['overduepending'] ?? 0;
            if ($row['progress'] < 25 && ($row['status'] ?? '') === activity_query::STATUS_NONE) {
                $earlyexit++;
            }
        }

        $risk = activity_query::build_block($people, [$this->courseid]);
        $risk['overduedue'] = $due;
        $risk['overduepending'] = $pending;
        $risk['overduerate'] = activity_query::rate($pending, $due);
        $risk['earlyexit'] = $earlyexit;
        $risk['earlyexitrate'] = activity_query::rate($earlyexit, count($rows));

        return $risk;
    }

    /**
     * Sanea el nombre de una actividad para tabla y grafica.
     *
     * Los rotulos (mod_label) usan su propio contenido como nombre, asi que
     * pueden traer HTML y saltos de linea que romperian la maquetacion y el
     * eje del grafico.
     *
     * @param string $raw
     * @return string
     */
    protected function clean_name(string $raw): string {
        $text = html_to_text(format_string($raw, true), 0, false);
        $text = preg_replace('/\s+/u', ' ', $text);
        $text = trim((string)$text);

        if ($text === '') {
            return get_string('unnamedactivity', 'local_learninganalytics');
        }

        return shorten_text($text, 60);
    }

    /**
     * Formatea una duracion en segundos de forma compacta.
     *
     * @param int $seconds
     * @return string
     */
    protected function format_duration(int $seconds): string {
        if ($seconds <= 0) {
            return '-';
        }

        $hours = (int)floor($seconds / HOURSECS);
        $minutes = (int)floor(($seconds % HOURSECS) / MINSECS);

        if ($hours > 0) {
            return get_string('durationhm', 'local_learninganalytics',
                (object)['h' => $hours, 'm' => $minutes]);
        }

        return get_string('durationm', 'local_learninganalytics', $minutes);
    }
}
