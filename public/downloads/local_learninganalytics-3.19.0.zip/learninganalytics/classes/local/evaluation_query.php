<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Evaluacion y entregas de un curso: tareas y cuestionarios.
 *
 * Responde ocho preguntas sobre un conjunto de estudiantes ya filtrado:
 * cuantas entregas llegaron a tiempo, cuantos cuestionarios se completaron,
 * cuantos alcanzan la nota de aprobado, cuantas entregas calificadas llevan
 * retroalimentacion y cuantas la recibieron dentro del plazo, cuantos
 * reentregaron, cuantos intentos mejoran entre el primero y el ultimo, y si
 * el libro de calificaciones esta al dia con lo vencido.
 *
 * Todo sale de las tablas de mod_assign, mod_quiz y del libro de
 * calificaciones, con las excepciones por usuario de fecha limite. Las
 * excepciones por grupo no se aplican.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class evaluation_query {

    /** Dias de plazo para retroalimentar si el ajuste no dice otra cosa. */
    const FEEDBACK_DEFAULT_DAYS = 7;

    /** @var int */
    protected $courseid;

    /** @var array Ids de estudiantes, ya filtrados por el informe de curso. */
    protected $userids;

    /** @var int */
    protected $now;

    /**
     * @param int $courseid
     * @param array $userids
     */
    public function __construct(int $courseid, array $userids) {
        $this->courseid = $courseid;
        $this->userids = array_values(array_unique(array_map('intval', $userids)));
        $this->now = time();
    }

    /**
     * Dias de plazo para la retroalimentacion.
     *
     * @return int
     */
    public static function feedback_days(): int {
        $days = (int)get_config('local_learninganalytics', 'feedbackdays');
        return $days > 0 ? $days : self::FEEDBACK_DEFAULT_DAYS;
    }

    /**
     * Bloque vacio, con todas las claves que espera el servicio web.
     *
     * @return array
     */
    public static function empty_block(): array {
        return [
            'available'      => false,
            'feedbackdays'   => self::feedback_days(),
            'ontime'         => 0,
            'ontimeexpected' => 0,
            'ontimerate'     => 0.0,
            'quizdone'       => 0,
            'quizexpected'   => 0,
            'quizrate'       => 0.0,
            'hasmastery'     => false,
            'mastery'        => 0,
            'masteryof'      => 0,
            'masteryrate'    => 0.0,
            'feedback'       => 0,
            'graded'         => 0,
            'feedbackrate'   => 0.0,
            'feedbackintime' => 0,
            'feedbackintimerate' => 0.0,
            'resubmitted'    => 0,
            'resubmittable'  => 0,
            'resubmitrate'   => 0.0,
            'itemsuptodate'  => 0,
            'itemsdue'       => 0,
            'uptodaterate'   => 0.0,
            'hasgain'        => false,
            'gain'           => 0.0,
            'gainstudents'   => 0,
            'items'          => [],
        ];
    }

    /**
     * Calcula el bloque completo.
     *
     * @return array
     */
    public function run(): array {
        $block = self::empty_block();

        $items = array_merge($this->assignments(), $this->quizzes());
        if (empty($items)) {
            return $block;
        }

        $block['available'] = true;
        $this->attach_mastery($items);

        // Las actividades con fecha van primero, de la mas antigua a la mas
        // reciente; las que no tienen fecha, al final por nombre.
        usort($items, function($a, $b) {
            if (($a['deadlinets'] > 0) !== ($b['deadlinets'] > 0)) {
                return $a['deadlinets'] > 0 ? -1 : 1;
            }
            return [$a['deadlinets'], $a['name']] <=> [$b['deadlinets'], $b['name']];
        });

        $gainsum = 0.0;
        $gainn = 0;
        foreach ($items as $it) {
            $block['ontime'] += $it['ontime'];
            $block['ontimeexpected'] += $it['type'] === 'assign' ? $it['expected'] : 0;
            if ($it['type'] === 'quiz') {
                $block['quizdone'] += $it['delivered'];
                $block['quizexpected'] += $it['expected'];
                if ($it['gain'] !== null) {
                    $gainsum += $it['gain'] * $it['gainstudents'];
                    $gainn += $it['gainstudents'];
                }
            }
            $block['feedback'] += $it['feedback'];
            $block['graded'] += $it['type'] === 'assign' ? $it['graded'] : 0;
            $block['feedbackintime'] += $it['feedbackintime'];
            $block['resubmitted'] += $it['resubmitted'];
            $block['resubmittable'] += $it['resubmittable'];
            if ($it['due']) {
                $block['itemsdue']++;
                if ($it['uptodate']) {
                    $block['itemsuptodate']++;
                }
            }
        }

        $block['ontimerate'] = activity_query::rate($block['ontime'], $block['ontimeexpected']);
        $block['quizrate'] = activity_query::rate($block['quizdone'], $block['quizexpected']);
        $block['feedbackrate'] = activity_query::rate($block['feedback'], $block['graded']);
        $block['feedbackintimerate'] = activity_query::rate($block['feedbackintime'], $block['graded']);
        $block['resubmitrate'] = activity_query::rate($block['resubmitted'], $block['resubmittable']);
        $block['uptodaterate'] = activity_query::rate($block['itemsuptodate'], $block['itemsdue']);
        $block['hasgain'] = $gainn > 0;
        $block['gain'] = $gainn ? round($gainsum / $gainn, 1) : 0.0;
        $block['gainstudents'] = $gainn;

        [$block['hasmastery'], $block['mastery'], $block['masteryof']] = $this->course_mastery($items);
        $block['masteryrate'] = activity_query::rate($block['mastery'], $block['masteryof']);

        $block['items'] = array_map(function($it) {
            unset($it['due'], $it['instance']);
            return $it;
        }, $items);

        return $block;
    }

    /**
     * Fila base de una actividad.
     *
     * @param string $type
     * @param \stdClass $r
     * @param int $deadline
     * @return array
     */
    protected function new_item(string $type, \stdClass $r, int $deadline): array {
        return [
            'cmid'           => (int)$r->cmid,
            'instance'       => (int)$r->id,
            'name'           => format_string($r->name),
            'type'           => $type,
            'deadlinets'     => $deadline,
            'deadline'       => $deadline > 0
                ? userdate($deadline, get_string('strftimedatetimeshort', 'langconfig'))
                : '',
            'expected'       => 0,
            'delivered'      => 0,
            'deliveredrate'  => 0.0,
            'ontime'         => 0,
            'ontimerate'     => 0.0,
            'graded'         => 0,
            'feedback'       => 0,
            'feedbackrate'   => 0.0,
            'feedbackintime' => 0,
            'feedbackintimerate' => 0.0,
            'resubmitted'    => 0,
            'resubmittable'  => 0,
            'gain'           => null,
            'gainstudents'   => 0,
            'pendinggrading' => 0,
            'due'            => false,
            'uptodate'       => true,
            'gradepass'      => null,
            'mastery'        => 0,
            'masteryof'      => 0,
            'masteryrate'    => 0.0,
        ];
    }

    /**
     * Tareas del curso con sus cifras.
     *
     * @return array
     */
    protected function assignments(): array {
        global $DB;

        if (empty($this->userids)) {
            return [];
        }

        $assigns = $DB->get_records_sql(
            "SELECT a.id, a.name, a.duedate, a.attemptreopenmethod, cm.id AS cmid
               FROM {assign} a
               JOIN {course_modules} cm ON cm.instance = a.id
               JOIN {modules} m ON m.id = cm.module AND m.name = 'assign'
              WHERE a.course = :courseid AND a.nosubmissions = 0
                    AND cm.visible = 1 AND cm.deletioninprogress = 0",
            ['courseid' => $this->courseid]);
        if (empty($assigns)) {
            return [];
        }

        [$asql, $aparams] = $DB->get_in_or_equal(array_keys($assigns), SQL_PARAMS_NAMED, 'ea');
        [$usql, $uparams] = $DB->get_in_or_equal($this->userids, SQL_PARAMS_NAMED, 'eu');

        // Fecha limite por estudiante: la de la tarea salvo excepcion propia.
        $overrides = [];
        $records = $DB->get_records_sql(
            "SELECT id, assignid, userid, duedate
               FROM {assign_overrides}
              WHERE userid IS NOT NULL AND duedate IS NOT NULL AND assignid {$asql}", $aparams);
        foreach ($records as $o) {
            $overrides[(int)$o->assignid][(int)$o->userid] = (int)$o->duedate;
        }

        // Ultima entrega de cada estudiante.
        $submissions = [];
        $records = $DB->get_records_sql(
            "SELECT id, assignment, userid, status, timemodified, attemptnumber
               FROM {assign_submission}
              WHERE latest = 1 AND assignment {$asql} AND userid {$usql}", $aparams + $uparams);
        foreach ($records as $s) {
            $submissions[(int)$s->assignment][(int)$s->userid] = $s;
        }

        // Ultima calificacion de cada estudiante (una fila por intento).
        $grades = [];
        $records = $DB->get_records_sql(
            "SELECT id, assignment, userid, grade, timemodified, attemptnumber
               FROM {assign_grades}
              WHERE assignment {$asql} AND userid {$usql}
           ORDER BY attemptnumber", $aparams + $uparams);
        foreach ($records as $g) {
            $grades[(int)$g->assignment][(int)$g->userid] = $g;   // Se queda el ultimo intento.
        }

        // Retroalimentacion: comentario, archivo o formulario avanzado.
        $withfeedback = [];
        $records = $DB->get_records_sql(
            "SELECT grade FROM {assignfeedback_comments}
              WHERE assignment {$asql} AND commenttext IS NOT NULL AND commenttext <> ''", $aparams);
        foreach ($records as $f) {
            $withfeedback[(int)$f->grade] = true;
        }
        if ($DB->get_manager()->table_exists('assignfeedback_file')) {
            $records = $DB->get_records_sql(
                "SELECT grade FROM {assignfeedback_file} WHERE assignment {$asql} AND numfiles > 0", $aparams);
            foreach ($records as $f) {
                $withfeedback[(int)$f->grade] = true;
            }
        }
        $contextids = [];
        foreach ($assigns as $a) {
            $contextids[] = \context_module::instance($a->cmid)->id;
        }
        [$csql, $cparams] = $DB->get_in_or_equal($contextids, SQL_PARAMS_NAMED, 'ec');
        $records = $DB->get_records_sql(
            "SELECT gin.id, gin.itemid
               FROM {grading_instances} gin
               JOIN {grading_definitions} gd ON gd.id = gin.definitionid
               JOIN {grading_areas} ga ON ga.id = gd.areaid
              WHERE ga.component = 'mod_assign' AND ga.areaname = 'submissions'
                    AND gin.status = 1 AND ga.contextid {$csql}", $cparams);
        foreach ($records as $f) {
            $withfeedback[(int)$f->itemid] = true;
        }

        $window = self::feedback_days() * DAYSECS;
        $items = [];

        foreach ($assigns as $a) {
            $it = $this->new_item('assign', $a, (int)$a->duedate);
            $reopen = ($a->attemptreopenmethod ?? 'none') !== 'none';

            foreach ($this->userids as $uid) {
                $deadline = $overrides[$a->id][$uid] ?? (int)$a->duedate;
                $expected = $deadline > 0 && $deadline < $this->now;
                $sub = $submissions[$a->id][$uid] ?? null;
                $delivered = $sub && $sub->status === 'submitted';
                $g = $grades[$a->id][$uid] ?? null;
                $graded = $g && $g->grade !== null && (float)$g->grade >= 0;

                if ($expected) {
                    $it['expected']++;
                    $it['due'] = true;
                }
                if ($delivered) {
                    $it['delivered']++;
                    if ($expected && (int)$sub->timemodified <= $deadline) {
                        $it['ontime']++;
                    }
                    if ($reopen) {
                        $it['resubmittable']++;
                        if ((int)$sub->attemptnumber >= 1) {
                            $it['resubmitted']++;
                        }
                    }
                    if (!$graded) {
                        $it['pendinggrading']++;
                    }
                }
                if ($graded) {
                    $it['graded']++;
                    if (!empty($withfeedback[(int)$g->id])) {
                        $it['feedback']++;
                    }
                    if ($delivered && (int)$g->timemodified - (int)$sub->timemodified <= $window) {
                        $it['feedbackintime']++;
                    }
                }
            }

            $it['uptodate'] = $it['pendinggrading'] === 0;
            $it['deliveredrate'] = activity_query::rate($it['delivered'], $it['expected'] ?: count($this->userids));
            $it['ontimerate'] = activity_query::rate($it['ontime'], $it['expected']);
            $it['feedbackrate'] = activity_query::rate($it['feedback'], $it['graded']);
            $it['feedbackintimerate'] = activity_query::rate($it['feedbackintime'], $it['graded']);
            $items[] = $it;
        }

        return $items;
    }

    /**
     * Cuestionarios del curso con sus cifras.
     *
     * @return array
     */
    protected function quizzes(): array {
        global $DB;

        if (empty($this->userids)) {
            return [];
        }

        $quizzes = $DB->get_records_sql(
            "SELECT q.id, q.name, q.timeclose, q.sumgrades, cm.id AS cmid
               FROM {quiz} q
               JOIN {course_modules} cm ON cm.instance = q.id
               JOIN {modules} m ON m.id = cm.module AND m.name = 'quiz'
              WHERE q.course = :courseid AND cm.visible = 1 AND cm.deletioninprogress = 0",
            ['courseid' => $this->courseid]);
        if (empty($quizzes)) {
            return [];
        }

        [$qsql, $qparams] = $DB->get_in_or_equal(array_keys($quizzes), SQL_PARAMS_NAMED, 'eq');
        [$usql, $uparams] = $DB->get_in_or_equal($this->userids, SQL_PARAMS_NAMED, 'ev');

        $overrides = [];
        $records = $DB->get_records_sql(
            "SELECT id, quiz, userid, timeclose
               FROM {quiz_overrides}
              WHERE userid IS NOT NULL AND timeclose IS NOT NULL AND quiz {$qsql}", $qparams);
        foreach ($records as $o) {
            $overrides[(int)$o->quiz][(int)$o->userid] = (int)$o->timeclose;
        }

        // Intentos terminados, en orden, por estudiante.
        $attempts = [];
        $pending = [];
        $records = $DB->get_records_sql(
            "SELECT id, quiz, userid, attempt, sumgrades
               FROM {quiz_attempts}
              WHERE state = 'finished' AND preview = 0 AND quiz {$qsql} AND userid {$usql}
           ORDER BY quiz, userid, attempt", $qparams + $uparams);
        foreach ($records as $at) {
            $attempts[(int)$at->quiz][(int)$at->userid][] = $at->sumgrades;
            if ($at->sumgrades === null) {
                $pending[(int)$at->quiz][(int)$at->userid] = true;
            }
        }

        $items = [];
        foreach ($quizzes as $q) {
            $it = $this->new_item('quiz', $q, (int)$q->timeclose);
            $max = (float)$q->sumgrades;
            $gainsum = 0.0;

            foreach ($this->userids as $uid) {
                $close = $overrides[$q->id][$uid] ?? (int)$q->timeclose;
                // Sin fecha de cierre todos cuentan como esperados; con
                // fecha, solo quienes ya la pasaron.
                $expected = $close <= 0 || $close < $this->now;
                if ($close > 0 && $close < $this->now) {
                    $it['due'] = true;
                }
                $list = $attempts[$q->id][$uid] ?? [];

                if ($expected) {
                    $it['expected']++;
                }
                if (!empty($list)) {
                    $it['delivered']++;
                    if ($expected) {
                        $it['ontime']++;
                    }
                    if (!empty($pending[$q->id][$uid])) {
                        $it['pendinggrading']++;
                    }
                    if (count($list) >= 2 && $max > 0
                            && $list[0] !== null && end($list) !== null) {
                        $gainsum += ((float)end($list) - (float)$list[0]) / $max * 100;
                        $it['gainstudents']++;
                    }
                }
            }

            $it['uptodate'] = $it['pendinggrading'] === 0;
            $it['deliveredrate'] = activity_query::rate($it['delivered'], $it['expected']);
            $it['ontimerate'] = $it['deliveredrate'];
            $it['gain'] = $it['gainstudents'] ? round($gainsum / $it['gainstudents'], 1) : null;
            $items[] = $it;
        }

        return $items;
    }

    /**
     * Anade a cada actividad cuantos estudiantes alcanzan su nota de aprobado.
     *
     * @param array $items
     */
    protected function attach_mastery(array &$items): void {
        global $DB;

        if (empty($items) || empty($this->userids)) {
            return;
        }

        [$usql, $uparams] = $DB->get_in_or_equal($this->userids, SQL_PARAMS_NAMED, 'em');

        $records = $DB->get_records_sql(
            "SELECT gi.id, gi.itemmodule, gi.iteminstance, gi.gradepass, gi.grademax,
                    COUNT(gg.id) AS graded,
                    SUM(CASE WHEN gg.finalgrade >= gi.gradepass THEN 1 ELSE 0 END) AS passed
               FROM {grade_items} gi
               LEFT JOIN {grade_grades} gg ON gg.itemid = gi.id AND gg.finalgrade IS NOT NULL
                    AND gg.userid {$usql}
              WHERE gi.courseid = :courseid AND gi.itemtype = 'mod'
                    AND gi.itemmodule IN ('assign', 'quiz') AND gi.gradepass > 0
           GROUP BY gi.id, gi.itemmodule, gi.iteminstance, gi.gradepass, gi.grademax",
            $uparams + ['courseid' => $this->courseid]);

        $index = [];
        foreach ($records as $r) {
            $index[$r->itemmodule . '-' . $r->iteminstance] = $r;
        }

        foreach ($items as &$it) {
            $r = $index[$it['type'] . '-' . $it['instance']] ?? null;
            if (!$r) {
                continue;
            }
            $it['gradepass'] = $r->grademax > 0 ? round($r->gradepass / $r->grademax * 100, 1) : null;
            $it['masteryof'] = (int)$r->graded;
            $it['mastery'] = (int)$r->passed;
            $it['masteryrate'] = activity_query::rate($it['mastery'], $it['masteryof']);
        }
        unset($it);
    }

    /**
     * Dominio a nivel de curso.
     *
     * Si el total del curso tiene nota de aprobado, se usa esa; si no, se
     * suman las actividades que la tienen.
     *
     * @param array $items
     * @return array [hay criterio, alcanzan, evaluados]
     */
    protected function course_mastery(array $items): array {
        global $DB;

        if (empty($this->userids)) {
            return [false, 0, 0];
        }

        [$usql, $uparams] = $DB->get_in_or_equal($this->userids, SQL_PARAMS_NAMED, 'ecm');
        $r = $DB->get_record_sql(
            "SELECT COUNT(gg.id) AS graded,
                    SUM(CASE WHEN gg.finalgrade >= gi.gradepass THEN 1 ELSE 0 END) AS passed
               FROM {grade_items} gi
               JOIN {grade_grades} gg ON gg.itemid = gi.id AND gg.finalgrade IS NOT NULL
                    AND gg.userid {$usql}
              WHERE gi.courseid = :courseid AND gi.itemtype = 'course' AND gi.gradepass > 0",
            $uparams + ['courseid' => $this->courseid]);

        if ($r && (int)$r->graded > 0) {
            return [true, (int)$r->passed, (int)$r->graded];
        }

        $passed = 0;
        $graded = 0;
        $any = false;
        foreach ($items as $it) {
            if ($it['gradepass'] !== null) {
                $any = true;
                $passed += $it['mastery'];
                $graded += $it['masteryof'];
            }
        }

        return [$any, $passed, $graded];
    }
}
