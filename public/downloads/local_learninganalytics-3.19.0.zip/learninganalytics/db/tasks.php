<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Scheduled tasks.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => 'local_learninganalytics\task\revalidate_licence',
        // Una vez al dia, de madrugada: revocar no es urgente y asi no compite
        // con las tareas pesadas del sitio.
        'blocking'  => 0,
        'minute'    => 'R',
        'hour'      => '4',
        'day'       => '*',
        'dayofweek' => '*',
        'month'     => '*',
    ],
    [
        'classname' => 'local_learninganalytics\task\aggregate_time',
        // Cada media hora: procesa el registro por tramos y deja el cursor
        // donde se quedo, asi que una ejecucion corta no pierde nada.
        'blocking'  => 0,
        'minute'    => '*/30',
        'hour'      => '*',
        'day'       => '*',
        'dayofweek' => '*',
        'month'     => '*',
    ],
];
