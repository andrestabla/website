<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Cadenas en espanol.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Learning Analytics';
$string['dashboard'] = 'Panel de Learning Analytics';
$string['settings'] = 'Ajustes de Learning Analytics';

// Capacidades.
$string['learninganalytics:view'] = 'Ver el panel de Learning Analytics';
$string['learninganalytics:resendcredentials'] = 'Reenviar credenciales de acceso a los usuarios';

// Ajustes.
$string['field_estado'] = 'Campo de perfil «Estado»';
$string['field_estado_desc'] = 'Campo de perfil personalizado que se usa como columna «Estado». Dejar vacío para ocultar la columna.';
$string['field_supervisor'] = 'Campo de perfil «Supervisor»';
$string['field_supervisor_desc'] = 'Campo de perfil personalizado que se usa como columna «Supervisor». Dejar vacío para ocultar la columna.';
$string['sender'] = 'Remitente de credenciales';
$string['sender_desc'] = 'Nombre de usuario de la cuenta remitente al reenviar credenciales. Dejar vacío para usar el administrador principal del sitio.';
$string['signaturemap'] = 'Mapa de tareas de firma';
$string['signaturemap_desc'] = 'Una línea por curso, con el formato <code>shortname_curso : tarea</code>, donde tarea es el id de la tarea o su nombre exacto. Se usa para la columna «Firmado». Dejar vacío para ocultar la columna.';

// Interfaz del panel.
$string['filters'] = 'Filtros';
$string['filter_course'] = 'Curso';
$string['filter_country'] = 'País';
$string['filter_domain'] = 'Dominio de correo';
$string['filter_estado'] = 'Estado';
$string['filter_supervisor'] = 'Supervisor';
$string['filter_startdate'] = 'Desde';
$string['filter_enddate'] = 'Hasta';
$string['filter_user'] = 'Buscar usuario';
$string['filter_all'] = 'Todos';
$string['applyfilters'] = 'Aplicar filtros';
$string['resetfilters'] = 'Limpiar';

$string['kpi_users'] = 'Usuarios';
$string['kpi_enrolments'] = 'Matriculaciones';
$string['kpi_certificates'] = 'Certificados emitidos';
$string['kpi_certrate'] = 'Tasa de certificación';

$string['chart_growth'] = 'Crecimiento de usuarios';
$string['chart_domains'] = 'Usuarios por dominio';
$string['chart_countries'] = 'Usuarios por país';
$string['chart_certificates'] = 'Certificados en el tiempo';

$string['tab_users'] = 'Usuarios';
$string['tab_progress'] = 'Progreso';
$string['tab_certificates'] = 'Certificados';

$string['col_name'] = 'Nombre';
$string['col_email'] = 'Correo';
$string['col_country'] = 'País';
$string['col_estado'] = 'Estado';
$string['col_supervisor'] = 'Supervisor';
$string['col_lastaccess'] = 'Último acceso';
$string['col_course'] = 'Curso';
$string['col_progress'] = 'Progreso';
$string['col_signed'] = 'Firmado';
$string['col_certificate'] = 'Certificado';
$string['col_issued'] = 'Emitido';

$string['yes'] = 'Sí';
$string['no'] = 'No';
$string['notapplicable'] = 'No aplica';
$string['never'] = 'Nunca';
$string['nodata'] = 'Ningún dato coincide con los filtros actuales.';
$string['nodate'] = 'Sin fecha';
$string['loading'] = 'Cargando...';

// Exportación.
$string['export'] = 'Exportar';
$string['exportcsv'] = 'Descargar CSV';

// Reenvío de credenciales.
$string['resendcredentials'] = 'Reenviar credenciales de acceso';
$string['resendconfirm'] = '¿Reenviar credenciales a los {$a} usuario(s) seleccionados?';
$string['resendconfirmdetail'] = 'Se generará una contraseña nueva y se enviará por correo. Los usuarios deberán cambiarla en su siguiente acceso.';
$string['resendnousers'] = 'No hay usuarios seleccionados.';
$string['resendresults'] = 'Resultado del reenvío';
$string['resendsent'] = 'Enviado a {$a}';
$string['resendskippedauth'] = 'Omitido {$a}: la cuenta usa autenticación externa (SSO/LDAP) y su contraseña no la gestiona Moodle.';
$string['resendfailed'] = 'Falló para {$a}: no se pudo enviar el mensaje. Revise la configuración de correo del sitio.';
$string['resendsummary'] = '{$a->sent} enviados, {$a->skipped} omitidos, {$a->failed} fallidos.';
$string['resendsubject'] = 'Tus credenciales de acceso para {$a}';
$string['backtodashboard'] = 'Volver al panel';

// Avisos.
$string['customcertmissing'] = 'El plugin Custom certificate (mod_customcert) no está instalado, por lo que no hay datos de certificados.';
$string['fieldsnotconfigured'] = 'Los campos de perfil Estado y Supervisor no están configurados. Defínalos en los ajustes del plugin para habilitar esas columnas.';

// Privacidad.
$string['privacy:metadata:ai'] = 'Histórico de consultas del asistente de IA. Cada fila pertenece a un solo usuario y solo él la ve en el tablero.';
$string['privacy:metadata:ai:userid'] = 'Usuario que hizo la consulta.';
$string['privacy:metadata:ai:contextid'] = 'Contexto del tablero (plataforma, categoría o curso) desde el que se preguntó.';
$string['privacy:metadata:ai:mode'] = 'Tipo de consulta: respuesta breve o informe detallado.';
$string['privacy:metadata:ai:question'] = 'Texto de la pregunta escrita por el usuario.';
$string['privacy:metadata:ai:answer'] = 'Respuesta generada por el servicio de IA.';
$string['privacy:metadata:ai:timecreated'] = 'Momento de la consulta.';
$string['privacy:metadata:algoritmot'] = 'Servicio de analítica conversacional de Algoritmo T. Solo interviene si el administrador activó la función; la consulta se procesa con un proveedor de IA externo. Nunca se envían nombres, correos ni identificadores de estudiantes.';
$string['privacy:metadata:algoritmot:question'] = 'La pregunta escrita por el usuario.';
$string['privacy:metadata:algoritmot:series'] = 'Las cifras agregadas visibles en el tablero (títulos de bloques, etiquetas y valores numéricos).';

// Acceso y ubicacion (v2.1).
$string['hdr_access'] = 'Acceso';
$string['hdr_access_desc'] = 'Define quién puede abrir los tableros. Seleccionar un rol le concede la capacidad correspondiente de Moodle, de modo que la interfaz nativa de Roles queda sincronizada y puede seguir usándose para excepciones más finas.';
$string['viewroles'] = 'Roles que pueden ver los tableros';
$string['viewroles_desc'] = 'Los administradores del sitio siempre tienen acceso. Un rol seleccionado aquí recibe <code>local/learninganalytics:view</code>. Dónde ve el tablero ese rol depende de dónde esté asignado: un gestor a nivel de sistema ve el tablero de plataforma; un profesor en un curso ve solo ese curso.';
$string['resendroles'] = 'Roles que pueden reenviar credenciales';
$string['resendroles_desc'] = 'Concede <code>local/learninganalytics:resendcredentials</code>. Es una capacidad de alto riesgo: genera contraseñas nuevas y las envía por correo. Déjelo vacío para restringirla a los administradores del sitio.';

$string['hdr_placement'] = 'Ubicación';
$string['hdr_placement_desc'] = 'Define en qué niveles aparece el tablero. Un nivel desactivado es inaccesible incluso por URL directa.';
$string['enablesite'] = 'Nivel plataforma';
$string['enablesite_desc'] = 'Muestra el tablero global en Administración del sitio → Informes. Abarca todos los cursos.';
$string['enablecategory'] = 'Nivel categoría';
$string['enablecategory_desc'] = 'Añade el tablero a los ajustes de categoría. Abarca la categoría y sus subcategorías.';
$string['enablecourse'] = 'Nivel curso';
$string['enablecourse_desc'] = 'Añade el tablero al menú del curso. Abarca únicamente ese curso.';

$string['hdr_data'] = 'Correspondencia de datos';
$string['hdr_data_desc'] = 'Asocia los campos de perfil y las tareas de esta plataforma con las columnas del informe. Nada está cableado: dejar un valor vacío oculta la columna correspondiente.';
$string['hdr_credentials'] = 'Reenvío de credenciales';
$string['hdr_credentials_desc'] = 'Ajustes de la acción masiva «Reenviar credenciales de acceso».';

$string['dashboardfor'] = 'Learning Analytics: {$a}';
$string['levelnotenabled'] = 'El tablero de Learning Analytics no está habilitado en este nivel. Un administrador del sitio puede habilitarlo en los ajustes del plugin.';
$string['scope_site'] = 'Toda la plataforma';
$string['scope_category'] = 'Categoría';
$string['scope_course'] = 'Curso';

// Graficas v2.2.
$string['chart_activity'] = 'Actividad por último acceso';
$string['chart_topcourses'] = 'Cursos con más matriculaciones';
$string['chart_certsplit'] = 'Usuarios certificados';
$string['chart_map'] = 'Distribución geográfica';
$string['act_7'] = 'Últimos 7 días';
$string['act_30'] = 'Últimos 30 días';
$string['act_90'] = 'Últimos 90 días';
$string['act_older'] = 'Más de 90 días';
$string['act_never'] = 'Nunca accedió';
$string['cert_with'] = 'Con certificado';
$string['cert_without'] = 'Sin certificado';
$string['maphint'] = 'El tamaño de la burbuja es proporcional al número de usuarios. Se dibuja localmente: no se solicitan mosaicos a servidores externos.';
$string['nocountrydata'] = 'Ningún usuario tiene país definido en su perfil.';
$string['nousers'] = 'sin usuarios';

// Analitica de curso v2.4.
$string['coursepanel'] = 'Analítica del curso';
$string['courseonlyreport'] = 'Este informe solo está disponible a nivel de curso.';
$string['kpi_students'] = 'Estudiantes';
$string['kpi_avgprogress'] = 'Progreso promedio';
$string['kpi_avggrade'] = 'Calificación promedio';
$string['kpi_avgtime'] = 'Permanencia promedio';
$string['kpi_completed'] = 'Completaron el curso';
$string['chart_sections'] = 'Progreso por sección';
$string['chart_activities'] = 'Progreso por actividad';
$string['chart_activitygrades'] = 'Calificación promedio por actividad';
$string['tab_students'] = 'Estudiantes';
$string['tab_activities'] = 'Actividades';
$string['col_progress'] = 'Progreso';
$string['col_grade'] = 'Calificación';
$string['col_timespent'] = 'Permanencia';
$string['col_activity'] = 'Actividad';
$string['col_section'] = 'Sección';
$string['col_completedby'] = 'Completada por';
$string['col_avggrade'] = 'Calificación promedio';
$string['sectionnumber'] = 'Sección {$a}';
$string['nosection'] = 'Sin sección';
$string['durationhm'] = '{$a->h} h {$a->m} min';
$string['durationm'] = '{$a} min';
$string['filter_lastaccess'] = 'Último acceso';
$string['filter_progressrange'] = 'Progreso (%)';
$string['filter_graderange'] = 'Calificación (%)';
$string['filter_student'] = 'Estudiante';
$string['la_older'] = 'Más de 90 días';
$string['nocompletion'] = 'Este curso no tiene activado el seguimiento de finalización, por lo que no se puede calcular el progreso. Actívelo en los ajustes del curso y defina condiciones de finalización en las actividades.';
$string['nogrades'] = 'Este curso aún no tiene actividades calificadas.';
$string['timeestimated'] = 'La permanencia es una estimación derivada de los registros de actividad: se suman los eventos consecutivos y un hueco mayor de 30 minutos cierra la sesión. No es una medición exacta.';
$string['logcapped'] = 'El volumen de registros superó el límite de procesamiento, por lo que los tiempos mostrados cubren solo parte del historial.';
$string['unnamedactivity'] = '(actividad sin nombre)';

// Cascada de categorías v2.6.
$string['filter_category'] = 'Categoría';
$string['filter_subcategory'] = 'Subcategoría';
$string['filter_categorylevel'] = 'Categoría (nivel {$a})';
$string['filter_role'] = 'Rol';
$string['sendmessage'] = 'Mensaje';
$string['col_actions'] = 'Acciones';

// Envío masivo v2.9.
$string['learninganalytics:sendbulkmessage'] = 'Enviar un mensaje a todos los usuarios que devuelve un filtro';
$string['bulkmessage'] = 'Enviar mensaje a los usuarios filtrados';
$string['bulkmessagebutton'] = 'Mensaje a los filtrados';
$string['bulkmessageroles'] = 'Roles que pueden enviar mensajes masivos';
$string['bulkmessageroles_desc'] = 'Concede <code>local/learninganalytics:sendbulkmessage</code>. Es la capacidad de mayor riesgo del plugin: alcanza de una vez a todos los usuarios que devuelve un filtro. Déjelo vacío para restringirla a los administradores del sitio.';
$string['bulkmessagelimit'] = 'Máximo de destinatarios por envío';
$string['bulkmessagelimit_desc'] = 'Un envío que supere esta cifra se rechaza en lugar de recortarse. Por defecto 200.';
$string['bulkmessagetext'] = 'Mensaje';
$string['bulkmessagetext_help'] = 'Texto plano. Se entrega como mensaje personal de Moodle desde su cuenta a cada destinatario, y cada persona solo ve su propia copia.';
$string['bulkmessagesend'] = 'Enviar mensaje';
$string['bulkmessageconfirm'] = 'Este mensaje se enviará a {$a} personas';
$string['bulkmessagerecipients'] = 'Destinatarios:';
$string['bulkmessageresults'] = 'Resultado del envío';
$string['bulkmessagesummary'] = '{$a->sent} enviados, {$a->blocked} no permitidos, {$a->failed} fallidos.';
$string['bulkmessageblocked'] = 'sus ajustes de privacidad no permiten su mensaje';
$string['bulkmessagefailed'] = 'la entrega falló';
$string['bulkmessagenorecipients'] = 'El filtro actual no devuelve a nadie a quien escribir.';
$string['bulkmessagetoomany'] = 'El filtro devuelve {$a->count} destinatarios, por encima del límite de {$a->limit}. Acote el filtro o suba el límite en los ajustes del plugin.';
$string['messagingdisabled'] = 'La mensajería está desactivada en este sitio.';
$string['event_bulkmessagesent'] = 'Mensaje masivo enviado desde Learning Analytics';

// Modal de correo v3.0.
$string['learninganalytics:sendmessage'] = 'Enviar un correo a un usuario desde el tablero';
$string['emailtitle'] = 'Enviar correo';
$string['emailsubject'] = 'Asunto';
$string['emailbody'] = 'Mensaje';
$string['emailsend'] = 'Enviar correo';
$string['emailrecipient'] = 'Se enviará a:';
$string['emailsentok'] = 'Correo enviado a {$a}.';
$string['emailsentfail'] = 'No se pudo enviar el correo. Revise la configuración de correo del sitio.';
$string['emailnoaddress'] = 'Este usuario no tiene dirección de correo registrada.';
$string['emailempty'] = 'Hacen falta tanto el asunto como el mensaje.';
$string['usernotinscope'] = 'Ese usuario no pertenece al ámbito que está consultando.';
$string['event_emailsent'] = 'Correo enviado desde Learning Analytics';
$string['messageroles'] = 'Roles que pueden enviar correos';
$string['messageroles_desc'] = 'Concede <code>local/learninganalytics:sendmessage</code>, que permite enviar un correo a un usuario a la vez desde el tablero.';
$string['emailsubject_course'] = 'Tu progreso en {$a}';
$string['emailbody_course'] = 'Hola {$a->name}:

Te escribo en relación con tu avance en «{$a->course}».

  Progreso:            {$a->progress}%
  Calificación:        {$a->grade}
  Último acceso:       {$a->lastaccess}
  Permanencia:         {$a->timespent}

';
$string['emailsubject_general'] = 'Un mensaje sobre tu aprendizaje';
$string['emailbody_general'] = 'Hola {$a->name}:

  Último acceso: {$a->lastaccess}

';

// Apariencia del correo v3.1.
$string['hdr_email'] = 'Apariencia del correo';
$string['hdr_email_desc'] = 'Cabecera, color y pie de los correos que se envían desde el tablero.';
$string['emaillogo'] = 'Logo para el correo';
$string['emaillogo_desc'] = 'Se muestra en la cabecera del correo. Se aceptan PNG, JPG, GIF y SVG. La mayoría de clientes de correo no renderizan SVG, así que un SVG subido se convierte a PNG automáticamente cuando el servidor dispone de conversor; la conversión se cachea y se rehace al cambiar el logo. Si no hay conversor instalado se envía el SVG tal cual, y algunos clientes no lo mostrarán. Si se deja vacío, se usa el logo del sitio cuando su formato lo permite y, en su defecto, se muestra el nombre del sitio como texto.';
$string['emaillogo_svgnote'] = 'Hay un logo SVG en uso, pero el servidor no tiene instalado un conversor de SVG, por lo que el logo no aparecerá en la mayoría de clientes de correo. Instale <code>librsvg2-bin</code> en el servidor o suba una versión en PNG.';
$string['emailaccent'] = 'Color de acento';
$string['emailaccent_desc'] = 'Color hexadecimal de la banda de cabecera y los enlaces, por ejemplo <code>#2a72b0</code>.';
$string['emailfooter'] = 'Texto del pie';
$string['emailfooter_desc'] = 'Texto opcional que aparece sobre el nombre del sitio en el pie, para avisos de contacto o legales.';

$string['emailresult_ok'] = 'Correo enviado';
$string['emailresult_fail'] = 'No se pudo enviar';

// Descargas v3.4.
$string['exp_full'] = 'Descargar';
$string['exp_chartsblock'] = 'Solo gráficas';
$string['exp_menulabel'] = 'Descargar {$a}';
$string['exp_kpis'] = 'Cifras clave';
$string['exp_coursekpis'] = 'Cifras clave del curso';
$string['exp_indicator'] = 'Indicador';
$string['exp_value'] = 'Valor';
$string['exp_category'] = 'Categoría';
$string['exp_type'] = 'Tipo';
$string['exp_unknownformat'] = 'Formato de descarga desconocido.';

$string['exp_workspace'] = 'Todo el área de trabajo';
$string['exp_tablesblock'] = 'Solo tablas';
$string['exp_aspdf'] = 'PDF (con gráficas)';
$string['exp_asxlsx'] = 'Excel (.xlsx)';
$string['exp_ascsv'] = 'CSV';

$string['bulkchannel'] = 'Enviar por';
$string['bulkchannel_help'] = 'El correo llega a la bandeja de entrada del destinatario con la cabecera y el pie del sitio, y necesita asunto. El mensaje de Moodle se queda dentro de la plataforma y respeta los ajustes de privacidad de mensajería de cada usuario.';
$string['bulkchannel_email'] = 'Correo electrónico';
$string['bulkchannel_message'] = 'Mensaje de Moodle';
$string['bulkmessagenoaddress'] = 'no tiene dirección de correo registrada';

// Licenciamiento v3.8.
$string['hdr_licence'] = 'Licencia';
$string['hdr_licence_desc'] = 'Sin licencia el plugin muestra las métricas gratuitas: total de usuarios y certificados, crecimiento de usuarios, cursos con más matriculaciones y descarga en CSV. La licencia habilita los filtros, las tablas, el mapa, la analítica de curso, la mensajería y las descargas en XLSX, PDF y JPG. Las licencias se emiten en <a href="https://www.algoritmot.com/learning_analytics" target="_blank">algoritmot.com/learning_analytics</a>.';
$string['lic_key'] = 'Código de activación';
$string['lic_key_desc'] = 'Pegue el código emitido para esta plataforma. El identificador de su sitio es <code>{$a}</code> — indíquelo al solicitar la licencia.';
$string['lic_active'] = '<strong>Licencia activa</strong> — {$a->customer}. Vigente hasta {$a->expires}.';
$string['lic_noexpiry'] = 'sin fecha de caducidad';
$string['lic_reason_nocode'] = '<strong>Versión gratuita.</strong> No se ha introducido código de activación.';
$string['lic_reason_invalid'] = '<strong>El código no es válido.</strong> Compruebe que se copió completo.';
$string['lic_reason_expired'] = '<strong>La licencia ha caducado.</strong> Renuévela para recuperar todas las funciones.';
$string['lic_reason_wrongsite'] = '<strong>Este código pertenece a otra plataforma.</strong> Solicite uno para el identificador de este sitio.';
$string['lic_reason_revoked'] = '<strong>La licencia fue revocada.</strong> Contacte con Algoritmo T.';
$string['lic_required'] = 'Esta función requiere una licencia activa.';
$string['lic_upsell'] = 'Está usando la versión gratuita: cifras generales, crecimiento de usuarios y cursos con más matriculaciones. Los filtros, las tablas, el mapa, la analítica de curso, la mensajería y las descargas avanzadas requieren licencia.';
$string['lic_activate'] = 'Activar';
$string['task_revalidate'] = 'Revalidar licencia de Learning Analytics';

// Ficha de cada indicador: que mide, de donde sale y con que regla. Sin esto,
// dos areas leen la misma cifra de forma distinta y nadie sabe cual es la buena.
$string['whatisthis'] = 'Cómo se calcula';
$string['generatedat'] = 'Datos calculados a las {$a}';
$string['def_growth'] = 'Usuarios nuevos por mes, según la fecha en que se creó cada cuenta en Moodle (campo timecreated). Cuenta altas, no actividad: un usuario creado en marzo aparece en marzo aunque nunca haya entrado.';
$string['def_domains'] = 'Reparto de usuarios por el dominio de su correo, tomando lo que sigue a la arroba. Sirve para distinguir de qué institución procede cada grupo.';
$string['def_countries'] = 'País declarado en el perfil de Moodle de cada usuario. No se deduce de la dirección IP: si el perfil está vacío, ese usuario no aparece en el mapa.';
$string['def_activity'] = 'Reparto de usuarios por su último acceso a la plataforma, medido desde hoy. «Nunca accedió» son cuentas creadas que jamás iniciaron sesión.';
$string['def_topcourses'] = 'Cursos ordenados por número de usuarios matriculados distintos. Un usuario con dos matriculaciones en el mismo curso cuenta una vez.';
$string['def_certificates'] = 'Certificados emitidos por mes con la actividad mod_customcert. Si un curso emite certificados por otro medio, aquí no se ven.';
$string['def_certsplit'] = 'Cuántos usuarios del ámbito han obtenido al menos un certificado y cuántos ninguno.';
$string['def_certrate'] = 'Porcentaje de usuarios con al menos un certificado sobre el total de usuarios del ámbito. No es el porcentaje de cursos aprobados.';
$string['def_sections'] = 'Porcentaje medio de finalización de las actividades de cada sección, sobre los estudiantes del curso. Solo cuentan las actividades con seguimiento de finalización activado.';
$string['def_activities'] = 'Porcentaje de estudiantes que han completado cada actividad. Una actividad sin seguimiento de finalización configurado aparece en cero.';
$string['def_activitygrades'] = 'Calificación media de cada actividad calificable, sobre 100. Solo entran los estudiantes que tienen nota: quien no ha entregado no baja la media.';

// Analitica conversacional. La consulta la resuelve Algoritmo T, no esta
// plataforma: de ahi el cupo y el aviso sobre que se envia.
$string['ai_heading'] = 'Pregunta sobre estas cifras';
$string['ai_intro'] = 'Escribe una pregunta y se responderá con los datos que tienes en pantalla. Solo se envían las cifras agregadas de los bloques visibles: ninguna persona, ningún correo.';
$string['ai_placeholder'] = 'Por ejemplo: ¿dónde está el mayor problema y qué haría primero?';
$string['ai_ask'] = 'Preguntar';
$string['ai_asking'] = 'Consultando…';
$string['ai_remaining'] = 'Quedan {$a} consultas en tu bolsa.';
$string['ai_nodata'] = 'No hay ninguna gráfica con datos en pantalla sobre la que preguntar.';
$string['ai_notincluded'] = 'Esta plataforma no tiene habilitada la analítica conversacional.';
$string['ai_unreachable'] = 'No se pudo contactar con el servicio. Inténtalo de nuevo en un momento.';
$string['ai_failed'] = 'No se pudo resolver la consulta.';
$string['ai_disclaimer'] = 'Respuesta generada automáticamente a partir de las cifras mostradas. Contrástala antes de tomar una decisión.';

// Explicación por gráfica. Cada una descuenta una consulta de la bolsa, así
// que el aviso tiene que ser explícito antes de gastar.
$string['ai_explain'] = 'Explicar con IA';
$string['ai_explainq'] = 'Explica en dos o tres frases qué muestra este bloque y qué conviene mirar.';
$string['ai_explaincost'] = 'Cada explicación descuenta una consulta de tu bolsa. Te quedan {$a}. ¿Continuar?';
$string['ai_explainnote'] = 'Ha consumido una consulta de la bolsa. Quedan {$a}.';
$string['ai_empty'] = 'Este bloque no tiene datos que explicar.';

// Modo informe: mismo coste que una pregunta, pero salida estructurada.
$string['ai_mode_answer'] = 'Respuesta breve';
$string['ai_mode_report'] = 'Informe detallado';
$string['ai_reportplaceholder'] = 'Qué debe cubrir el informe. Por ejemplo: estado de la plataforma para el comité del lunes, con foco en abandono.';
$string['ai_pdftitle'] = 'Análisis con IA';
$string['ai_open'] = 'Asistente IA';
$string['ai_close'] = 'Cerrar el asistente';
$string['ai_history'] = 'Tus consultas anteriores';
$string['ai_historyempty'] = 'Todavía no has hecho ninguna consulta.';
