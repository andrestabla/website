<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics;

use local_learninganalytics\local\activity_query;

/**
 * Expone los ayudantes protegidos del servicio para poder comprobarlos.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class ask_ai_probe extends \local_learninganalytics\external\ask_ai {

    /**
     * @param array $risk
     * @param bool $iscourse
     * @return array
     */
    public static function pairs(array $risk, bool $iscourse): array {
        return self::risk_pairs($risk, $iscourse);
    }

    /**
     * @param string $key
     * @param array $pairs
     * @return array|null
     */
    public static function fig(string $key, array $pairs): ?array {
        return self::figures($key, $pairs);
    }
}

/**
 * Tests de lo que la IA recibe del bloque de riesgo.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \local_learninganalytics\external\ask_ai
 */
final class ask_ai_test extends \advanced_testcase {

    /**
     * Cada etiqueta lleva su unidad y las cifras sin denominador no viajan.
     */
    public function test_risk_pairs_carry_their_unit(): void {
        $this->resetAfterTest();

        $risk = activity_query::empty_block();
        $risk = array_merge($risk, [
            'available' => true, 'total' => 10, 'active' => 4, 'low' => 3, 'none' => 3,
            'activerate' => 40.0, 'regularrate' => 20.0, 'avgdays' => 2.5,
            // Sin matriculas recientes ni mensajes enviados: no hay denominador.
            'earlytotal' => 0, 'earlyrate' => 0.0,
            'reacttotal' => 0, 'reactrate' => 0.0,
        ]);

        $pairs = ask_ai_probe::pairs($risk, false);
        $labels = array_keys($pairs);

        // El porcentaje se distingue del recuento por la propia etiqueta.
        $this->assertContains(get_string('kpi_active', 'local_learninganalytics') . ' (%)', $labels);
        $this->assertSame(40.0, $pairs[get_string('kpi_active', 'local_learninganalytics') . ' (%)']);
        $this->assertSame(3, $pairs[get_string('kpi_none', 'local_learninganalytics')]);

        // Un cero sin denominador se leeria como un mal resultado: se omite.
        $this->assertNotContains(get_string('kpi_early', 'local_learninganalytics') . ' (%)', $labels);
        $this->assertNotContains(get_string('kpi_react', 'local_learninganalytics') . ' (%)', $labels);

        // Lo propio del curso solo aparece en el ambito de curso.
        $this->assertNotContains(get_string('kpi_earlyexit', 'local_learninganalytics') . ' (%)', $labels);
        $encurso = array_keys(ask_ai_probe::pairs($risk, true));
        $this->assertContains(get_string('kpi_earlyexit', 'local_learninganalytics') . ' (%)', $encurso);
    }

    /**
     * La serie de cifras conserva el orden y descarta los valores ausentes.
     */
    public function test_figures(): void {
        $this->resetAfterTest();

        $this->assertNull(ask_ai_probe::fig('risk_heading', []));
        $this->assertNull(ask_ai_probe::fig('risk_heading', ['a' => null]));

        $serie = ask_ai_probe::fig('risk_heading', ['Uno' => 1, 'Dos' => null, 'Tres' => 3.5]);

        $this->assertSame(get_string('risk_heading', 'local_learninganalytics'), $serie['title']);
        $this->assertSame(['Uno', 'Tres'], $serie['labels']);
        $this->assertSame([1.0, 3.5], $serie['values']);
    }
}
