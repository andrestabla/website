<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Plugin version and metadata.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_learninganalytics';
$plugin->version   = 2026090303;
$plugin->requires  = 2024100700;   // Moodle 4.5 LTS.
// Verificado con instalacion real en:
//   - Moodle 4.5.13 + MariaDB 11.1  (entorno de produccion)
//   - Moodle 4.5.13 + PostgreSQL 13 (22 consultas, con datos)
//   - Moodle 5.2.2  + PostgreSQL 16 (17 consultas, con datos)
// Las ramas 5.0 y 5.1 no se probaron, pero comparten el nucleo de 5.2.
$plugin->supported = [405, 502];
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '3.20.1';

// mod_customcert NO se declara como dependencia dura: el dashboard debe
// instalarse igual y ocultar la pestaña de certificados si el plugin falta.
// Ver report_query::certificates_available().
