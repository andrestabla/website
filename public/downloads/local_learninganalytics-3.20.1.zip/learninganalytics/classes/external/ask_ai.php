<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_learninganalytics\local\course_report;
use local_learninganalytics\local\licence;
use local_learninganalytics\local\report_query;
use local_learninganalytics\local\scope;

/**
 * Traslada una pregunta en lenguaje natural sobre las cifras del tablero.
 *
 * La consulta no se resuelve aqui: viaja a Algoritmo T, que pone el proveedor
 * de IA. Esta clase existe para tres cosas que no pueden hacerse desde el
 * navegador: comprobar la capacidad en el contexto pedido, mantener el codigo
 * de licencia del lado del servidor, y no dejar que salga de la plataforma
 * nada que identifique a una persona.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class ask_ai extends external_api {

    /** Techos alineados con los del servidor remoto: fallar aqui es mas barato. */
    const MAX_SERIES = 12;
    const MAX_POINTS = 60;

    /**
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'question'  => new external_value(PARAM_TEXT, 'Pregunta en lenguaje natural'),
            'contextid' => new external_value(PARAM_INT, 'Contexto del ambito; 0 = plataforma', VALUE_DEFAULT, 0),
            'mode'      => new external_value(PARAM_ALPHA, 'answer o report', VALUE_DEFAULT, 'answer'),
            'categoryid' => new external_value(PARAM_INT, 'Categoria filtrada en el panel; 0 = ninguna', VALUE_DEFAULT, 0),
            'courseid'   => new external_value(PARAM_INT, 'Curso filtrado; 0 = todos', VALUE_DEFAULT, 0),
            'country'    => new external_value(PARAM_ALPHA, 'Pais filtrado', VALUE_DEFAULT, ''),
            'domain'     => new external_value(PARAM_HOST, 'Dominio filtrado', VALUE_DEFAULT, ''),
            'estado'     => new external_value(PARAM_TEXT, 'Estado filtrado', VALUE_DEFAULT, ''),
            'supervisor' => new external_value(PARAM_TEXT, 'Supervisor filtrado', VALUE_DEFAULT, ''),
            'startdate'  => new external_value(PARAM_INT, 'Desde', VALUE_DEFAULT, 0),
            'enddate'    => new external_value(PARAM_INT, 'Hasta', VALUE_DEFAULT, 0),
            'roleid'     => new external_value(PARAM_INT, 'Rol filtrado', VALUE_DEFAULT, 0),
            // El panel de filtros es uno solo desde la 3.20: lo que acota el
            // tablero tiene que acotar tambien lo que lee la IA, o la
            // respuesta describe un conjunto distinto del que se ve.
            'status'     => new external_value(PARAM_ALPHA, 'Actividad: active | low | none', VALUE_DEFAULT, ''),
            'lastaccess' => new external_value(PARAM_ALPHANUM, 'Ultimo acceso en el curso', VALUE_DEFAULT, ''),
            'progressmin' => new external_value(PARAM_INT, 'Progreso minimo', VALUE_DEFAULT, 0),
            'progressmax' => new external_value(PARAM_INT, 'Progreso maximo', VALUE_DEFAULT, 100),
            'grademin'   => new external_value(PARAM_INT, 'Calificacion minima', VALUE_DEFAULT, 0),
            'grademax'   => new external_value(PARAM_INT, 'Calificacion maxima', VALUE_DEFAULT, 100),
            'uicontext' => new external_value(PARAM_TEXT, 'Filtros y ambito visibles en pantalla', VALUE_DEFAULT, ''),
            'kpis' => new external_multiple_structure(new external_single_structure([
                'label' => new external_value(PARAM_TEXT, 'Nombre del indicador'),
                'value' => new external_value(PARAM_TEXT, 'Valor mostrado'),
            ]), 'Indicadores en pantalla', VALUE_DEFAULT, []),
            'series' => new external_multiple_structure(new external_single_structure([
                'title'  => new external_value(PARAM_TEXT, 'Titulo del bloque'),
                'labels' => new external_multiple_structure(new external_value(PARAM_TEXT, 'Etiqueta')),
                'values' => new external_multiple_structure(new external_value(PARAM_FLOAT, 'Valor')),
            ]), 'Series ya agregadas que se ven en pantalla', VALUE_DEFAULT, []),
        ]);
    }

    /**
     * @param string $question
     * @param int $contextid
     * @param array $kpis
     * @param array $series
     * @return array
     */
    public static function execute(string $question, int $contextid = 0,
            string $mode = 'answer', int $categoryid = 0, int $courseid = 0,
            string $country = '', string $domain = '', string $estado = '',
            string $supervisor = '', int $startdate = 0, int $enddate = 0,
            int $roleid = 0, string $status = '', string $lastaccess = '',
            int $progressmin = 0, int $progressmax = 100,
            int $grademin = 0, int $grademax = 100, string $uicontext = '',
            array $kpis = [], array $series = []): array {

        $params = self::validate_parameters(self::execute_parameters(), [
            'question'  => $question,
            'contextid' => $contextid,
            'mode'      => $mode,
            'categoryid' => $categoryid,
            'courseid'  => $courseid,
            'country'   => $country,
            'domain'    => $domain,
            'estado'    => $estado,
            'supervisor' => $supervisor,
            'startdate' => $startdate,
            'enddate'   => $enddate,
            'roleid'    => $roleid,
            'status'    => $status,
            'lastaccess' => $lastaccess,
            'progressmin' => $progressmin,
            'progressmax' => $progressmax,
            'grademin'  => $grademin,
            'grademax'  => $grademax,
            'uicontext' => $uicontext,
            'kpis'      => $kpis,
            'series'    => $series,
        ]);

        // Misma regla que en el resto del plugin: la capacidad se comprueba
        // contra el contexto pedido, no contra el del sitio.
        $scope = scope::from_contextid($params['contextid']);
        $context = $scope->get_context();
        self::validate_context($context);
        require_capability('local/learninganalytics:view', $context);

        $ai = licence::ai_status();
        if (!$ai->enabled) {
            return self::fail(get_string('ai_notincluded', 'local_learninganalytics'));
        }

        $status = licence::get_status();

        // Las series se calculan aqui contra la base de datos, con los filtros
        // vigentes del tablero: la IA lee el estado real del recorte pedido y
        // no depende de lo que el navegador llegara a pintar. Lo enviado por
        // el navegador queda como complemento (las graficas de curso) y como
        // respaldo si el calculo fallara.
        $filters = [
            'courseid'   => $params['courseid'],
            'country'    => $params['country'],
            'domain'     => $params['domain'],
            'estado'     => $params['estado'],
            'supervisor' => $params['supervisor'],
            'startdate'  => $params['startdate'],
            'enddate'    => $params['enddate'],
            'roleid'     => $params['roleid'],
            'status'     => $params['status'],
            'categoryid' => $params['categoryid'],
            'contextid'  => (int)$context->id,
            // Nunca por persona: la IA trabaja solo con agregados.
            'userid'     => 0,
            'search'     => '',
        ];

        $serverkpis = [];
        $serverseries = [];
        try {
            [$serverkpis, $serverseries] = self::report_series($filters, $scope);
        } catch (\Throwable $e) {
            debugging('Learning Analytics: fallo el calculo de series para IA: ' . $e->getMessage());
        }

        // En un curso, el informe del curso es lo que describe el recorte que
        // se esta mirando: permanencia, evaluacion y foros. Sin esto la IA
        // respondia con las cifras generales de la plataforma recortadas al
        // curso, que no es lo mismo.
        $coursekpis = [];
        $courseseries = [];
        if ($scope->get_level() === scope::LEVEL_COURSE) {
            try {
                [$coursekpis, $courseseries] = self::course_series($scope, $params);
            } catch (\Throwable $e) {
                debugging('Learning Analytics: fallo el informe de curso para IA: ' . $e->getMessage());
            }
        }

        $known = [];
        foreach (array_merge($serverseries, $courseseries) as $sr) {
            $known[$sr['title']] = true;
        }
        // Del navegador solo entra lo que el servidor no calculo (por ejemplo
        // las graficas del panel de curso), identificado por su titulo.
        $browser = [];
        foreach (self::clean_series($params['series']) as $sr) {
            if (empty($known[$sr['title']])) {
                $browser[] = $sr;
            }
        }

        if (!empty($serverkpis) || !empty($coursekpis)) {
            // En un curso las cifras del curso van primero: el tope de doce
            // recorta por el final y son las que responden la pregunta.
            $params['kpis'] = array_merge($coursekpis, $serverkpis);
        }

        if (empty($serverseries) && empty($courseseries) && empty($browser)) {
            return self::fail(get_string('ai_nodata', 'local_learninganalytics'));
        }

        // Las series del navegador son las graficas genericas del tablero. Al
        // mirar una categoria o un curso, eso no alcanza: la respuesta salia
        // igual de generica que los datos. Aqui se anade el detalle por curso
        // del ambito, calculado en el servidor, que es lo que permite decir
        // "el curso X tiene 7 matriculados y nadie paso del 20 %".
        $qcourses = self::find_question_courses($params['question'], $scope);
        $qcat = self::find_question_category($params['question'], $scope);
        $qdates = self::parse_question_dates($params['question']);

        $extras = array_merge(
            // Si la pregunta nombra cursos, un listado con sus matriculas
            // permite responder "que cursos hay de X" enumerandolos.
            self::course_listing_series($qcourses),
            // Y la ficha detallada de los mas relevantes va primero: es la
            // respuesta directa y no depende de ningun filtro previo.
            self::question_course_series($params['question'], $scope),
            // La categoria nombrada en la pregunta activa el detalle por curso
            // aunque no haya filtro puesto, igual que hace el filtro.
            self::scope_detail_series($scope, $params['categoryid'] ?: (int)($qcat->id ?? 0))
        );

        // El orden importa porque el tope recorta por el final. En un curso
        // manda lo del curso; en plataforma, las series generales y despues
        // el detalle que la pregunta pidio por su nombre.
        $ordered = $scope->get_level() === scope::LEVEL_COURSE
            ? array_merge($courseseries, $browser, $serverseries, $extras)
            : array_merge($serverseries, $extras, $browser);

        $clean = array_slice($ordered, 0, self::MAX_SERIES);

        $payload = [
            'licence'  => $status->licenceid,
            'site'     => licence::site_hash(),
            'version'  => get_config('local_learninganalytics', 'version'),
            'scope'    => $scope->get_level(),
            // Solo se admiten los dos modos conocidos: cualquier otro valor
            // degrada a la respuesta corta en lugar de viajar tal cual.
            'mode'     => $params['mode'] === 'report' ? 'report' : 'answer',
            'context'  => \core_text::substr($params['uicontext'], 0, 300),
            'question' => $params['question'],
            'kpis'     => array_slice($params['kpis'], 0, 12),
            'series'   => $clean,
        ];

        global $CFG;
        // Igual que en licence: la clase curl no viene cargada por defecto en
        // una peticion de servicio web.
        require_once($CFG->libdir . '/filelib.php');

        $curl = new \curl(['ignoresecurity' => false]);
        $response = $curl->post(licence::ASK_URL, json_encode($payload), [
            'CURLOPT_HTTPHEADER'     => ['Content-Type: application/json'],
            'CURLOPT_TIMEOUT'        => 45,
            'CURLOPT_CONNECTTIMEOUT' => 10,
        ]);

        $info = $curl->get_info();
        $httpcode = (int)($info['http_code'] ?? 0);
        $data = json_decode((string)$response, true);

        if ($curl->get_errno() || !is_array($data)) {
            return self::fail(get_string('ai_unreachable', 'local_learninganalytics'));
        }

        if ($httpcode !== 200) {
            // El servidor explica en su idioma por que no; se muestra tal cual
            // en lugar de un mensaje generico que obligue a adivinar.
            return self::fail((string)($data['error'] ?? get_string('ai_failed', 'local_learninganalytics')));
        }

        // El cupo que queda llega en la respuesta: se guarda para que el
        // tablero lo muestre sin esperar a la revalidacion del dia siguiente.
        if (isset($data['remaining'])) {
            set_config('airemaining', (int)$data['remaining'], 'local_learninganalytics');
        }

        // Historico personal: cada consulta pagada queda guardada para su
        // autor. Solo tiene sentido anotar las que obtuvieron respuesta.
        global $DB, $USER;
        $DB->insert_record('local_learninganalytics_ai', (object)[
            'userid'      => $USER->id,
            'contextid'   => (int)$context->id,
            'mode'        => $params['mode'] === 'report' ? 'report' : 'answer',
            'question'    => $params['question'],
            'answer'      => (string)($data['answer'] ?? ''),
            'timecreated' => time(),
        ]);

        $suggestid = 0;
        $suggestname = '';
        $suggestcatid = 0;
        $suggestcatname = '';
        if (!empty($qcourses)) {
            $suggestid = (int)$qcourses[0]->id;
            $suggestname = \core_text::substr(format_string($qcourses[0]->fullname), 0, 80);
        }
        // Ambas propuestas viajan: el navegador prefiere el curso si es
        // aplicable y cae a la categoria si no. Suprimirla aqui dejaba sin
        // propuesta cuando el curso resultaba inaplicable en el filtro.
        if ($qcat !== null) {
            $suggestcatid = (int)$qcat->id;
            $suggestcatname = \core_text::substr(format_string($qcat->name), 0, 80);
        }

        $links = [];
        foreach (array_slice($qcourses, 0, 6) as $c) {
            $links[] = [
                'id'   => (int)$c->id,
                'name' => \core_text::substr(format_string($c->fullname), 0, 80),
                'url'  => (new \moodle_url('/course/view.php', ['id' => $c->id]))->out(false),
            ];
        }

        return [
            'ok'        => true,
            'answer'    => (string)($data['answer'] ?? ''),
            'remaining' => (int)($data['remaining'] ?? 0),
            'courses'   => $links,
            'suggestcourseid' => $suggestid,
            'suggestname'     => $suggestname,
            'suggestcategoryid'   => $suggestcatid,
            'suggestcategoryname' => $suggestcatname,
            'suggeststart'    => $qdates !== null ? (int)$qdates[0] : 0,
            'suggestend'      => $qdates !== null ? (int)$qdates[1] : 0,
            'suggestdatelabel' => $qdates !== null ? $qdates[2] : '',
            'error'     => '',
        ];
    }

    /**
     * Ejecuta el informe con los filtros dados y lo convierte en series e
     * indicadores para la IA. Del resultado solo se toman los agregados: el
     * padron de personas queda fuera a proposito.
     *
     * @param array $filters
     * @param scope $scope
     * @return array [kpis, series]
     */
    protected static function report_series(array $filters, scope $scope): array {
        $data = (new report_query($filters, $scope))->run();

        $kpis = [
            ['label' => get_string('kpi_users', 'local_learninganalytics'),
             'value' => (string)$data['kpis']['users']],
            ['label' => get_string('kpi_enrolments', 'local_learninganalytics'),
             'value' => (string)$data['kpis']['enrolments']],
            ['label' => get_string('kpi_certificates', 'local_learninganalytics'),
             'value' => (string)$data['kpis']['certificates']],
            ['label' => get_string('kpi_certrate', 'local_learninganalytics'),
             'value' => $data['kpis']['certrate'] . '%'],
        ];

        $series = [];
        $add = function(string $stringkey, $block) use (&$series) {
            if (!empty($block['labels'])) {
                $series[] = [
                    'title'  => get_string($stringkey, 'local_learninganalytics'),
                    'labels' => array_map('strval', $block['labels']),
                    'values' => array_map('floatval', $block['values']),
                ];
            }
        };
        $add('chart_growth', $data['growth']);
        $add('chart_domains', $data['domains']);
        $add('chart_countries', $data['countries']);
        $add('chart_activity', $data['activity']);
        $add('chart_topcourses', $data['topcourses']);
        $add('chart_certificates', $data['certificates']);
        $add('chart_certsplit', $data['certsplit']);

        // Permanencia y riesgo: es el bloque que responde "a quien hay que
        // escribir hoy", asi que tiene que llegar a la IA como cifras, no
        // solo como la grafica de personas activas por ventana.
        // En un curso lo aporta course_series con mas detalle y sobre los
        // estudiantes del curso: enviarlo dos veces daria a la IA dos cifras
        // distintas bajo el mismo titulo.
        $risk = $scope->get_level() === scope::LEVEL_COURSE ? [] : ($data['risk'] ?? []);
        if (!empty($risk['available'])) {
            $kpis[] = ['label' => get_string('kpi_active', 'local_learninganalytics') . ' (%)',
                       'value' => $risk['activerate'] . '%'];
            $kpis[] = ['label' => get_string('kpi_none', 'local_learninganalytics'),
                       'value' => (string)$risk['none']];

            $figures = self::figures('risk_heading', self::risk_pairs($risk, false));
            if ($figures !== null) {
                $series[] = $figures;
            }
            $add('chart_riskseries', $risk['series']);
        }

        return [$kpis, $series];
    }

    /**
     * Cifras del bloque de permanencia y riesgo, con su unidad en la etiqueta.
     *
     * Un modelo no puede adivinar si un 23 son personas o un porcentaje: cada
     * etiqueta lo dice. Las cifras cuyo denominador es cero se omiten en vez
     * de viajar como un cero que se leeria como un mal resultado.
     *
     * @param array $risk
     * @param bool $iscourse
     * @return array
     */
    protected static function risk_pairs(array $risk, bool $iscourse): array {
        $s = fn($key) => get_string($key, 'local_learninganalytics');

        $pairs = [
            $s($iscourse ? 'kpi_students' : 'kpi_users') => $risk['total'],
            $s('kpi_active') . ' (%)'   => $risk['activerate'],
            $s('kpi_low')               => $risk['low'],
            $s('kpi_none')              => $risk['none'],
            $s('kpi_regular') . ' (%)'  => $risk['regularrate'],
            $s('kpi_avgdays')           => $risk['avgdays'],
        ];

        if (!empty($risk['earlytotal'])) {
            $pairs[$s('kpi_early') . ' (%)'] = $risk['earlyrate'];
        }
        if (!empty($risk['reacttotal'])) {
            $pairs[$s('kpi_react') . ' (%)'] = $risk['reactrate'];
        }
        if ($iscourse && !empty($risk['overduedue'])) {
            $pairs[$s('kpi_overdue') . ' (%)'] = $risk['overduerate'];
        }
        if ($iscourse) {
            $pairs[$s('kpi_earlyexit') . ' (%)'] = $risk['earlyexitrate'];
        }

        return $pairs;
    }

    /**
     * Convierte un conjunto de cifras con nombre en una serie para la IA.
     *
     * @param string $titlekey
     * @param array $pairs etiqueta => valor
     * @return array|null
     */
    protected static function figures(string $titlekey, array $pairs): ?array {
        $labels = [];
        $values = [];

        foreach ($pairs as $label => $value) {
            if ($value === null) {
                continue;
            }
            $labels[] = (string)$label;
            $values[] = (float)$value;
        }

        if (empty($labels)) {
            return null;
        }

        return [
            'title'  => get_string($titlekey, 'local_learninganalytics'),
            'labels' => $labels,
            'values' => $values,
        ];
    }

    /**
     * Informe del curso convertido en cifras y series para la IA.
     *
     * Se ejecuta con el mismo recorte que muestra el panel, incluidos los
     * filtros propios del curso, para que la respuesta describa exactamente
     * lo que la persona tiene delante. El padron de estudiantes no entra: de
     * aqui solo salen agregados.
     *
     * Las cifras de facilitacion docente solo aparecen si quien pregunta
     * tiene la capacidad; de eso se encarga forum_query, que las vacia antes
     * de devolverlas.
     *
     * @param scope $scope
     * @param array $params
     * @return array [kpis, series]
     */
    protected static function course_series(scope $scope, array $params): array {
        $data = (new course_report($scope->get_instanceid(), [
            'userid'      => 0,
            'roleid'      => $params['roleid'],
            'status'      => $params['status'],
            'lastaccess'  => $params['lastaccess'],
            'progressmin' => $params['progressmin'],
            'progressmax' => $params['progressmax'],
            'grademin'    => $params['grademin'],
            'grademax'    => $params['grademax'],
        ]))->run();

        $s = fn($key) => get_string($key, 'local_learninganalytics');
        $k = $data['kpis'];

        $kpis = [
            ['label' => $s('kpi_students'), 'value' => (string)$k['students']],
            ['label' => $s('kpi_avgprogress'), 'value' => $k['avgprogress'] . '%'],
        ];
        if ($k['gradedcount'] > 0) {
            $kpis[] = ['label' => $s('kpi_avggrade'), 'value' => $k['avggrade'] . '%'];
        }
        if ($k['avgtime'] > 0) {
            $kpis[] = ['label' => $s('kpi_avgtime'), 'value' => $k['avgtimeformatted']];
        }

        $series = [];
        $push = function(?array $figures) use (&$series) {
            if ($figures !== null) {
                $series[] = $figures;
            }
        };

        $risk = $data['risk'] ?? [];
        if (!empty($risk['available'])) {
            $push(self::figures('risk_heading', self::risk_pairs($risk, true)));
        }

        $ev = $data['evaluation'] ?? [];
        if (!empty($ev['available'])) {
            $pairs = [];
            if ($ev['ontimeexpected'] > 0) {
                $pairs[$s('kpi_ontime') . ' (%)'] = $ev['ontimerate'];
            }
            if ($ev['quizexpected'] > 0) {
                $pairs[$s('kpi_quizdone') . ' (%)'] = $ev['quizrate'];
            }
            if (!empty($ev['hasmastery'])) {
                $pairs[$s('kpi_mastery') . ' (%)'] = $ev['masteryrate'];
            }
            if ($ev['graded'] > 0) {
                $pairs[$s('kpi_feedback') . ' (%)'] = $ev['feedbackrate'];
                $pairs[get_string('kpi_feedbackintime', 'local_learninganalytics',
                    $ev['feedbackdays']) . ' (%)'] = $ev['feedbackintimerate'];
            }
            if ($ev['resubmittable'] > 0) {
                $pairs[$s('kpi_resubmit') . ' (%)'] = $ev['resubmitrate'];
            }
            if ($ev['itemsdue'] > 0) {
                $pairs[$s('kpi_gradebook') . ' (%)'] = $ev['uptodaterate'];
            }
            if (!empty($ev['hasgain'])) {
                $pairs[$s('kpi_gain') . ' (pp)'] = $ev['gain'];
            }
            $push(self::figures('eval_heading', $pairs));
        }

        $fr = $data['forums'] ?? [];
        if (!empty($fr['available'])) {
            $pairs = [
                $s('kpi_participation') . ' (%)' => $fr['participationrate'],
                $s('col_discussions')            => $fr['discussions'],
            ];
            if ($fr['participants'] > 0) {
                $pairs[$s('kpi_peerreply') . ' (%)'] = $fr['peerreplierrate'];
                $pairs[$s('kpi_interaction')] = $fr['interaction'];
            }
            if ($fr['discussions'] > 0) {
                $pairs[$s('kpi_unanswered') . ' (%)'] = $fr['unansweredrate'];
            }
            $push(self::figures('forum_heading', $pairs));

            if (!empty($fr['canviewteaching'])) {
                $teaching = [
                    $s('kpi_teacherwindows') . ' (%)' => $fr['teacherwindowrate'],
                    $s('kpi_announcements') . ' (%)'  => $fr['announcementrate'],
                ];
                if ($fr['responsemedian'] !== null) {
                    $teaching[$s('kpi_responsetime') . ' (h)'] = $fr['responsemedian'];
                }
                if ($fr['activeforums'] > 0) {
                    $teaching[$s('kpi_facilitated') . ' (%)'] = $fr['facilitatedrate'];
                }
                $push(self::figures('forum_teaching', $teaching));
            }
        }

        return [$kpis, $series];
    }

    /**
     * Listado de los cursos que coinciden con la pregunta, con su matricula.
     * Es lo que permite ENUMERAR ("que cursos hay de H5P") sin gastar una
     * ficha completa por cada uno.
     *
     * @param array $qcourses
     * @return array
     */
    protected static function course_listing_series(array $qcourses): array {
        global $DB;

        if (count($qcourses) < 2) {
            // Con un solo curso la ficha detallada ya lo cubre.
            return [];
        }

        $ids = array_map(function($c) {
            return (int)$c->id;
        }, $qcourses);
        [$insql, $params] = $DB->get_in_or_equal($ids, SQL_PARAMS_NAMED, 'cl');
        $enrolled = $DB->get_records_sql_menu(
            "SELECT e.courseid, COUNT(DISTINCT ue.userid)
               FROM {user_enrolments} ue
               JOIN {enrol} e ON e.id = ue.enrolid
               JOIN {user} u ON u.id = ue.userid AND u.deleted = 0 AND u.confirmed = 1
              WHERE e.courseid {$insql}
           GROUP BY e.courseid", $params);

        $labels = [];
        $values = [];
        foreach ($qcourses as $c) {
            $labels[] = \core_text::substr(format_string($c->fullname), 0, 60);
            $values[] = (float)($enrolled[$c->id] ?? 0);
        }

        return [[
            'title'  => 'Cursos que coinciden con la pregunta (matriculados en cada uno)',
            'labels' => $labels,
            'values' => $values,
        ]];
    }

    /**
     * Normaliza texto para comparar: minusculas y sin tildes.
     *
     * @param string $text
     * @return string
     */
    protected static function fold(string $text): string {
        return strtr(\core_text::strtolower($text), [
            'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u',
            'ä' => 'a', 'ë' => 'e', 'ï' => 'i', 'ö' => 'o', 'ü' => 'u',
            'ñ' => 'n',
        ]);
    }

    /**
     * Palabras utiles de una pregunta ya normalizada: fuera conectores,
     * verbos de cortesia y meses (los meses son fechas, no nombres).
     *
     * @param string $q Pregunta pasada por fold().
     * @return array
     */
    protected static function question_tokens(string $q): array {
        $stop = ['que', 'cual', 'cuales', 'como', 'donde', 'hay', 'los', 'las', 'del', 'con',
            'por', 'para', 'sobre', 'una', 'unos', 'unas', 'este', 'esta', 'estos', 'estas',
            'curso', 'cursos', 'categoria', 'categorias', 'informe', 'reporte', 'dame', 'dime',
            'muestrame', 'necesito', 'quiero', 'analiza', 'analisis', 'plataforma', 'the',
            'and', 'course', 'courses', 'what', 'report', 'fue', 'van', 'les', 'nos',
            'tiene', 'tienen', 'hizo', 'ver', 'dar',
            'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto',
            'septiembre', 'setiembre', 'octubre', 'noviembre', 'diciembre', 'ultimos', 'dias'];
        $tokens = [];
        foreach (preg_split('/[^a-z0-9]+/', $q) as $t) {
            if (\core_text::strlen($t) >= 3 && !in_array($t, $stop, true)) {
                $tokens[] = $t;
            }
        }
        return $tokens;
    }

    /**
     * Puntua cuanto encaja un nombre con la pregunta.
     *
     * Palabra completa: 2 puntos. Subcadena: 1 punto y solo para terminos de
     * cinco letras o mas ("fue" dentro de "esfuerzos" no puntua; "gastronom"
     * dentro de "gastronomia" si).
     *
     * @param string $name Nombre ya normalizado con fold().
     * @param string $q Pregunta ya normalizada.
     * @param array $tokens Palabras utiles de la pregunta.
     * @return int
     */
    protected static function score_name(string $name, string $q, array $tokens): int {
        if ($name === '') {
            return 0;
        }
        $score = 0;
        if (strpos($q, $name) !== false) {
            $score += 10;
        }
        $namewords = preg_split('/[^a-z0-9]+/', $name);
        foreach ($tokens as $t) {
            if (in_array($t, $namewords, true)) {
                $score += 2;
            } else if (\core_text::strlen($t) >= 5 && strpos($name, $t) !== false) {
                $score += 1;
            }
        }
        return $score;
    }

    /**
     * Categoria que la pregunta parece mencionar, si el ambito permite
     * moverse por categorias.
     *
     * @param string $question
     * @param scope $scope
     * @return \stdClass|null
     */
    protected static function find_question_category(string $question, scope $scope): ?\stdClass {
        global $DB;

        if ($scope->get_level() === scope::LEVEL_COURSE) {
            return null;
        }

        $q = self::fold($question);
        $tokens = self::question_tokens($q);
        // Sin filtrar por visible: las categorias ocultas aparecen igualmente
        // en la cascada de quien tiene permiso de ver este tablero, y la
        // propuesta solo aplica un filtro que ese panel ya ofrece.
        $cats = $DB->get_records('course_categories', [], '', 'id, name, parent');

        $best = null;
        $bestscore = 0;
        foreach ($cats as $c) {
            $score = self::score_name(self::fold(format_string($c->name)), $q, $tokens);
            if ($score > $bestscore) {
                $bestscore = $score;
                $best = $c;
            }
        }

        return $bestscore > 0 ? $best : null;
    }

    /**
     * Rango de fechas que la pregunta menciona: un mes ("octubre", "octubre
     * de 2025"), un ano ("2025") o "ultimos N dias". Deteccion literal, sin
     * modelo: una fecha inventada seria peor que ninguna.
     *
     * @param string $question
     * @return array|null [inicio, fin, etiqueta]
     */
    protected static function parse_question_dates(string $question): ?array {
        $q = self::fold($question);

        if (preg_match('/ultim[oa]s?\s+(\d{1,3})\s+dias/', $q, $m)) {
            $n = min(365, max(1, (int)$m[1]));
            return [time() - $n * DAYSECS, time(), 'últimos ' . $n . ' días'];
        }

        $months = ['enero' => 1, 'febrero' => 2, 'marzo' => 3, 'abril' => 4, 'mayo' => 5,
            'junio' => 6, 'julio' => 7, 'agosto' => 8, 'septiembre' => 9, 'setiembre' => 9,
            'octubre' => 10, 'noviembre' => 11, 'diciembre' => 12];
        foreach ($months as $name => $num) {
            if (preg_match('/\b' . $name . '\b(?:\s+(?:de\s+)?(20\d{2}))?/', $q, $m)) {
                $year = !empty($m[1]) ? (int)$m[1] : (int)date('Y');
                // "octubre" a secas en agosto se refiere al octubre pasado.
                if (empty($m[1]) && $num > (int)date('n')) {
                    $year--;
                }
                return [
                    make_timestamp($year, $num, 1),
                    make_timestamp($year, $num + 1, 1) - 1,
                    $name . ' ' . $year,
                ];
            }
        }

        if (preg_match('/\b(20\d{2})\b/', $q, $m)) {
            $y = (int)$m[1];
            return [make_timestamp($y, 1, 1), make_timestamp($y + 1, 1, 1) - 1, (string)$y];
        }

        return null;
    }

    /**
     * Cursos del ambito que la pregunta parece mencionar, por relevancia.
     *
     * No exige el nombre exacto: la pregunta se trocea en palabras y se
     * puntua cada curso por cuantas aparecen en su nombre. "que cursos hay de
     * H5P" encuentra todo curso con H5P en el titulo. Es busqueda lexica
     * tolerante, no semantica: "contenido interactivo" no encontrara H5P si
     * la palabra no esta en el nombre.
     *
     * @param string $question
     * @param scope $scope
     * @return array Registros de curso con ->score, de mayor a menor.
     */
    protected static function find_question_courses(string $question, scope $scope): array {
        global $DB;

        $q = self::fold($question);
        if (\core_text::strlen(trim($q)) < 3) {
            return [];
        }

        $tokens = self::question_tokens($q);

        // Universo consultable: los cursos del ambito. La capacidad sobre el
        // contexto ya se comprobo; un profesor de curso solo alcanza el suyo.
        $scopeids = $scope->get_course_ids();
        $where = 'id <> ' . SITEID;
        $params = [];
        if ($scopeids !== null) {
            if (empty($scopeids)) {
                return [];
            }
            [$insql, $params] = $DB->get_in_or_equal($scopeids, SQL_PARAMS_NAMED, 'qc');
            $where .= " AND id {$insql}";
        }
        $courses = $DB->get_records_select('course', $where, $params, '', 'id, fullname, shortname');

        $matches = [];
        foreach ($courses as $c) {
            $fullname = self::fold(format_string($c->fullname));
            $shortname = self::fold($c->shortname);
            $score = self::score_name($fullname, $q, $tokens);
            if (\core_text::strlen($shortname) >= 4 && strpos($q, $shortname) !== false) {
                $score += 8;
            }
            if ($score > 0) {
                $c->score = $score;
                $matches[] = $c;
            }
        }

        usort($matches, function($a, $b) {
            return $b->score <=> $a->score;
        });

        return array_slice($matches, 0, 10);
    }

    /**
     * Fichas de los cursos que la pregunta menciona por su nombre.
     *
     * Pedir "informe del curso X" sin haber filtrado el tablero devolvia
     * cifras globales: el modelo no tenia nada de X. Aqui se buscan los
     * nombres de curso dentro de la pregunta y se adjunta una ficha agregada
     * de cada coincidencia, siempre dentro de lo que el ambito permite ver.
     *
     * @param string $question
     * @param scope $scope
     * @return array
     */
    protected static function question_course_series(string $question, scope $scope): array {
        global $DB;

        $matches = array_slice(self::find_question_courses($question, $scope), 0, 3);

        $out = [];
        $now = time();
        foreach ($matches as $c) {
            $cid = ['cid' => $c->id];

            $enrolled = (int)$DB->count_records_sql(
                "SELECT COUNT(DISTINCT ue.userid)
                   FROM {user_enrolments} ue
                   JOIN {enrol} e ON e.id = ue.enrolid
                   JOIN {user} u ON u.id = ue.userid AND u.deleted = 0 AND u.confirmed = 1
                  WHERE e.courseid = :cid", $cid);

            // Ultimo acceso AL CURSO, por tramos disjuntos.
            $d7  = (int)$DB->count_records_select('user_lastaccess',
                'courseid = :cid AND timeaccess >= :t', ['cid' => $c->id, 't' => $now - 7 * DAYSECS]);
            $d30 = (int)$DB->count_records_select('user_lastaccess',
                'courseid = :cid AND timeaccess >= :t AND timeaccess < :t2',
                ['cid' => $c->id, 't' => $now - 30 * DAYSECS, 't2' => $now - 7 * DAYSECS]);
            $d90 = (int)$DB->count_records_select('user_lastaccess',
                'courseid = :cid AND timeaccess >= :t AND timeaccess < :t2',
                ['cid' => $c->id, 't' => $now - 90 * DAYSECS, 't2' => $now - 30 * DAYSECS]);
            $mas = (int)$DB->count_records_select('user_lastaccess',
                'courseid = :cid AND timeaccess < :t', ['cid' => $c->id, 't' => $now - 90 * DAYSECS]);
            $nunca = max(0, $enrolled - ($d7 + $d30 + $d90 + $mas));

            $tracked = (int)$DB->count_records_select('course_modules',
                'course = :cid AND completion > 0', $cid);
            $completed = (int)$DB->count_records_sql(
                "SELECT COUNT(*)
                   FROM {course_modules_completion} cmc
                   JOIN {course_modules} cm ON cm.id = cmc.coursemoduleid
                  WHERE cmc.completionstate > 0 AND cm.course = :cid
                    AND EXISTS (SELECT 1 FROM {user_enrolments} ue
                                  JOIN {enrol} e ON e.id = ue.enrolid
                                 WHERE ue.userid = cmc.userid AND e.courseid = cm.course)", $cid);
            $slots = $tracked * $enrolled;
            $avance = $slots > 0 ? min(100.0, round($completed / $slots * 100, 1)) : 0.0;

            $certs = 0;
            if (report_query::certificates_available()) {
                $certs = (int)$DB->count_records_sql(
                    "SELECT COUNT(ci.id)
                       FROM {customcert_issues} ci
                       JOIN {customcert} cc ON cc.id = ci.customcertid
                      WHERE cc.course = :cid", $cid);
            }

            $name = \core_text::substr(format_string($c->fullname), 0, 60);
            $out[] = [
                'title'  => 'Ficha del curso "' . $name . '" (consultado en la pregunta)',
                'labels' => [
                    'Matriculados en el curso',
                    'Accedieron al curso en los ultimos 7 dias',
                    'Accedieron entre 8 y 30 dias atras',
                    'Accedieron entre 31 y 90 dias atras',
                    'Sin acceso al curso en mas de 90 dias',
                    'Nunca han entrado al curso',
                    'Actividades con seguimiento de finalizacion',
                    'Avance medio del curso en %',
                    'Certificados emitidos en el curso',
                ],
                'values' => [
                    (float)$enrolled, (float)$d7, (float)$d30, (float)$d90,
                    (float)$mas, (float)$nunca, (float)$tracked, $avance, (float)$certs,
                ],
            ];
        }

        return $out;
    }

    /** Cursos como maximo en el detalle por ambito. */
    const MAX_DETAIL_COURSES = 20;

    /**
     * Detalle agregado por curso del ambito: matriculados, avance medio y
     * certificados. Sin personas: solo totales por curso.
     *
     * Se calcula con tres consultas agregadas en total, no una por curso,
     * para que una categoria grande no convierta la pregunta en un barrido.
     *
     * @param scope $scope
     * @return array Series con la misma forma que las del navegador.
     */
    protected static function scope_detail_series(scope $scope, int $categoryid = 0): array {
        global $DB;

        // El recorte puede venir de dos sitios: el ambito (tablero de curso o
        // de categoria) o el filtro de categoria del panel. Misma regla que en
        // report_query: el filtro estrecha el ambito, nunca lo amplia.
        $courseids = $scope->get_course_ids();
        if ($categoryid > 0) {
            $incategory = scope::courses_in_category($categoryid);
            $courseids = $courseids === null
                ? $incategory
                : array_values(array_intersect($courseids, $incategory));
        }
        // A nivel de plataforma sin filtro, el detalle por curso seria enorme
        // y ya viaja el bloque de cursos con mas matriculaciones.
        if ($courseids === null || empty($courseids)) {
            return [];
        }

        $courseids = array_slice($courseids, 0, self::MAX_DETAIL_COURSES);
        [$insql, $inparams] = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED, 'sd');

        // Matriculados distintos por curso.
        $enrolled = $DB->get_records_sql(
            "SELECT c.id, c.fullname, COUNT(DISTINCT ue.userid) AS total
               FROM {course} c
               JOIN {enrol} e ON e.courseid = c.id
               JOIN {user_enrolments} ue ON ue.enrolid = e.id
               JOIN {user} u ON u.id = ue.userid AND u.deleted = 0 AND u.confirmed = 1
              WHERE c.id {$insql}
           GROUP BY c.id, c.fullname", $inparams);

        if (empty($enrolled)) {
            return [];
        }

        // Actividades con seguimiento y finalizaciones, por curso.
        $tracked = $DB->get_records_sql_menu(
            "SELECT cm.course, COUNT(*) FROM {course_modules} cm
              WHERE cm.completion > 0 AND cm.course {$insql}
           GROUP BY cm.course", $inparams);
        // Solo finalizaciones de gente actualmente matriculada: las filas de
        // quien se desmatriculo persisten en la tabla y sin este filtro el
        // porcentaje puede superar el 100 (paso en produccion: 192,9 %).
        $completed = $DB->get_records_sql_menu(
            "SELECT cm.course, COUNT(*)
               FROM {course_modules_completion} cmc
               JOIN {course_modules} cm ON cm.id = cmc.coursemoduleid
              WHERE cmc.completionstate > 0 AND cm.course {$insql}
                AND EXISTS (SELECT 1
                              FROM {user_enrolments} ue
                              JOIN {enrol} e ON e.id = ue.enrolid
                             WHERE ue.userid = cmc.userid AND e.courseid = cm.course)
           GROUP BY cm.course", $inparams);

        $names = [];
        $enrolvalues = [];
        $progressvalues = [];
        foreach ($enrolled as $c) {
            $name = \core_text::substr(format_string($c->fullname), 0, 60);
            $names[] = $name;
            $enrolvalues[] = (float)$c->total;
            $slots = (int)($tracked[$c->id] ?? 0) * (int)$c->total;
            // Avance medio aproximado: finalizaciones sobre huecos posibles.
            // El tope evita que cualquier resto historico invente mas del 100 %.
            $progressvalues[] = $slots > 0
                ? min(100.0, round(((int)($completed[$c->id] ?? 0)) / $slots * 100, 1))
                : 0.0;
        }

        return [
            ['title' => 'Matriculados por curso (ambito actual)',
             'labels' => $names, 'values' => $enrolvalues],
            ['title' => 'Avance medio por curso en % (finalizaciones sobre actividades con seguimiento)',
             'labels' => $names, 'values' => $progressvalues],
        ];
    }

    /**
     * Recorta las series y descarta lo que pueda identificar a una persona.
     *
     * Es la ultima frontera dentro de la plataforma: lo que pase de aqui sale
     * a internet. El servidor remoto repite la comprobacion, pero confiar solo
     * en el otro extremo seria dejar la puerta abierta.
     *
     * @param array $series
     * @return array
     */
    protected static function clean_series(array $series): array {
        $out = [];

        foreach (array_slice($series, 0, self::MAX_SERIES) as $s) {
            $title = trim((string)($s['title'] ?? ''));
            $labels = array_slice((array)($s['labels'] ?? []), 0, self::MAX_POINTS);
            $values = array_slice((array)($s['values'] ?? []), 0, self::MAX_POINTS);

            if ($title === '' || empty($labels)) {
                continue;
            }

            $clean = [];
            foreach ($labels as $label) {
                $label = (string)$label;
                // Un correo en una etiqueta solo puede significar que se colo
                // el padron: se descarta la serie entera, no solo esa fila.
                if (preg_match('/[\w.+-]+@[\w-]+\.[\w.-]+/', $label)) {
                    continue 2;
                }
                $clean[] = \core_text::substr($label, 0, 120);
            }

            $out[] = [
                'title'  => \core_text::substr($title, 0, 120),
                'labels' => $clean,
                'values' => array_map('floatval', array_values($values)),
            ];
        }

        return $out;
    }

    /**
     * @param string $message
     * @return array
     */
    protected static function fail(string $message): array {
        return ['ok' => false, 'answer' => '', 'remaining' => 0, 'courses' => [],
            'suggestcourseid' => 0, 'suggestname' => '',
            'suggestcategoryid' => 0, 'suggestcategoryname' => '',
            'suggeststart' => 0, 'suggestend' => 0, 'suggestdatelabel' => '',
            'error' => $message];
    }

    /**
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'        => new external_value(PARAM_BOOL, 'Si se obtuvo respuesta'),
            'answer'    => new external_value(PARAM_RAW, 'Respuesta en lenguaje natural'),
            'remaining' => new external_value(PARAM_INT, 'Consultas que quedan este mes'),
            'courses' => new external_multiple_structure(new external_single_structure([
                'id'   => new external_value(PARAM_INT, 'ID del curso'),
                'name' => new external_value(PARAM_TEXT, 'Nombre'),
                'url'  => new external_value(PARAM_URL, 'Acceso directo'),
            ]), 'Cursos relacionados con la pregunta', VALUE_DEFAULT, []),
            'suggestcourseid' => new external_value(PARAM_INT, 'Curso propuesto para filtrar el tablero', VALUE_DEFAULT, 0),
            'suggestname'     => new external_value(PARAM_TEXT, 'Nombre del curso propuesto', VALUE_DEFAULT, ''),
            'suggestcategoryid'   => new external_value(PARAM_INT, 'Categoria propuesta', VALUE_DEFAULT, 0),
            'suggestcategoryname' => new external_value(PARAM_TEXT, 'Nombre de la categoria propuesta', VALUE_DEFAULT, ''),
            'suggeststart'    => new external_value(PARAM_INT, 'Inicio del rango propuesto', VALUE_DEFAULT, 0),
            'suggestend'      => new external_value(PARAM_INT, 'Fin del rango propuesto', VALUE_DEFAULT, 0),
            'suggestdatelabel' => new external_value(PARAM_TEXT, 'Etiqueta del rango', VALUE_DEFAULT, ''),
            'error'     => new external_value(PARAM_TEXT, 'Motivo cuando no hubo respuesta'),
        ]);
    }
}
