<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_learninganalytics\local\licence;
use local_learninganalytics\local\scope;

/**
 * Traslada una pregunta en lenguaje natural sobre las cifras del tablero.
 *
 * La consulta no se resuelve aqui: viaja a Algoritmo T, que pone el proveedor
 * de IA. Esta clase existe para tres cosas que no pueden hacerse desde el
 * navegador: comprobar la capacidad en el contexto pedido, mantener el codigo
 * de licencia del lado del servidor, y no dejar que salga de la plataforma
 * nada que identifique a una persona.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class ask_ai extends external_api {

    /** Techos alineados con los del servidor remoto: fallar aqui es mas barato. */
    const MAX_SERIES = 12;
    const MAX_POINTS = 60;

    /**
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'question'  => new external_value(PARAM_TEXT, 'Pregunta en lenguaje natural'),
            'contextid' => new external_value(PARAM_INT, 'Contexto del ambito; 0 = plataforma', VALUE_DEFAULT, 0),
            'mode'      => new external_value(PARAM_ALPHA, 'answer o report', VALUE_DEFAULT, 'answer'),
            'categoryid' => new external_value(PARAM_INT, 'Categoria filtrada en el panel; 0 = ninguna', VALUE_DEFAULT, 0),
            'uicontext' => new external_value(PARAM_TEXT, 'Filtros y ambito visibles en pantalla', VALUE_DEFAULT, ''),
            'kpis' => new external_multiple_structure(new external_single_structure([
                'label' => new external_value(PARAM_TEXT, 'Nombre del indicador'),
                'value' => new external_value(PARAM_TEXT, 'Valor mostrado'),
            ]), 'Indicadores en pantalla', VALUE_DEFAULT, []),
            'series' => new external_multiple_structure(new external_single_structure([
                'title'  => new external_value(PARAM_TEXT, 'Titulo del bloque'),
                'labels' => new external_multiple_structure(new external_value(PARAM_TEXT, 'Etiqueta')),
                'values' => new external_multiple_structure(new external_value(PARAM_FLOAT, 'Valor')),
            ]), 'Series ya agregadas que se ven en pantalla', VALUE_DEFAULT, []),
        ]);
    }

    /**
     * @param string $question
     * @param int $contextid
     * @param array $kpis
     * @param array $series
     * @return array
     */
    public static function execute(string $question, int $contextid = 0,
            string $mode = 'answer', int $categoryid = 0, string $uicontext = '',
            array $kpis = [], array $series = []): array {

        $params = self::validate_parameters(self::execute_parameters(), [
            'question'  => $question,
            'contextid' => $contextid,
            'mode'      => $mode,
            'categoryid' => $categoryid,
            'uicontext' => $uicontext,
            'kpis'      => $kpis,
            'series'    => $series,
        ]);

        // Misma regla que en el resto del plugin: la capacidad se comprueba
        // contra el contexto pedido, no contra el del sitio.
        $scope = scope::from_contextid($params['contextid']);
        $context = $scope->get_context();
        self::validate_context($context);
        require_capability('local/learninganalytics:view', $context);

        $ai = licence::ai_status();
        if (!$ai->enabled) {
            return self::fail(get_string('ai_notincluded', 'local_learninganalytics'));
        }

        $status = licence::get_status();
        $clean = self::clean_series($params['series']);

        if (empty($clean)) {
            return self::fail(get_string('ai_nodata', 'local_learninganalytics'));
        }

        // Las series del navegador son las graficas genericas del tablero. Al
        // mirar una categoria o un curso, eso no alcanza: la respuesta salia
        // igual de generica que los datos. Aqui se anade el detalle por curso
        // del ambito, calculado en el servidor, que es lo que permite decir
        // "el curso X tiene 7 matriculados y nadie paso del 20 %".
        foreach (self::scope_detail_series($scope, $params['categoryid']) as $extra) {
            if (count($clean) >= self::MAX_SERIES) {
                break;
            }
            $clean[] = $extra;
        }

        $payload = [
            'licence'  => $status->licenceid,
            'site'     => licence::site_hash(),
            'version'  => get_config('local_learninganalytics', 'version'),
            'scope'    => $scope->get_level(),
            // Solo se admiten los dos modos conocidos: cualquier otro valor
            // degrada a la respuesta corta en lugar de viajar tal cual.
            'mode'     => $params['mode'] === 'report' ? 'report' : 'answer',
            'context'  => \core_text::substr($params['uicontext'], 0, 300),
            'question' => $params['question'],
            'kpis'     => array_slice($params['kpis'], 0, 12),
            'series'   => $clean,
        ];

        global $CFG;
        // Igual que en licence: la clase curl no viene cargada por defecto en
        // una peticion de servicio web.
        require_once($CFG->libdir . '/filelib.php');

        $curl = new \curl(['ignoresecurity' => false]);
        $response = $curl->post(licence::ASK_URL, json_encode($payload), [
            'CURLOPT_HTTPHEADER'     => ['Content-Type: application/json'],
            'CURLOPT_TIMEOUT'        => 45,
            'CURLOPT_CONNECTTIMEOUT' => 10,
        ]);

        $info = $curl->get_info();
        $httpcode = (int)($info['http_code'] ?? 0);
        $data = json_decode((string)$response, true);

        if ($curl->get_errno() || !is_array($data)) {
            return self::fail(get_string('ai_unreachable', 'local_learninganalytics'));
        }

        if ($httpcode !== 200) {
            // El servidor explica en su idioma por que no; se muestra tal cual
            // en lugar de un mensaje generico que obligue a adivinar.
            return self::fail((string)($data['error'] ?? get_string('ai_failed', 'local_learninganalytics')));
        }

        // El cupo que queda llega en la respuesta: se guarda para que el
        // tablero lo muestre sin esperar a la revalidacion del dia siguiente.
        if (isset($data['remaining'])) {
            set_config('airemaining', (int)$data['remaining'], 'local_learninganalytics');
        }

        return [
            'ok'        => true,
            'answer'    => (string)($data['answer'] ?? ''),
            'remaining' => (int)($data['remaining'] ?? 0),
            'error'     => '',
        ];
    }

    /** Cursos como maximo en el detalle por ambito. */
    const MAX_DETAIL_COURSES = 20;

    /**
     * Detalle agregado por curso del ambito: matriculados, avance medio y
     * certificados. Sin personas: solo totales por curso.
     *
     * Se calcula con tres consultas agregadas en total, no una por curso,
     * para que una categoria grande no convierta la pregunta en un barrido.
     *
     * @param scope $scope
     * @return array Series con la misma forma que las del navegador.
     */
    protected static function scope_detail_series(scope $scope, int $categoryid = 0): array {
        global $DB;

        // El recorte puede venir de dos sitios: el ambito (tablero de curso o
        // de categoria) o el filtro de categoria del panel. Misma regla que en
        // report_query: el filtro estrecha el ambito, nunca lo amplia.
        $courseids = $scope->get_course_ids();
        if ($categoryid > 0) {
            $incategory = scope::courses_in_category($categoryid);
            $courseids = $courseids === null
                ? $incategory
                : array_values(array_intersect($courseids, $incategory));
        }
        // A nivel de plataforma sin filtro, el detalle por curso seria enorme
        // y ya viaja el bloque de cursos con mas matriculaciones.
        if ($courseids === null || empty($courseids)) {
            return [];
        }

        $courseids = array_slice($courseids, 0, self::MAX_DETAIL_COURSES);
        [$insql, $inparams] = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED, 'sd');

        // Matriculados distintos por curso.
        $enrolled = $DB->get_records_sql(
            "SELECT c.id, c.fullname, COUNT(DISTINCT ue.userid) AS total
               FROM {course} c
               JOIN {enrol} e ON e.courseid = c.id
               JOIN {user_enrolments} ue ON ue.enrolid = e.id
               JOIN {user} u ON u.id = ue.userid AND u.deleted = 0
              WHERE c.id {$insql}
           GROUP BY c.id, c.fullname", $inparams);

        if (empty($enrolled)) {
            return [];
        }

        // Actividades con seguimiento y finalizaciones, por curso.
        $tracked = $DB->get_records_sql_menu(
            "SELECT cm.course, COUNT(*) FROM {course_modules} cm
              WHERE cm.completion > 0 AND cm.course {$insql}
           GROUP BY cm.course", $inparams);
        $completed = $DB->get_records_sql_menu(
            "SELECT cm.course, COUNT(*)
               FROM {course_modules_completion} cmc
               JOIN {course_modules} cm ON cm.id = cmc.coursemoduleid
              WHERE cmc.completionstate > 0 AND cm.course {$insql}
           GROUP BY cm.course", $inparams);

        $names = [];
        $enrolvalues = [];
        $progressvalues = [];
        foreach ($enrolled as $c) {
            $name = \core_text::substr(format_string($c->fullname), 0, 60);
            $names[] = $name;
            $enrolvalues[] = (float)$c->total;
            $slots = (int)($tracked[$c->id] ?? 0) * (int)$c->total;
            // Avance medio aproximado: finalizaciones sobre huecos posibles.
            $progressvalues[] = $slots > 0
                ? round(((int)($completed[$c->id] ?? 0)) / $slots * 100, 1)
                : 0.0;
        }

        return [
            ['title' => 'Matriculados por curso (ambito actual)',
             'labels' => $names, 'values' => $enrolvalues],
            ['title' => 'Avance medio por curso en % (finalizaciones sobre actividades con seguimiento)',
             'labels' => $names, 'values' => $progressvalues],
        ];
    }

    /**
     * Recorta las series y descarta lo que pueda identificar a una persona.
     *
     * Es la ultima frontera dentro de la plataforma: lo que pase de aqui sale
     * a internet. El servidor remoto repite la comprobacion, pero confiar solo
     * en el otro extremo seria dejar la puerta abierta.
     *
     * @param array $series
     * @return array
     */
    protected static function clean_series(array $series): array {
        $out = [];

        foreach (array_slice($series, 0, self::MAX_SERIES) as $s) {
            $title = trim((string)($s['title'] ?? ''));
            $labels = array_slice((array)($s['labels'] ?? []), 0, self::MAX_POINTS);
            $values = array_slice((array)($s['values'] ?? []), 0, self::MAX_POINTS);

            if ($title === '' || empty($labels)) {
                continue;
            }

            $clean = [];
            foreach ($labels as $label) {
                $label = (string)$label;
                // Un correo en una etiqueta solo puede significar que se colo
                // el padron: se descarta la serie entera, no solo esa fila.
                if (preg_match('/[\w.+-]+@[\w-]+\.[\w.-]+/', $label)) {
                    continue 2;
                }
                $clean[] = \core_text::substr($label, 0, 120);
            }

            $out[] = [
                'title'  => \core_text::substr($title, 0, 120),
                'labels' => $clean,
                'values' => array_map('floatval', array_values($values)),
            ];
        }

        return $out;
    }

    /**
     * @param string $message
     * @return array
     */
    protected static function fail(string $message): array {
        return ['ok' => false, 'answer' => '', 'remaining' => 0, 'error' => $message];
    }

    /**
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'        => new external_value(PARAM_BOOL, 'Si se obtuvo respuesta'),
            'answer'    => new external_value(PARAM_RAW, 'Respuesta en lenguaje natural'),
            'remaining' => new external_value(PARAM_INT, 'Consultas que quedan este mes'),
            'error'     => new external_value(PARAM_TEXT, 'Motivo cuando no hubo respuesta'),
        ]);
    }
}
