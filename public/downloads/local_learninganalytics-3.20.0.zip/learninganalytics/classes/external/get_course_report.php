<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_learninganalytics\local\course_report;
use local_learninganalytics\local\scope;

/**
 * Analitica de un curso: progreso, calificaciones y permanencia.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class get_course_report extends external_api {

    /**
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'contextid'   => new external_value(PARAM_INT, 'Contexto del curso'),
            'userid'      => new external_value(PARAM_INT, 'Estudiante concreto', VALUE_DEFAULT, 0),
            'lastaccess'  => new external_value(PARAM_ALPHANUM, '7 | 30 | 90 | older | never', VALUE_DEFAULT, ''),
            'progressmin' => new external_value(PARAM_INT, 'Progreso minimo', VALUE_DEFAULT, 0),
            'progressmax' => new external_value(PARAM_INT, 'Progreso maximo', VALUE_DEFAULT, 100),
            'grademin'    => new external_value(PARAM_INT, 'Calificacion minima', VALUE_DEFAULT, 0),
            'grademax'    => new external_value(PARAM_INT, 'Calificacion maxima', VALUE_DEFAULT, 100),
            'roleid'      => new external_value(PARAM_INT, 'Rol dentro del curso', VALUE_DEFAULT, 0),
            'status'      => new external_value(PARAM_ALPHA, 'Actividad: active | low | none', VALUE_DEFAULT, ''),
        ]);
    }

    /**
     * @param int $contextid
     * @param int $userid
     * @param string $lastaccess
     * @param int $progressmin
     * @param int $progressmax
     * @param int $grademin
     * @param int $grademax
     * @return array
     */
    public static function execute(int $contextid, int $userid = 0, string $lastaccess = '',
            int $progressmin = 0, int $progressmax = 100,
            int $grademin = 0, int $grademax = 100, int $roleid = 0, string $status = ''): array {

        $params = self::validate_parameters(self::execute_parameters(), [
            'contextid'   => $contextid,
            'userid'      => $userid,
            'lastaccess'  => $lastaccess,
            'progressmin' => $progressmin,
            'progressmax' => $progressmax,
            'grademin'    => $grademin,
            'grademax'    => $grademax,
            'roleid'      => $roleid,
            'status'      => $status,
        ]);

        $scope = scope::from_contextid($params['contextid']);
        $context = $scope->get_context();

        self::validate_context($context);
        require_capability('local/learninganalytics:view', $context);

        if (!\local_learninganalytics\local\licence::has_feature(
                \local_learninganalytics\local\licence::FEATURE_COURSE)) {
            throw new \moodle_exception('lic_required', 'local_learninganalytics');
        }

        // Este informe solo existe a nivel de curso.
        if ($scope->get_level() !== scope::LEVEL_COURSE) {
            throw new \moodle_exception('courseonlyreport', 'local_learninganalytics');
        }

        if (!$scope->is_enabled()) {
            throw new \moodle_exception('levelnotenabled', 'local_learninganalytics');
        }

        $report = new course_report($scope->get_instanceid(), $params);

        return $report->run();
    }

    /**
     * Estructura del bloque de evaluacion y entregas.
     *
     * @return external_single_structure
     */
    public static function evaluation_returns(): external_single_structure {
        return new external_single_structure([
            'available'      => new external_value(PARAM_BOOL, 'Hay tareas o cuestionarios'),
            'feedbackdays'   => new external_value(PARAM_INT, 'Plazo de retroalimentacion en dias'),
            'ontime'         => new external_value(PARAM_INT, 'Entregas a tiempo'),
            'ontimeexpected' => new external_value(PARAM_INT, 'Entregas esperadas con fecha vencida'),
            'ontimerate'     => new external_value(PARAM_FLOAT, 'Porcentaje a tiempo'),
            'quizdone'       => new external_value(PARAM_INT, 'Cuestionarios completados'),
            'quizexpected'   => new external_value(PARAM_INT, 'Cuestionarios esperados'),
            'quizrate'       => new external_value(PARAM_FLOAT, 'Porcentaje completado'),
            'hasmastery'     => new external_value(PARAM_BOOL, 'Hay nota de aprobado definida'),
            'mastery'        => new external_value(PARAM_INT, 'Alcanzan el aprobado'),
            'masteryof'      => new external_value(PARAM_INT, 'Evaluados'),
            'masteryrate'    => new external_value(PARAM_FLOAT, 'Porcentaje que alcanza el aprobado'),
            'feedback'       => new external_value(PARAM_INT, 'Calificadas con retroalimentacion'),
            'graded'         => new external_value(PARAM_INT, 'Entregas calificadas'),
            'feedbackrate'   => new external_value(PARAM_FLOAT, 'Porcentaje con retroalimentacion'),
            'feedbackintime' => new external_value(PARAM_INT, 'Retroalimentadas en plazo'),
            'feedbackintimerate' => new external_value(PARAM_FLOAT, 'Porcentaje en plazo'),
            'resubmitted'    => new external_value(PARAM_INT, 'Reentregas'),
            'resubmittable'  => new external_value(PARAM_INT, 'Entregas con reenvio posible'),
            'resubmitrate'   => new external_value(PARAM_FLOAT, 'Porcentaje de reentregas'),
            'itemsuptodate'  => new external_value(PARAM_INT, 'Actividades vencidas al dia'),
            'itemsdue'       => new external_value(PARAM_INT, 'Actividades vencidas'),
            'uptodaterate'   => new external_value(PARAM_FLOAT, 'Porcentaje al dia'),
            'hasgain'        => new external_value(PARAM_BOOL, 'Hay estudiantes con dos o mas intentos'),
            'gain'           => new external_value(PARAM_FLOAT, 'Ganancia media entre intentos, en puntos'),
            'gainstudents'   => new external_value(PARAM_INT, 'Estudiantes con dos o mas intentos'),
            'items' => new external_multiple_structure(new external_single_structure([
                'cmid'           => new external_value(PARAM_INT, 'ID del modulo'),
                'name'           => new external_value(PARAM_TEXT, 'Actividad'),
                'type'           => new external_value(PARAM_ALPHA, 'assign | quiz'),
                'deadlinets'     => new external_value(PARAM_INT, 'Fecha limite'),
                'deadline'       => new external_value(PARAM_TEXT, 'Fecha limite legible'),
                'expected'       => new external_value(PARAM_INT, 'Esperadas'),
                'delivered'      => new external_value(PARAM_INT, 'Entregadas o intentadas'),
                'deliveredrate'  => new external_value(PARAM_FLOAT, 'Porcentaje entregado'),
                'ontime'         => new external_value(PARAM_INT, 'A tiempo'),
                'ontimerate'     => new external_value(PARAM_FLOAT, 'Porcentaje a tiempo'),
                'graded'         => new external_value(PARAM_INT, 'Calificadas'),
                'feedback'       => new external_value(PARAM_INT, 'Con retroalimentacion'),
                'feedbackrate'   => new external_value(PARAM_FLOAT, 'Porcentaje con retroalimentacion'),
                'feedbackintime' => new external_value(PARAM_INT, 'Retroalimentadas en plazo'),
                'feedbackintimerate' => new external_value(PARAM_FLOAT, 'Porcentaje en plazo'),
                'resubmitted'    => new external_value(PARAM_INT, 'Reentregas'),
                'resubmittable'  => new external_value(PARAM_INT, 'Con reenvio posible'),
                'gain'           => new external_value(PARAM_FLOAT, 'Ganancia media', VALUE_OPTIONAL, null, NULL_ALLOWED),
                'gainstudents'   => new external_value(PARAM_INT, 'Estudiantes con dos o mas intentos'),
                'pendinggrading' => new external_value(PARAM_INT, 'Entregas sin calificar'),
                'uptodate'       => new external_value(PARAM_BOOL, 'Sin calificaciones pendientes'),
                'gradepass'      => new external_value(PARAM_FLOAT, 'Nota de aprobado (%)', VALUE_OPTIONAL, null, NULL_ALLOWED),
                'mastery'        => new external_value(PARAM_INT, 'Alcanzan el aprobado'),
                'masteryof'      => new external_value(PARAM_INT, 'Evaluados'),
                'masteryrate'    => new external_value(PARAM_FLOAT, 'Porcentaje que alcanza el aprobado'),
            ])),
        ]);
    }

    /**
     * Estructura del bloque de foros y presencia docente.
     *
     * @return external_single_structure
     */
    public static function forum_returns(): external_single_structure {
        return new external_single_structure([
            'available'      => new external_value(PARAM_BOOL, 'El curso tiene foros visibles'),
            'canviewteaching' => new external_value(PARAM_BOOL, 'Quien mira ve las cifras docentes'),
            'windows'        => new external_value(PARAM_INT, 'Ventanas observadas'),
            'windowdays'     => new external_value(PARAM_INT, 'Dias de cada ventana'),
            'participants'   => new external_value(PARAM_INT, 'Estudiantes que participan'),
            'expected'       => new external_value(PARAM_INT, 'Estudiantes convocados'),
            'participationrate' => new external_value(PARAM_FLOAT, 'Porcentaje de participacion'),
            'peerrepliers'   => new external_value(PARAM_INT, 'Responden a un companero'),
            'peerreplierrate' => new external_value(PARAM_FLOAT, 'Porcentaje sobre participantes'),
            'discussions'    => new external_value(PARAM_INT, 'Hilos'),
            'unanswered'     => new external_value(PARAM_INT, 'Hilos sin respuesta'),
            'unansweredrate' => new external_value(PARAM_FLOAT, 'Porcentaje sin respuesta'),
            'peerposts'      => new external_value(PARAM_INT, 'Respuestas entre pares'),
            'interaction'    => new external_value(PARAM_FLOAT, 'Respuestas entre pares por participante'),
            'teachers'       => new external_value(PARAM_INT, 'Personas con rol docente'),
            'teacherwindows' => new external_value(PARAM_INT, 'Ventanas con intervencion docente'),
            'teacherwindowrate' => new external_value(PARAM_FLOAT, 'Porcentaje de ventanas'),
            'responsemedian' => new external_value(PARAM_FLOAT, 'Mediana de horas hasta la respuesta docente',
                VALUE_OPTIONAL, null, NULL_ALLOWED),
            'responsecases'  => new external_value(PARAM_INT, 'Hilos con respuesta docente medida'),
            'announcements'  => new external_value(PARAM_INT, 'Ventanas con anuncio'),
            'announcementrate' => new external_value(PARAM_FLOAT, 'Porcentaje de ventanas con anuncio'),
            'facilitated'    => new external_value(PARAM_INT, 'Foros con intervencion docente'),
            'activeforums'   => new external_value(PARAM_INT, 'Foros con actividad'),
            'facilitatedrate' => new external_value(PARAM_FLOAT, 'Porcentaje de foros mediados'),
            'forums' => new external_multiple_structure(new external_single_structure([
                'cmid'         => new external_value(PARAM_INT, 'ID del modulo'),
                'name'         => new external_value(PARAM_TEXT, 'Foro'),
                'type'         => new external_value(PARAM_ALPHA, 'Tipo de foro'),
                'discussions'  => new external_value(PARAM_INT, 'Hilos'),
                'posts'        => new external_value(PARAM_INT, 'Mensajes'),
                'participants' => new external_value(PARAM_INT, 'Estudiantes que participan'),
                'participationrate' => new external_value(PARAM_FLOAT, 'Porcentaje de participacion'),
                'unanswered'   => new external_value(PARAM_INT, 'Hilos sin respuesta'),
                'unansweredrate' => new external_value(PARAM_FLOAT, 'Porcentaje sin respuesta'),
                'teacherposts' => new external_value(PARAM_INT, 'Mensajes docentes'),
                'responsemedian' => new external_value(PARAM_FLOAT, 'Mediana de horas',
                    VALUE_OPTIONAL, null, NULL_ALLOWED),
            ])),
        ]);
    }

    /**
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {
        $series = new external_single_structure([
            'labels' => new external_multiple_structure(new external_value(PARAM_TEXT, 'Etiqueta')),
            'values' => new external_multiple_structure(new external_value(PARAM_FLOAT, 'Valor')),
        ]);

        return new external_single_structure([
            'kpis' => new external_single_structure([
                'students'     => new external_value(PARAM_INT, 'Estudiantes'),
                'avgprogress'  => new external_value(PARAM_FLOAT, 'Progreso medio (%)'),
                'avggrade'     => new external_value(PARAM_FLOAT, 'Calificacion media (%)'),
                'gradedcount'  => new external_value(PARAM_INT, 'Estudiantes con nota'),
                'avgtime'      => new external_value(PARAM_INT, 'Tiempo medio (segundos)'),
                'avgtimeformatted' => new external_value(PARAM_TEXT, 'Tiempo medio legible'),
                'totalmodules' => new external_value(PARAM_INT, 'Actividades con seguimiento'),
                'completed'    => new external_value(PARAM_INT, 'Estudiantes al 100%'),
            ]),
            'sections'   => $series,
            'activities' => new external_multiple_structure(new external_single_structure([
                'cmid'        => new external_value(PARAM_INT, 'ID del modulo'),
                'name'        => new external_value(PARAM_TEXT, 'Actividad'),
                'sectionname' => new external_value(PARAM_TEXT, 'Seccion'),
                'modname'     => new external_value(PARAM_PLUGIN, 'Tipo de modulo'),
                'completed'   => new external_value(PARAM_INT, 'Estudiantes que la completaron'),
                'progress'    => new external_value(PARAM_FLOAT, 'Porcentaje de finalizacion'),
                'average'     => new external_value(PARAM_FLOAT, 'Calificacion media (%)', VALUE_OPTIONAL, null, NULL_ALLOWED),
            ])),
            'students' => new external_multiple_structure(new external_single_structure([
                'userid'     => new external_value(PARAM_INT, 'ID'),
                'fullname'   => new external_value(PARAM_TEXT, 'Nombre'),
                'email'      => new external_value(PARAM_TEXT, 'Correo'),
                'progress'   => new external_value(PARAM_FLOAT, 'Progreso (%)'),
                'grade'      => new external_value(PARAM_FLOAT, 'Calificacion (%)', VALUE_OPTIONAL, null, NULL_ALLOWED),
                'lastaccess' => new external_value(PARAM_INT, 'Ultimo acceso (marca de tiempo)'),
                'lastaccessformatted' => new external_value(PARAM_TEXT, 'Ultimo acceso legible'),
                'timespent'  => new external_value(PARAM_INT, 'Permanencia (segundos)'),
                'timespentformatted' => new external_value(PARAM_TEXT, 'Permanencia legible'),
                'hours'      => new external_value(PARAM_FLOAT, 'Horas en la ventana'),
                'days'       => new external_value(PARAM_INT, 'Dias activos en la ventana'),
                'weeks'      => new external_value(PARAM_INT, 'Ventanas activas de 4'),
                'status'     => new external_value(PARAM_ALPHA, 'active | low | none'),
                'overduepending' => new external_value(PARAM_INT, 'Vencidas sin entregar'),
                'overduedue' => new external_value(PARAM_INT, 'Vencidas'),
            ])),
            'risk'          => get_report::risk_returns(),
            'evaluation'    => self::evaluation_returns(),
            'forums'        => self::forum_returns(),
            'coursename'    => new external_value(PARAM_TEXT, 'Nombre del curso'),
            'hascompletion' => new external_value(PARAM_BOOL, 'El curso tiene seguimiento de finalizacion'),
            'hasgrades'     => new external_value(PARAM_BOOL, 'El curso tiene calificaciones'),
            'haslogs'       => new external_value(PARAM_BOOL, 'Hay registros para estimar permanencia'),
            'logcapped'     => new external_value(PARAM_BOOL, 'Se alcanzo el tope de registros'),
            'totalmodules'  => new external_value(PARAM_INT, 'Actividades con seguimiento'),
        ]);
    }
}
