<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Interaccion en foros y presencia docente de un curso.
 *
 * Dos caras de la misma conversacion. Del lado del estudiante: quien
 * participa, quien responde a un companero, cuantos hilos se quedan sin
 * respuesta y cuanta interaccion hay entre pares. Del lado del docente:
 * en cuantas ventanas intervino, cuanto tarda en responder, si publica
 * anuncios y a cuantos foros llega su mediacion.
 *
 * La parte docente es sensible: mide el trabajo de una persona identificable.
 * Por eso vive detras de su propia capacidad, local/learninganalytics:viewteaching,
 * y el servidor la recorta cuando quien mira no la tiene.
 *
 * Se lee de {forum}, {forum_discussions} y {forum_posts}. Las respuestas
 * privadas quedan fuera: no son parte de la conversacion que ve el grupo.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class forum_query {

    /** Horas que se le dan a un hilo antes de contarlo como sin respuesta. */
    const UNANSWERED_GRACE = 48 * HOURSECS;

    /** Tope de mensajes que se procesan, para no ahogar la peticion. */
    const POST_CAP = 200000;

    /** @var int */
    protected $courseid;

    /** @var \context_course */
    protected $context;

    /** @var array Estudiantes visibles, ya filtrados por el informe de curso. */
    protected $userids;

    /** @var array Ids de quienes ejercen un rol docente en el curso. */
    protected $teacherids = [];

    /** @var bool Si quien mira puede ver las cifras de facilitacion. */
    protected $canviewteaching;

    /** @var int */
    protected $now;

    /**
     * @param int $courseid
     * @param array $userids Estudiantes visibles.
     * @param bool|null $canviewteaching Null = se comprueba la capacidad.
     */
    public function __construct(int $courseid, array $userids, ?bool $canviewteaching = null) {
        $this->courseid = $courseid;
        $this->context = \context_course::instance($courseid);
        $this->userids = array_values(array_unique(array_map('intval', $userids)));
        $this->now = time();
        $this->canviewteaching = $canviewteaching ?? has_capability(
            'local/learninganalytics:viewteaching', $this->context);
    }

    /**
     * Bloque vacio, con todas las claves que espera el servicio web.
     *
     * @return array
     */
    public static function empty_block(): array {
        return [
            'available'      => false,
            'canviewteaching' => false,
            'windows'        => activity_query::SERIES_WINDOWS,
            'windowdays'     => activity_query::window_days(),
            'participants'   => 0,
            'expected'       => 0,
            'participationrate' => 0.0,
            'peerrepliers'   => 0,
            'peerreplierrate' => 0.0,
            'discussions'    => 0,
            'unanswered'     => 0,
            'unansweredrate' => 0.0,
            'peerposts'      => 0,
            'interaction'    => 0.0,
            'teachers'       => 0,
            'teacherwindows' => 0,
            'teacherwindowrate' => 0.0,
            'responsemedian' => null,
            'responsecases'  => 0,
            'announcements'  => 0,
            'announcementrate' => 0.0,
            'facilitated'    => 0,
            'activeforums'   => 0,
            'facilitatedrate' => 0.0,
            'forums'         => [],
        ];
    }

    /**
     * Calcula el bloque completo.
     *
     * @return array
     */
    public function run(): array {
        global $DB;

        $block = self::empty_block();
        $block['canviewteaching'] = $this->canviewteaching;
        $block['expected'] = count($this->userids);

        $forums = $this->get_forums();
        if (empty($forums)) {
            return $block;
        }

        $block['available'] = true;
        $this->teacherids = $this->get_teacher_ids();
        $block['teachers'] = count($this->teacherids);

        [$discussions, $posts] = $this->get_activity(array_keys($forums));

        $students = array_flip($this->userids);
        $teachers = array_flip($this->teacherids);
        $window = activity_query::window_seconds();
        $windows = activity_query::SERIES_WINDOWS;

        // Mensajes agrupados por hilo, en orden, para responder a las
        // preguntas de hilo (sin respuesta, primera respuesta docente).
        $bydiscussion = [];
        foreach ($posts as $p) {
            $bydiscussion[(int)$p->discussion][] = $p;
        }
        $author = [];
        foreach ($posts as $p) {
            $author[(int)$p->id] = (int)$p->userid;
        }

        $participants = [];
        $peerrepliers = [];
        $peerposts = 0;
        $teacherwindows = [];
        $announcementwindows = [];
        $forumteachers = [];
        $responsetimes = [];

        $perforum = [];
        foreach ($forums as $f) {
            $perforum[(int)$f->id] = [
                'cmid'         => (int)$f->cmid,
                'name'         => format_string($f->name),
                'type'         => $f->type,
                'discussions'  => 0,
                'posts'        => 0,
                'participants' => 0,
                'participationrate' => 0.0,
                'unanswered'   => 0,
                'unansweredrate' => 0.0,
                'teacherposts' => 0,
                'responsemedian' => null,
                'people'       => [],
                'times'        => [],
            ];
        }

        foreach ($posts as $p) {
            $uid = (int)$p->userid;
            $forumid = (int)$p->forum;
            $created = (int)$p->created;
            if (!isset($perforum[$forumid])) {
                continue;
            }
            $perforum[$forumid]['posts']++;

            $isteacher = isset($teachers[$uid]);
            if ($isteacher) {
                $perforum[$forumid]['teacherposts']++;
                $forumteachers[$forumid] = true;
                $index = intdiv(max(0, $this->now - $created - 1), $window);
                if ($index < $windows) {
                    $teacherwindows[$index] = true;
                    if ($p->type === 'news') {
                        $announcementwindows[$index] = true;
                    }
                }
            }

            if (isset($students[$uid])) {
                $participants[$uid] = true;
                $perforum[$forumid]['people'][$uid] = true;

                // Responder a un companero: el mensaje padre existe y lo
                // escribio otra persona que no es docente.
                $parent = (int)$p->parent;
                if ($parent && isset($author[$parent])) {
                    $parentauthor = $author[$parent];
                    if ($parentauthor !== $uid && !isset($teachers[$parentauthor])) {
                        $peerrepliers[$uid] = true;
                        $peerposts++;
                    }
                }
            }
        }

        // Hilos: sin respuesta y tiempo hasta la primera respuesta docente.
        foreach ($discussions as $d) {
            $forumid = (int)$d->forum;
            if (!isset($perforum[$forumid])) {
                continue;
            }
            $perforum[$forumid]['discussions']++;
            $block['discussions']++;

            $list = $bydiscussion[(int)$d->id] ?? [];
            if (empty($list)) {
                continue;
            }

            $first = $list[0];
            $firstauthor = (int)$first->userid;
            $mature = ((int)$first->created) < ($this->now - self::UNANSWERED_GRACE);

            // Un hilo cuenta como sin respuesta solo si lo abrio alguien que
            // no es docente: un anuncio no espera contestacion.
            if ($mature && count($list) === 1 && !isset($teachers[$firstauthor])) {
                $perforum[$forumid]['unanswered']++;
                $block['unanswered']++;
            }

            // Primera respuesta docente al primer mensaje no docente del hilo.
            $asked = null;
            foreach ($list as $p) {
                $uid = (int)$p->userid;
                if ($asked === null && !isset($teachers[$uid])) {
                    $asked = (int)$p->created;
                    continue;
                }
                if ($asked !== null && isset($teachers[$uid])) {
                    $hours = ((int)$p->created - $asked) / HOURSECS;
                    if ($hours >= 0) {
                        $responsetimes[] = $hours;
                        $perforum[$forumid]['times'][] = $hours;
                    }
                    break;
                }
            }
        }

        $block['participants'] = count($participants);
        $block['participationrate'] = activity_query::rate($block['participants'], $block['expected']);
        $block['peerrepliers'] = count($peerrepliers);
        $block['peerreplierrate'] = activity_query::rate($block['peerrepliers'], $block['participants']);
        $block['unansweredrate'] = activity_query::rate($block['unanswered'], $block['discussions']);
        $block['peerposts'] = $peerposts;
        $block['interaction'] = $block['participants']
            ? round($peerposts / $block['participants'], 1) : 0.0;

        $block['teacherwindows'] = count($teacherwindows);
        $block['teacherwindowrate'] = activity_query::rate($block['teacherwindows'], $windows);
        $block['announcements'] = count($announcementwindows);
        $block['announcementrate'] = activity_query::rate($block['announcements'], $windows);
        $block['responsemedian'] = self::median($responsetimes);
        $block['responsecases'] = count($responsetimes);

        $activeforums = 0;
        foreach ($perforum as $id => &$f) {
            $f['participants'] = count($f['people']);
            $f['participationrate'] = activity_query::rate($f['participants'], $block['expected']);
            $f['unansweredrate'] = activity_query::rate($f['unanswered'], $f['discussions']);
            $f['responsemedian'] = self::median($f['times']);
            unset($f['people'], $f['times']);
            if ($f['posts'] > 0) {
                $activeforums++;
                if (!empty($forumteachers[$id])) {
                    $block['facilitated']++;
                }
            }
        }
        unset($f);

        $block['activeforums'] = $activeforums;
        $block['facilitatedrate'] = activity_query::rate($block['facilitated'], $activeforums);

        // Los foros con mas conversacion primero: son los que se revisan.
        usort($perforum, fn($a, $b) => [$b['posts'], $a['name']] <=> [$a['posts'], $b['name']]);
        $block['forums'] = array_values($perforum);

        return $this->canviewteaching ? $block : self::strip_teaching($block);
    }

    /**
     * Retira del bloque las cifras que describen el trabajo docente.
     *
     * Se hace en el servidor: ocultar tarjetas en el navegador dejaria los
     * datos igualmente al alcance de quien mire la respuesta del servicio.
     *
     * @param array $block
     * @return array
     */
    protected static function strip_teaching(array $block): array {
        $block['teachers'] = 0;
        $block['teacherwindows'] = 0;
        $block['teacherwindowrate'] = 0.0;
        $block['responsemedian'] = null;
        $block['responsecases'] = 0;
        $block['announcements'] = 0;
        $block['announcementrate'] = 0.0;
        $block['facilitated'] = 0;
        $block['facilitatedrate'] = 0.0;

        $block['forums'] = array_map(function($f) {
            $f['teacherposts'] = 0;
            $f['responsemedian'] = null;
            return $f;
        }, $block['forums']);

        return $block;
    }

    /**
     * Mediana de una lista de numeros, o null si esta vacia.
     *
     * @param array $values
     * @return float|null
     */
    public static function median(array $values): ?float {
        if (empty($values)) {
            return null;
        }
        sort($values);
        $n = count($values);
        $mid = intdiv($n, 2);

        return round($n % 2 ? $values[$mid] : ($values[$mid - 1] + $values[$mid]) / 2, 1);
    }

    /**
     * Foros visibles del curso.
     *
     * @return array forumid => registro
     */
    protected function get_forums(): array {
        global $DB;

        if (!$DB->get_manager()->table_exists('forum')) {
            return [];
        }

        return $DB->get_records_sql(
            "SELECT f.id, f.name, f.type, cm.id AS cmid
               FROM {forum} f
               JOIN {course_modules} cm ON cm.instance = f.id
               JOIN {modules} m ON m.id = cm.module AND m.name = 'forum'
              WHERE f.course = :courseid AND cm.visible = 1 AND cm.deletioninprogress = 0",
            ['courseid' => $this->courseid]);
    }

    /**
     * Quienes ejercen un rol docente o de gestion en el curso.
     *
     * Se miran el contexto del curso y sus ancestros, de modo que un docente
     * asignado en la categoria tambien cuenta.
     *
     * @return array
     */
    protected function get_teacher_ids(): array {
        global $DB;

        $ctxids = $this->context->get_parent_context_ids(true);
        if (empty($ctxids)) {
            return [];
        }

        [$insql, $params] = $DB->get_in_or_equal($ctxids, SQL_PARAMS_NAMED, 'ftc');

        $ids = $DB->get_fieldset_sql(
            "SELECT DISTINCT ra.userid
               FROM {role_assignments} ra
               JOIN {role} r ON r.id = ra.roleid
              WHERE ra.contextid {$insql}
                    AND r.archetype IN ('editingteacher', 'teacher', 'manager')", $params);

        return array_map('intval', $ids);
    }

    /**
     * Hilos y mensajes de los foros indicados.
     *
     * @param array $forumids
     * @return array [hilos, mensajes en orden cronologico]
     */
    protected function get_activity(array $forumids): array {
        global $DB;

        if (empty($forumids)) {
            return [[], []];
        }

        [$insql, $params] = $DB->get_in_or_equal($forumids, SQL_PARAMS_NAMED, 'fq');

        $discussions = $DB->get_records_sql(
            "SELECT id, forum, userid, timemodified
               FROM {forum_discussions}
              WHERE forum {$insql}", $params);

        // Las respuestas privadas no son parte de la conversacion del grupo,
        // y los mensajes borrados ya no existen para nadie.
        $posts = $DB->get_records_sql(
            "SELECT p.id, p.discussion, p.parent, p.userid, p.created,
                    d.forum, f.type
               FROM {forum_posts} p
               JOIN {forum_discussions} d ON d.id = p.discussion
               JOIN {forum} f ON f.id = d.forum
              WHERE d.forum {$insql} AND p.deleted = 0 AND p.privatereplyto = 0
           ORDER BY p.discussion, p.created, p.id", $params, 0, self::POST_CAP);

        return [$discussions, $posts];
    }
}
