<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Reune los datos que se pueden exportar.
 *
 * Traduce un "objetivo" (un objeto suelto, un bloque o el informe entero) a una
 * lista de conjuntos de datos con titulo, cabeceras y filas. A partir de ahi,
 * cada formato solo tiene que recorrer esa estructura, de modo que CSV, XLSX y
 * PDF no pueden divergir en lo que muestran.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class exporter {

    /** @var scope */
    protected $scope;

    /** @var array */
    protected $filters;

    /** @var array|null Informe general, calculado bajo demanda. */
    protected $report = null;

    /** @var array|null Informe de curso, calculado bajo demanda. */
    protected $coursereport = null;

    /**
     * @param scope $scope
     * @param array $filters
     */
    public function __construct(scope $scope, array $filters) {
        $this->scope = $scope;
        $this->filters = $filters;
    }

    /**
     * Objetivos disponibles en este ambito.
     *
     * @return array clave => titulo
     */
    public function get_available_targets(): array {
        $targets = [
            'kpis'         => get_string('exp_kpis', 'local_learninganalytics'),
            'users'        => get_string('tab_users', 'local_learninganalytics'),
            'progress'     => get_string('tab_progress', 'local_learninganalytics'),
            'growth'       => get_string('chart_growth', 'local_learninganalytics'),
            'domains'      => get_string('chart_domains', 'local_learninganalytics'),
            'countries'    => get_string('chart_countries', 'local_learninganalytics'),
            'activity'     => get_string('chart_activity', 'local_learninganalytics'),
            'topcourses'   => get_string('chart_topcourses', 'local_learninganalytics'),
            'risk'         => get_string('exp_risk', 'local_learninganalytics'),
            'riskusers'    => get_string('risk_table', 'local_learninganalytics'),
            'riskseries'   => get_string('chart_riskseries', 'local_learninganalytics'),
        ];

        if ($this->scope->get_level() === scope::LEVEL_COURSE) {
            $targets['cforums']     = get_string('exp_forums', 'local_learninganalytics');
            $targets['cforumitems'] = get_string('forum_table', 'local_learninganalytics');
            $targets['ceval']       = get_string('exp_eval', 'local_learninganalytics');
            $targets['cevalitems']  = get_string('eval_table', 'local_learninganalytics');
            $targets['crisk']       = get_string('exp_risk', 'local_learninganalytics');
            $targets['criskusers']  = get_string('risk_table', 'local_learninganalytics');
            $targets['criskseries'] = get_string('chart_riskseries', 'local_learninganalytics');
            $targets['ckpis']       = get_string('exp_coursekpis', 'local_learninganalytics');
            $targets['csections']   = get_string('chart_sections', 'local_learninganalytics');
            $targets['cactivities'] = get_string('tab_activities', 'local_learninganalytics');
            $targets['cstudents']   = get_string('tab_students', 'local_learninganalytics');
        }

        return $targets;
    }

    /**
     * Devuelve los conjuntos de datos de un objetivo.
     *
     * @param string $target Clave de objeto, "block:*" o "all".
     * @return array Lista de ['title' => ..., 'headers' => [...], 'rows' => [[...]]]
     */
    public function get_datasets(string $target): array {
        $iscourse = $this->scope->get_level() === scope::LEVEL_COURSE;

        // El navegador no puede enviar ":" en un PARAM_ALPHANUMEXT, asi que
        // los bloques viajan sin el. Se aceptan ambas formas para que la
        // clase no dependa de como la llame quien la use.
        $aliases = [
            'blockcharts' => 'block:charts',
            'blocktables' => 'block:tables',
            'blockcourse' => 'block:course',
        ];
        $target = $aliases[$target] ?? $target;

        switch ($target) {
            case 'all':
                $keys = ['kpis', 'users', 'progress', 'growth', 'domains',
                         'countries', 'activity', 'topcourses'];
                if ($iscourse) {
                    $keys = array_merge(['ckpis', 'crisk', 'criskusers', 'ceval', 'cevalitems',
                        'cforums', 'cforumitems', 'csections', 'cactivities', 'cstudents'], $keys);
                } else {
                    $keys = array_merge($keys, ['risk', 'riskusers', 'riskseries']);
                }
                break;

            case 'block:charts':
                $keys = ['growth', 'domains', 'countries', 'activity', 'topcourses'];
                if ($iscourse) {
                    array_unshift($keys, 'csections', 'criskseries');
                } else {
                    $keys[] = 'riskseries';
                }
                break;

            case 'block:tables':
                $keys = $iscourse
                    ? ['cstudents', 'cactivities', 'criskusers', 'cevalitems', 'cforumitems', 'users', 'progress']
                                  : ['users', 'progress', 'riskusers'];
                break;

            case 'block:course':
                $keys = $iscourse
                    ? ['ckpis', 'crisk', 'ceval', 'cforums', 'csections', 'cactivities', 'cstudents',
                       'criskusers', 'cevalitems', 'cforumitems']
                    : [];
                break;

            default:
                $keys = [$target];
        }

        $out = [];
        foreach ($keys as $key) {
            $dataset = $this->build_dataset($key);
            if ($dataset !== null) {
                $out[] = $dataset;
            }
        }

        return $out;
    }

    /**
     * Informe general, calculado una sola vez.
     *
     * @return array
     */
    protected function report(): array {
        if ($this->report === null) {
            $this->report = (new report_query($this->filters, $this->scope))->run();
        }

        return $this->report;
    }

    /**
     * Informe de curso, calculado una sola vez.
     *
     * @return array|null
     */
    protected function coursereport(): ?array {
        if ($this->scope->get_level() !== scope::LEVEL_COURSE) {
            return null;
        }

        if ($this->coursereport === null) {
            $this->coursereport = (new course_report(
                $this->scope->get_instanceid(), $this->filters))->run();
        }

        return $this->coursereport;
    }

    /**
     * Construye un conjunto de datos concreto.
     *
     * @param string $key
     * @return array|null
     */
    protected function build_dataset(string $key): ?array {
        switch ($key) {
            case 'kpis':
                return $this->dataset_kpis();
            case 'users':
                return $this->dataset_users();
            case 'progress':
                return $this->dataset_progress();
            case 'growth':
            case 'domains':
            case 'countries':
            case 'activity':
            case 'topcourses':
            case 'certificates':
            case 'certsplit':
                return $this->dataset_series($key);
            case 'ckpis':
                return $this->dataset_course_kpis();
            case 'csections':
                return $this->dataset_sections();
            case 'cactivities':
                return $this->dataset_activities();
            case 'cstudents':
                return $this->dataset_students();
            case 'risk':
                return $this->dataset_risk(false);
            case 'crisk':
                return $this->dataset_risk(true);
            case 'riskusers':
                return $this->dataset_risk_users(false);
            case 'criskusers':
                return $this->dataset_risk_users(true);
            case 'riskseries':
                return $this->dataset_risk_series(false);
            case 'criskseries':
                return $this->dataset_risk_series(true);
            case 'ceval':
                return $this->dataset_eval();
            case 'cevalitems':
                return $this->dataset_eval_items();
            case 'cforums':
                return $this->dataset_forums();
            case 'cforumitems':
                return $this->dataset_forum_items();
        }

        return null;
    }

    /**
     * Bloque de riesgo del informe que toque, o null si no hay datos.
     *
     * @param bool $course
     * @return array|null
     */
    protected function risk(bool $course): ?array {
        $r = $course ? $this->coursereport() : $this->report();
        if (!$r || empty($r['risk']['available'])) {
            return null;
        }
        return $r['risk'];
    }

    /**
     * Cifras de permanencia y riesgo.
     *
     * @param bool $course
     * @return array|null
     */
    protected function dataset_risk(bool $course): ?array {
        $k = $this->risk($course);
        if (!$k) {
            return null;
        }

        $s = fn($key) => get_string($key, 'local_learninganalytics');
        $rows = [
            [$s('hdr_risk'), get_string('risk_intro', 'local_learninganalytics',
                (object)['hours' => $k['hours'], 'days' => $k['window']])],
            [$s('kpi_active'), $k['active'] . ' (' . $k['activerate'] . '%)'],
            [$s('kpi_low'), $k['low']],
            [$s('kpi_none'), $k['none']],
            [$s('kpi_regular'), $k['regular'] . ' (' . $k['regularrate'] . '%)'],
            [$s('kpi_avgdays'), $k['avgdays']],
            [$s('kpi_early'), $k['earlyentered'] . '/' . $k['earlytotal'] . ' (' . $k['earlyrate'] . '%)'],
            [$s('kpi_react'), $k['reactivated'] . '/' . $k['reacttotal'] . ' (' . $k['reactrate'] . '%)'],
        ];
        if ($course) {
            $rows[] = [$s('kpi_overdue'),
                $k['overduepending'] . '/' . $k['overduedue'] . ' (' . $k['overduerate'] . '%)'];
            $rows[] = [$s('kpi_earlyexit'), $k['earlyexit'] . ' (' . $k['earlyexitrate'] . '%)'];
        }

        return [
            'title'   => $s('exp_risk'),
            'headers' => [$s('exp_indicator'), $s('exp_value')],
            'rows'    => $rows,
        ];
    }

    /**
     * Personas por debajo de la regla.
     *
     * @param bool $course
     * @return array|null
     */
    protected function dataset_risk_users(bool $course): ?array {
        $k = $this->risk($course);
        if (!$k) {
            return null;
        }

        $s = fn($key) => get_string($key, 'local_learninganalytics');
        $status = [
            'active' => $s('status_active'),
            'low'    => $s('status_low'),
            'none'   => $s('status_none'),
        ];

        $rows = [];
        foreach ($k['users'] as $u) {
            $row = [$u['fullname'], $u['email']];
            if ($course) {
                $row[] = ($u['progress'] ?? 0) . '%';
            }
            $row[] = $u['hours'];
            $row[] = $u['days'];
            $row[] = $u['weeks'];
            if ($course) {
                $row[] = $u['overduedue'] ? $u['overduepending'] . '/' . $u['overduedue'] : '-';
            }
            $row[] = $u['lastaccess'];
            $row[] = $status[$u['status']] ?? $u['status'];
            $rows[] = $row;
        }

        $headers = [$s('col_name'), $s('col_email')];
        if ($course) {
            $headers[] = $s('col_progress');
        }
        $headers[] = $s('col_hours');
        $headers[] = $s('col_days');
        $headers[] = $s('col_weeks');
        if ($course) {
            $headers[] = $s('col_overdue');
        }
        $headers[] = $s('col_lastaccess');
        $headers[] = $s('col_status');

        return [
            'title'   => $s('risk_table'),
            'headers' => $headers,
            'rows'    => $rows,
        ];
    }

    /**
     * Serie de personas activas por ventana.
     *
     * @param bool $course
     * @return array|null
     */
    protected function dataset_risk_series(bool $course): ?array {
        $k = $this->risk($course);
        if (!$k || empty($k['series']['labels'])) {
            return null;
        }

        $rows = [];
        foreach ($k['series']['labels'] as $i => $label) {
            $rows[] = [$label, $k['series']['values'][$i]];
        }

        return [
            'title'   => get_string('chart_riskseries', 'local_learninganalytics'),
            'headers' => [get_string('exp_category', 'local_learninganalytics'),
                          get_string('exp_value', 'local_learninganalytics')],
            'rows'    => $rows,
        ];
    }

    /**
     * @return array
     */
    protected function dataset_kpis(): array {
        $r = $this->report();
        $k = $r['kpis'];

        $rows = [
            [get_string('kpi_users', 'local_learninganalytics'), $k['users']],
            [get_string('kpi_enrolments', 'local_learninganalytics'), $k['enrolments']],
        ];

        // Los certificados solo se exportan si el ambito los tiene.
        if (!empty($r['hascerts'])) {
            $rows[] = [get_string('kpi_certificates', 'local_learninganalytics'), $k['certificates']];
            $rows[] = [get_string('kpi_certrate', 'local_learninganalytics'), $k['certrate'] . '%'];
        }

        return [
            'title'   => get_string('exp_kpis', 'local_learninganalytics'),
            'headers' => [get_string('exp_indicator', 'local_learninganalytics'),
                          get_string('exp_value', 'local_learninganalytics')],
            'rows'    => $rows,
        ];
    }

    /**
     * @return array
     */
    protected function dataset_users(): array {
        $r = $this->report();

        $headers = [
            get_string('col_name', 'local_learninganalytics'),
            get_string('col_email', 'local_learninganalytics'),
            get_string('col_country', 'local_learninganalytics'),
        ];
        if (!empty($r['hasestado'])) {
            $headers[] = get_string('col_estado', 'local_learninganalytics');
        }
        if (!empty($r['hassupervisor'])) {
            $headers[] = get_string('col_supervisor', 'local_learninganalytics');
        }
        $headers[] = get_string('col_lastaccess', 'local_learninganalytics');

        $rows = [];
        foreach ($r['users'] as $u) {
            $row = [$u['fullname'], $u['email'], $u['country']];
            if (!empty($r['hasestado'])) {
                $row[] = $u['estado'];
            }
            if (!empty($r['hassupervisor'])) {
                $row[] = $u['supervisor'];
            }
            $row[] = $u['lastaccess'];
            $rows[] = $row;
        }

        return [
            'title'   => get_string('tab_users', 'local_learninganalytics'),
            'headers' => $headers,
            'rows'    => $rows,
        ];
    }

    /**
     * @return array
     */
    protected function dataset_progress(): array {
        $r = $this->report();
        $rows = [];

        foreach ($r['progress'] as $p) {
            $signed = $p['signed'] === 'na'
                ? get_string('notapplicable', 'local_learninganalytics')
                : ($p['signed'] === 'yes'
                    ? get_string('yes', 'local_learninganalytics')
                    : get_string('no', 'local_learninganalytics'));

            $rows[] = [$p['fullname'], $p['email'], $p['coursename'], $signed];
        }

        return [
            'title'   => get_string('tab_progress', 'local_learninganalytics'),
            'headers' => [
                get_string('col_name', 'local_learninganalytics'),
                get_string('col_email', 'local_learninganalytics'),
                get_string('col_course', 'local_learninganalytics'),
                get_string('col_signed', 'local_learninganalytics'),
            ],
            'rows'    => $rows,
        ];
    }

    /**
     * Serie de una grafica como tabla de dos columnas.
     *
     * @param string $key
     * @return array|null
     */
    protected function dataset_series(string $key): ?array {
        $r = $this->report();

        if (empty($r[$key]['labels'])) {
            return null;   // Sin datos no se exporta una hoja vacia.
        }

        $titles = [
            'growth'       => 'chart_growth',
            'domains'      => 'chart_domains',
            'countries'    => 'chart_countries',
            'activity'     => 'chart_activity',
            'topcourses'   => 'chart_topcourses',
            'certificates' => 'chart_certificates',
            'certsplit'    => 'chart_certsplit',
        ];

        $rows = [];
        foreach ($r[$key]['labels'] as $i => $label) {
            $rows[] = [$label, $r[$key]['values'][$i]];
        }

        return [
            'title'   => get_string($titles[$key], 'local_learninganalytics'),
            'headers' => [get_string('exp_category', 'local_learninganalytics'),
                          get_string('exp_value', 'local_learninganalytics')],
            'rows'    => $rows,
        ];
    }

    /**
     * @return array|null
     */
    protected function dataset_course_kpis(): ?array {
        $c = $this->coursereport();
        if (!$c) {
            return null;
        }

        $k = $c['kpis'];

        return [
            'title'   => get_string('exp_coursekpis', 'local_learninganalytics'),
            'headers' => [get_string('exp_indicator', 'local_learninganalytics'),
                          get_string('exp_value', 'local_learninganalytics')],
            'rows'    => [
                [get_string('kpi_students', 'local_learninganalytics'), $k['students']],
                [get_string('kpi_avgprogress', 'local_learninganalytics'), $k['avgprogress'] . '%'],
                [get_string('kpi_avggrade', 'local_learninganalytics'),
                    $k['gradedcount'] > 0 ? $k['avggrade'] . '%' : '-'],
                [get_string('kpi_avgtime', 'local_learninganalytics'), $k['avgtimeformatted']],
                [get_string('kpi_completed', 'local_learninganalytics'), $k['completed']],
            ],
        ];
    }

    /**
     * @return array|null
     */
    protected function dataset_sections(): ?array {
        $c = $this->coursereport();
        if (!$c || empty($c['sections']['labels'])) {
            return null;
        }

        $rows = [];
        foreach ($c['sections']['labels'] as $i => $label) {
            $rows[] = [$label, $c['sections']['values'][$i] . '%'];
        }

        return [
            'title'   => get_string('chart_sections', 'local_learninganalytics'),
            'headers' => [get_string('col_section', 'local_learninganalytics'),
                          get_string('col_progress', 'local_learninganalytics')],
            'rows'    => $rows,
        ];
    }

    /**
     * @return array|null
     */
    protected function dataset_activities(): ?array {
        $c = $this->coursereport();
        if (!$c) {
            return null;
        }

        $rows = [];
        foreach ($c['activities'] as $a) {
            $rows[] = [
                $a['name'],
                $a['sectionname'],
                $a['modname'],
                $a['completed'],
                $a['progress'] . '%',
                ($a['average'] === null) ? '-' : $a['average'] . '%',
            ];
        }

        return [
            'title'   => get_string('tab_activities', 'local_learninganalytics'),
            'headers' => [
                get_string('col_activity', 'local_learninganalytics'),
                get_string('col_section', 'local_learninganalytics'),
                get_string('exp_type', 'local_learninganalytics'),
                get_string('col_completedby', 'local_learninganalytics'),
                get_string('col_progress', 'local_learninganalytics'),
                get_string('col_avggrade', 'local_learninganalytics'),
            ],
            'rows'    => $rows,
        ];
    }

    /**
     * @return array|null
     */
    protected function dataset_students(): ?array {
        $c = $this->coursereport();
        if (!$c) {
            return null;
        }

        $rows = [];
        foreach ($c['students'] as $s) {
            $rows[] = [
                $s['fullname'],
                $s['email'],
                $s['progress'] . '%',
                ($s['grade'] === null) ? '-' : $s['grade'] . '%',
                $s['lastaccessformatted'],
                $s['timespentformatted'],
            ];
        }

        return [
            'title'   => get_string('tab_students', 'local_learninganalytics'),
            'headers' => [
                get_string('col_name', 'local_learninganalytics'),
                get_string('col_email', 'local_learninganalytics'),
                get_string('col_progress', 'local_learninganalytics'),
                get_string('col_grade', 'local_learninganalytics'),
                get_string('col_lastaccess', 'local_learninganalytics'),
                get_string('col_timespent', 'local_learninganalytics'),
            ],
            'rows'    => $rows,
        ];
    }

    /**
     * Bloque de evaluacion del curso, o null si no hay datos.
     *
     * @return array|null
     */
    protected function evaluation(): ?array {
        $c = $this->coursereport();
        if (!$c || empty($c['evaluation']['available'])) {
            return null;
        }
        return $c['evaluation'];
    }

    /**
     * Cifras de evaluacion y entregas.
     *
     * @return array|null
     */
    protected function dataset_eval(): ?array {
        $e = $this->evaluation();
        if (!$e) {
            return null;
        }

        $s = fn($key) => get_string($key, 'local_learninganalytics');
        $frac = fn($n, $t, $r) => $t > 0 ? "{$n}/{$t} ({$r}%)" : '-';

        $rows = [
            [$s('kpi_ontime'), $frac($e['ontime'], $e['ontimeexpected'], $e['ontimerate'])],
            [$s('kpi_quizdone'), $frac($e['quizdone'], $e['quizexpected'], $e['quizrate'])],
            [$s('kpi_mastery'), $e['hasmastery'] ? $frac($e['mastery'], $e['masteryof'], $e['masteryrate']) : '-'],
            [$s('kpi_feedback'), $frac($e['feedback'], $e['graded'], $e['feedbackrate'])],
            [get_string('kpi_feedbackintime', 'local_learninganalytics', $e['feedbackdays']),
                $frac($e['feedbackintime'], $e['graded'], $e['feedbackintimerate'])],
            [$s('kpi_resubmit'), $frac($e['resubmitted'], $e['resubmittable'], $e['resubmitrate'])],
            [$s('kpi_gradebook'), $frac($e['itemsuptodate'], $e['itemsdue'], $e['uptodaterate'])],
            [$s('kpi_gain'), $e['hasgain'] ? $e['gain'] . ' pp' : '-'],
        ];

        return [
            'title'   => $s('exp_eval'),
            'headers' => [$s('exp_indicator'), $s('exp_value')],
            'rows'    => $rows,
        ];
    }

    /**
     * Tabla de actividades evaluables.
     *
     * @return array|null
     */
    protected function dataset_eval_items(): ?array {
        $e = $this->evaluation();
        if (!$e) {
            return null;
        }

        $s = fn($key) => get_string($key, 'local_learninganalytics');
        // Un denominador a cero se muestra como guion: "0/0 (0%)" no dice nada.
        $pct = fn($n, $r, $t) => $t > 0 ? "{$n} ({$r}%)" : '-';
        $ratio = fn($n, $t, $r) => $t > 0 ? "{$n}/{$t} ({$r}%)" : '-';
        $rows = [];
        foreach ($e['items'] as $it) {
            $assign = $it['type'] === 'assign';
            $rows[] = [
                $it['name'],
                $s($it['type'] === 'quiz' ? 'type_quiz' : 'type_assign'),
                $it['deadline'] !== '' ? $it['deadline'] : $s('nodeadline'),
                $it['expected'],
                $it['delivered'] . ($it['expected'] > 0 ? ' (' . $it['deliveredrate'] . '%)' : ''),
                $assign ? $pct($it['ontime'], $it['ontimerate'], $it['expected']) : '-',
                $assign ? $ratio($it['feedback'], $it['graded'], $it['feedbackrate']) : '-',
                $assign ? $pct($it['feedbackintime'], $it['feedbackintimerate'], $it['graded']) : '-',
                $it['gain'] === null ? '-' : $it['gain'] . ' pp',
                $it['gradepass'] === null ? '-' : $ratio($it['mastery'], $it['masteryof'], $it['masteryrate']),
                $it['pendinggrading'] > 0
                    ? get_string('grading_pending', 'local_learninganalytics', $it['pendinggrading'])
                    : $s('grading_uptodate'),
            ];
        }

        return [
            'title'   => $s('eval_table'),
            'headers' => [
                $s('col_activity'), $s('col_type'), $s('col_deadline'), $s('col_expected'),
                $s('col_delivered'), $s('col_ontime'), $s('col_feedback'), $s('col_feedbackintime'),
                $s('col_gain'), $s('col_mastery'), $s('col_gradingstatus'),
            ],
            'rows'    => $rows,
        ];
    }

    /**
     * Bloque de foros del curso, o null si no hay foros visibles.
     *
     * @return array|null
     */
    protected function forums(): ?array {
        $c = $this->coursereport();
        if (!$c || empty($c['forums']['available'])) {
            return null;
        }
        return $c['forums'];
    }

    /**
     * Cifras de foros y, si quien exporta puede verlas, de presencia docente.
     *
     * @return array|null
     */
    protected function dataset_forums(): ?array {
        $f = $this->forums();
        if (!$f) {
            return null;
        }

        $s = fn($key) => get_string($key, 'local_learninganalytics');
        $ratio = fn($n, $t, $r) => $t > 0 ? "{$n}/{$t} ({$r}%)" : '-';

        $rows = [
            [$s('kpi_participation'), $ratio($f['participants'], $f['expected'], $f['participationrate'])],
            [$s('kpi_peerreply'), $ratio($f['peerrepliers'], $f['participants'], $f['peerreplierrate'])],
            [$s('kpi_unanswered'), $ratio($f['unanswered'], $f['discussions'], $f['unansweredrate'])],
            [$s('kpi_interaction'), $f['participants'] > 0 ? $f['interaction'] : '-'],
        ];

        // La presencia docente solo se exporta a quien tiene la capacidad: el
        // recorte ya lo hizo forum_query, aqui solo se omiten las filas.
        if (!empty($f['canviewteaching'])) {
            $rows[] = [$s('kpi_teacherwindows'), $ratio($f['teacherwindows'], $f['windows'], $f['teacherwindowrate'])];
            $rows[] = [$s('kpi_responsetime'), $f['responsemedian'] === null
                ? '-' : get_string('hours', 'local_learninganalytics', $f['responsemedian'])];
            $rows[] = [$s('kpi_announcements'), $ratio($f['announcements'], $f['windows'], $f['announcementrate'])];
            $rows[] = [$s('kpi_facilitated'), $ratio($f['facilitated'], $f['activeforums'], $f['facilitatedrate'])];
        }

        return [
            'title'   => $s('exp_forums'),
            'headers' => [$s('exp_indicator'), $s('exp_value')],
            'rows'    => $rows,
        ];
    }

    /**
     * Tabla de foros del curso.
     *
     * @return array|null
     */
    protected function dataset_forum_items(): ?array {
        $f = $this->forums();
        if (!$f) {
            return null;
        }

        $s = fn($key) => get_string($key, 'local_learninganalytics');
        $ratio = fn($n, $t, $r) => $t > 0 ? "{$n}/{$t} ({$r}%)" : '-';
        $teaching = !empty($f['canviewteaching']);

        $rows = [];
        foreach ($f['forums'] as $item) {
            $row = [
                $item['name'],
                self::forum_type_label($item['type']),
                $item['discussions'],
                $item['posts'],
                $ratio($item['participants'], $f['expected'], $item['participationrate']),
                $ratio($item['unanswered'], $item['discussions'], $item['unansweredrate']),
            ];
            if ($teaching) {
                $row[] = $item['teacherposts'];
                $row[] = $item['responsemedian'] === null
                    ? '-' : get_string('hours', 'local_learninganalytics', $item['responsemedian']);
            }
            $rows[] = $row;
        }

        $headers = [$s('col_forum'), $s('col_type'), $s('col_discussions'), $s('col_posts'),
                    $s('col_participants'), $s('col_unanswered')];
        if ($teaching) {
            $headers[] = $s('col_teacherposts');
            $headers[] = $s('col_responsetime');
        }

        return [
            'title'   => $s('forum_table'),
            'headers' => $headers,
            'rows'    => $rows,
        ];
    }

    /**
     * Nombre legible del tipo de foro.
     *
     * @param string $type
     * @return string
     */
    public static function forum_type_label(string $type): string {
        $known = ['general', 'news', 'qanda', 'single', 'eachuser', 'blog'];

        return in_array($type, $known, true)
            ? get_string('forumtype_' . $type, 'local_learninganalytics')
            : $type;
    }

    /**
     * Titulo legible del informe, para la cabecera del archivo.
     *
     * @return string
     */
    public function get_report_title(): string {
        return $this->scope->get_heading();
    }
}
