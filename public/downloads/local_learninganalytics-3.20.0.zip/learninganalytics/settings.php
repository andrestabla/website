<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Admin settings: acceso, ubicacion y directivas de funcionamiento.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use local_learninganalytics\admin\setting_roles;

if ($hassiteconfig) {

    // Entrada del dashboard de plataforma en Informes.
    $ADMIN->add('reports', new admin_externalpage(
        'local_learninganalytics',
        get_string('dashboard', 'local_learninganalytics'),
        new moodle_url('/local/learninganalytics/index.php'),
        'local/learninganalytics:view'
    ));

    $settings = new admin_settingpage(
        'local_learninganalytics_settings',
        get_string('settings', 'local_learninganalytics')
    );
    $ADMIN->add('localplugins', $settings);

    if ($ADMIN->fulltree) {
        global $DB, $OUTPUT;

        // ------------------------------------------------------------------
        // Licencia.
        // ------------------------------------------------------------------
        $settings->add(new admin_setting_heading(
            'local_learninganalytics/hdr_licence',
            get_string('hdr_licence', 'local_learninganalytics'),
            \local_learninganalytics\local\licence::get_status_message()
                . '<br><br>' . get_string('hdr_licence_desc', 'local_learninganalytics')
        ));

        $settings->add(new admin_setting_configtextarea(
            'local_learninganalytics/licencekey',
            get_string('lic_key', 'local_learninganalytics'),
            get_string('lic_key_desc', 'local_learninganalytics',
                \local_learninganalytics\local\licence::site_hash()),
            '', PARAM_RAW, 60, 3
        ));

        // ------------------------------------------------------------------
        // 1. Quien puede acceder a los tableros.
        // ------------------------------------------------------------------
        $settings->add(new admin_setting_heading(
            'local_learninganalytics/hdr_access',
            get_string('hdr_access', 'local_learninganalytics'),
            get_string('hdr_access_desc', 'local_learninganalytics')
        ));

        // El administrador del sitio siempre tiene acceso (doanything), por eso
        // no aparece en la lista: no es un rol que se pueda retirar aqui.
        $settings->add(new setting_roles(
            'local_learninganalytics/viewroles',
            get_string('viewroles', 'local_learninganalytics'),
            get_string('viewroles_desc', 'local_learninganalytics'),
            'local/learninganalytics:view',
            ['manager']
        ));

        $settings->add(new setting_roles(
            'local_learninganalytics/resendroles',
            get_string('resendroles', 'local_learninganalytics'),
            get_string('resendroles_desc', 'local_learninganalytics'),
            'local/learninganalytics:resendcredentials',
            []
        ));

        $settings->add(new setting_roles(
            'local_learninganalytics/messageroles',
            get_string('messageroles', 'local_learninganalytics'),
            get_string('messageroles_desc', 'local_learninganalytics'),
            'local/learninganalytics:sendmessage',
            ['manager']
        ));

        $settings->add(new setting_roles(
            'local_learninganalytics/bulkmessageroles',
            get_string('bulkmessageroles', 'local_learninganalytics'),
            get_string('bulkmessageroles_desc', 'local_learninganalytics'),
            'local/learninganalytics:sendbulkmessage',
            []
        ));

        $settings->add(new setting_roles(
            'local_learninganalytics/teachingroles',
            get_string('teachingroles', 'local_learninganalytics'),
            get_string('teachingroles_desc', 'local_learninganalytics'),
            'local/learninganalytics:viewteaching',
            ['manager']
        ));

        $settings->add(new admin_setting_configtext(
            'local_learninganalytics/bulkmessagelimit',
            get_string('bulkmessagelimit', 'local_learninganalytics'),
            get_string('bulkmessagelimit_desc', 'local_learninganalytics'),
            200, PARAM_INT
        ));

        // ------------------------------------------------------------------
        // 2. Donde aparecen los tableros.
        // ------------------------------------------------------------------
        $settings->add(new admin_setting_heading(
            'local_learninganalytics/hdr_placement',
            get_string('hdr_placement', 'local_learninganalytics'),
            get_string('hdr_placement_desc', 'local_learninganalytics')
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_learninganalytics/enablesite',
            get_string('enablesite', 'local_learninganalytics'),
            get_string('enablesite_desc', 'local_learninganalytics'),
            1
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_learninganalytics/enablecategory',
            get_string('enablecategory', 'local_learninganalytics'),
            get_string('enablecategory_desc', 'local_learninganalytics'),
            0
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_learninganalytics/enablecourse',
            get_string('enablecourse', 'local_learninganalytics'),
            get_string('enablecourse_desc', 'local_learninganalytics'),
            0
        ));

        // ------------------------------------------------------------------
        // 3. Correspondencia de datos.
        // ------------------------------------------------------------------
        $settings->add(new admin_setting_heading(
            'local_learninganalytics/hdr_data',
            get_string('hdr_data', 'local_learninganalytics'),
            get_string('hdr_data_desc', 'local_learninganalytics')
        ));

        $fields = ['' => get_string('none')];
        try {
            foreach ($DB->get_records('user_info_field', null, 'name', 'id, name, shortname') as $f) {
                $fields[$f->shortname] = format_string($f->name) . " ({$f->shortname})";
            }
        } catch (\Throwable $e) {
            $fields = ['' => get_string('none')];
        }

        // Reemplaza el fieldid 35 cableado.
        $settings->add(new admin_setting_configselect(
            'local_learninganalytics/field_estado',
            get_string('field_estado', 'local_learninganalytics'),
            get_string('field_estado_desc', 'local_learninganalytics'),
            '', $fields
        ));

        // Reemplaza el fieldid 36 cableado.
        $settings->add(new admin_setting_configselect(
            'local_learninganalytics/field_supervisor',
            get_string('field_supervisor', 'local_learninganalytics'),
            get_string('field_supervisor_desc', 'local_learninganalytics'),
            '', $fields
        ));

        // Reemplaza los pares curso 2/tarea 11 y curso 4/tarea 12 cableados.
        $settings->add(new admin_setting_configtextarea(
            'local_learninganalytics/signature_map',
            get_string('signaturemap', 'local_learninganalytics'),
            get_string('signaturemap_desc', 'local_learninganalytics'),
            '', PARAM_RAW
        ));

        // ------------------------------------------------------------------
        // Permanencia y riesgo.
        // ------------------------------------------------------------------
        $settings->add(new admin_setting_heading(
            'local_learninganalytics/hdr_risk',
            get_string('hdr_risk', 'local_learninganalytics'),
            get_string('hdr_risk_desc', 'local_learninganalytics')
        ));

        $settings->add(new admin_setting_configtext(
            'local_learninganalytics/activehours',
            get_string('activehours', 'local_learninganalytics'),
            get_string('activehours_desc', 'local_learninganalytics'),
            7, PARAM_FLOAT, 6
        ));

        $settings->add(new admin_setting_configtext(
            'local_learninganalytics/activewindow',
            get_string('activewindow', 'local_learninganalytics'),
            get_string('activewindow_desc', 'local_learninganalytics'),
            7, PARAM_INT, 6
        ));

        $settings->add(new admin_setting_configtext(
            'local_learninganalytics/feedbackdays',
            get_string('feedbackdays', 'local_learninganalytics'),
            get_string('feedbackdays_desc', 'local_learninganalytics'),
            7, PARAM_INT, 6
        ));

        $settings->add(new admin_setting_configtext(
            'local_learninganalytics/backfilldays',
            get_string('backfilldays', 'local_learninganalytics'),
            get_string('backfilldays_desc', 'local_learninganalytics'),
            90, PARAM_INT, 6
        ));

        $settings->add(new admin_setting_configtext(
            'local_learninganalytics/taskrows',
            get_string('taskrows', 'local_learninganalytics'),
            get_string('taskrows_desc', 'local_learninganalytics'),
            200000, PARAM_INT, 10
        ));

        // ------------------------------------------------------------------
        // Apariencia del correo.
        // ------------------------------------------------------------------
        $settings->add(new admin_setting_heading(
            'local_learninganalytics/hdr_email',
            get_string('hdr_email', 'local_learninganalytics'),
            get_string('hdr_email_desc', 'local_learninganalytics')
        ));

        $settings->add(new admin_setting_configstoredfile(
            'local_learninganalytics/emaillogo',
            get_string('emaillogo', 'local_learninganalytics'),
            get_string('emaillogo_desc', 'local_learninganalytics'),
            \local_learninganalytics\local\mailer::LOGO_FILEAREA,
            0,
            ['maxfiles' => 1, 'accepted_types' => ['.png', '.jpg', '.jpeg', '.gif', '.svg']]
        ));

        // Aviso solo cuando hace falta: hay un SVG en uso y el servidor no
        // puede convertirlo, asi que el logo no se veria en la mayoria de
        // clientes de correo.
        if (\local_learninganalytics\local\mailer::get_converter() === null) {
            $logofile = get_config('local_learninganalytics', 'emaillogo');
            if ($logofile && \core_text::strpos(\core_text::strtolower($logofile), '.svg') !== false) {
                $settings->add(new admin_setting_description(
                    'local_learninganalytics/emaillogo_svgwarning',
                    '',
                    $OUTPUT->notification(
                        get_string('emaillogo_svgnote', 'local_learninganalytics'),
                        \core\output\notification::NOTIFY_WARNING)
                ));
            }
        }

        $settings->add(new admin_setting_configtext(
            'local_learninganalytics/emailaccent',
            get_string('emailaccent', 'local_learninganalytics'),
            get_string('emailaccent_desc', 'local_learninganalytics'),
            '#2a72b0', PARAM_TEXT, 10
        ));

        $settings->add(new admin_setting_configtextarea(
            'local_learninganalytics/emailfooter',
            get_string('emailfooter', 'local_learninganalytics'),
            get_string('emailfooter_desc', 'local_learninganalytics'),
            '', PARAM_TEXT
        ));

        // ------------------------------------------------------------------
        // 4. Reenvio de credenciales.
        // ------------------------------------------------------------------
        $settings->add(new admin_setting_heading(
            'local_learninganalytics/hdr_credentials',
            get_string('hdr_credentials', 'local_learninganalytics'),
            get_string('hdr_credentials_desc', 'local_learninganalytics')
        ));

        // Reemplaza el user ID 55 cableado.
        $settings->add(new admin_setting_configtext(
            'local_learninganalytics/sender_username',
            get_string('sender', 'local_learninganalytics'),
            get_string('sender_desc', 'local_learninganalytics'),
            '', PARAM_USERNAME
        ));
    }
}
