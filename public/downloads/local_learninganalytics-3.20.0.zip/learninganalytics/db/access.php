<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

/**
 * Capability definitions.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$capabilities = [

    // Ver los tableros. Se declara en CONTEXT_COURSE para que pueda concederse
    // y sobrescribirse en curso, categoria y sistema: el mismo permiso da
    // acceso al tablero del curso a un profesor y al de plataforma a un gestor,
    // segun donde tenga asignado el rol.
    // RISK_PERSONAL porque expone el padron de usuarios del ambito.
    'local/learninganalytics:view' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_COURSE,
        'riskbitmask'  => RISK_PERSONAL,
        'archetypes'   => [
            'manager' => CAP_ALLOW,
        ],
    ],

    // Enviar un correo a un usuario concreto desde el tablero.
    'local/learninganalytics:sendmessage' => [
        'captype'      => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'riskbitmask'  => RISK_SPAM | RISK_PERSONAL,
        'archetypes'   => [
            'manager' => CAP_ALLOW,
        ],
    ],

    // Enviar un mensaje a TODOS los usuarios que devuelve un filtro. Es la
    // capacidad de mayor riesgo del plugin: alcanza a mucha gente de una vez.
    // Sin archetypes, y separada de :view a proposito, para que ver analitica
    // no implique poder escribir de forma masiva.
    'local/learninganalytics:sendbulkmessage' => [
        'captype'      => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'riskbitmask'  => RISK_SPAM | RISK_PERSONAL,
        'archetypes'   => [],
    ],

    // Ver las cifras que describen el trabajo docente: intervencion en foros,
    // tiempo de respuesta, anuncios y mediacion. Se separa de :view porque
    // mide a una persona identificable, no al grupo de estudiantes. Sin
    // archetypes: se concede explicitamente desde los ajustes del plugin.
    'local/learninganalytics:viewteaching' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_COURSE,
        'riskbitmask'  => RISK_PERSONAL,
        'archetypes'   => [],
    ],

    // Reenviar credenciales: siempre a nivel de sistema, porque actua sobre
    // cuentas de usuario globales. Sin archetypes: nadie salvo el administrador
    // hasta que se conceda explicitamente desde los ajustes del plugin.
    'local/learninganalytics:resendcredentials' => [
        'captype'      => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'riskbitmask'  => RISK_PERSONAL | RISK_SPAM,
        'archetypes'   => [],
    ],
];
