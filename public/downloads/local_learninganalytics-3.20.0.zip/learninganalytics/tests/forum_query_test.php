<?php
// This file is part of Moodle - http://moodle.org/
// (GPL v3 or later - see version.php header)

namespace local_learninganalytics;

use local_learninganalytics\local\forum_query;

/**
 * Tests de foros e interaccion.
 *
 * @package    local_learninganalytics
 * @copyright  2026 Algoritmo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \local_learninganalytics\local\forum_query
 */
final class forum_query_test extends \advanced_testcase {

    /**
     * La mediana con lista par, impar y vacia.
     */
    public function test_median(): void {
        $this->assertNull(forum_query::median([]));
        $this->assertSame(5.0, forum_query::median([5]));
        $this->assertSame(3.0, forum_query::median([1, 3, 9]));
        $this->assertSame(2.5, forum_query::median([4, 1, 2, 3]));
    }

    /**
     * Sin foros visibles el bloque se declara no disponible.
     */
    public function test_course_without_forums(): void {
        $this->resetAfterTest();
        $course = $this->getDataGenerator()->create_course();
        $student = $this->getDataGenerator()->create_and_enrol($course, 'student');

        $block = (new forum_query($course->id, [$student->id], true))->run();

        $this->assertFalse($block['available']);
        $this->assertSame([], $block['forums']);
    }

    /**
     * Participacion, respuesta a un par, hilo sin respuesta y presencia docente.
     */
    public function test_participation_and_teaching(): void {
        global $DB;
        $this->resetAfterTest();

        $now = time();
        $course = $this->getDataGenerator()->create_course();
        $ana = $this->getDataGenerator()->create_and_enrol($course, 'student');
        $beto = $this->getDataGenerator()->create_and_enrol($course, 'student');
        $silente = $this->getDataGenerator()->create_and_enrol($course, 'student');
        $profe = $this->getDataGenerator()->create_and_enrol($course, 'editingteacher');

        $forum = $this->getDataGenerator()->create_module('forum',
            ['course' => $course->id, 'type' => 'general']);
        $gen = $this->getDataGenerator()->get_plugin_generator('mod_forum');

        // Hilo 1: lo abre Ana, Beto le responde y el docente cierra 2 h despues.
        $d1 = $gen->create_discussion(['course' => $course->id, 'forum' => $forum->id,
            'userid' => $ana->id]);
        $DB->set_field('forum_posts', 'created', $now - 10 * HOURSECS, ['id' => $d1->firstpost]);

        $reply = $gen->create_post(['discussion' => $d1->id, 'parent' => $d1->firstpost,
            'userid' => $beto->id]);
        $DB->set_field('forum_posts', 'created', $now - 9 * HOURSECS, ['id' => $reply->id]);

        $teacherpost = $gen->create_post(['discussion' => $d1->id, 'parent' => $d1->firstpost,
            'userid' => $profe->id]);
        $DB->set_field('forum_posts', 'created', $now - 8 * HOURSECS, ['id' => $teacherpost->id]);

        // Hilo 2: lo abre Beto hace tres dias y nadie contesta.
        $d2 = $gen->create_discussion(['course' => $course->id, 'forum' => $forum->id,
            'userid' => $beto->id]);
        $DB->set_field('forum_posts', 'created', $now - 3 * DAYSECS, ['id' => $d2->firstpost]);

        $userids = [$ana->id, $beto->id, $silente->id];
        $block = (new forum_query($course->id, $userids, true))->run();

        $this->assertTrue($block['available']);
        $this->assertSame(3, $block['expected']);
        $this->assertSame(2, $block['participants']);          // Ana y Beto.
        $this->assertSame(66.7, $block['participationrate']);
        $this->assertSame(1, $block['peerrepliers']);          // Solo Beto responde a un par.
        $this->assertSame(1, $block['peerposts']);
        $this->assertSame(2, $block['discussions']);
        $this->assertSame(1, $block['unanswered']);            // El hilo 2.
        $this->assertSame(50.0, $block['unansweredrate']);
        $this->assertSame(0.5, $block['interaction']);

        // Presencia docente: dos horas desde el primer mensaje de Ana.
        $this->assertTrue($block['canviewteaching']);
        $this->assertSame(1, $block['teachers']);
        $this->assertSame(2.0, $block['responsemedian']);
        $this->assertSame(1, $block['responsecases']);
        $this->assertSame(1, $block['facilitated']);
        $this->assertSame(1, $block['activeforums']);

        $this->assertCount(1, $block['forums']);
        $this->assertSame(1, $block['forums'][0]['teacherposts']);
        $this->assertSame(2, $block['forums'][0]['participants']);
    }

    /**
     * Sin la capacidad, las cifras docentes no salen del servidor.
     */
    public function test_teaching_is_stripped_without_capability(): void {
        global $DB;
        $this->resetAfterTest();

        $now = time();
        $course = $this->getDataGenerator()->create_course();
        $ana = $this->getDataGenerator()->create_and_enrol($course, 'student');
        $profe = $this->getDataGenerator()->create_and_enrol($course, 'editingteacher');

        $forum = $this->getDataGenerator()->create_module('forum', ['course' => $course->id]);
        $gen = $this->getDataGenerator()->get_plugin_generator('mod_forum');

        $d = $gen->create_discussion(['course' => $course->id, 'forum' => $forum->id,
            'userid' => $ana->id]);
        $DB->set_field('forum_posts', 'created', $now - 5 * HOURSECS, ['id' => $d->firstpost]);
        $post = $gen->create_post(['discussion' => $d->id, 'parent' => $d->firstpost,
            'userid' => $profe->id]);
        $DB->set_field('forum_posts', 'created', $now - 4 * HOURSECS, ['id' => $post->id]);

        $block = (new forum_query($course->id, [$ana->id], false))->run();

        // Lo del estudiante se mantiene.
        $this->assertSame(1, $block['participants']);
        $this->assertSame(1, $block['discussions']);

        // Lo del docente, no.
        $this->assertFalse($block['canviewteaching']);
        $this->assertSame(0, $block['teachers']);
        $this->assertNull($block['responsemedian']);
        $this->assertSame(0, $block['facilitated']);
        $this->assertSame(0, $block['forums'][0]['teacherposts']);
        $this->assertNull($block['forums'][0]['responsemedian']);
    }
}
